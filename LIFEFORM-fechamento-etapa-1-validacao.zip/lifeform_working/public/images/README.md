# Imagens

Estrutura (ver `docs/VISUAL_ASSETS.md` para a lista completa de slots):

```
images/
  anime/
    modules/01-identity-480.webp  (+ -960, -1440)
    phases/1-reconstruction-480.webp
    onboarding/welcome-480.webp
    achievements/hero-480.webp
  photo/
    modules/01-identity-480.webp
    diagnostic/hero-480.webp
```

Cada imagem precisa das 3 larguras (480, 960, 1440) em `.webp`.
Arquivos ausentes não quebram o app: aparece o fallback "Imagem em preparação".
