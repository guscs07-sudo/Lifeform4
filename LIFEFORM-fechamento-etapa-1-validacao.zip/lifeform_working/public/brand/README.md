# Logo oficial

Coloque aqui o símbolo geométrico aprovado:

- `lifeform-symbol.svg` (preferencial, vetorial)

O componente `src/components/brand/Logo.tsx` carrega esse arquivo automaticamente.
Enquanto ele não existir, só o logotipo em texto é exibido; nenhum símbolo substituto é inventado.

Quando o arquivo chegar, também será extraído dele o laranja exato para
`tailwind.config.ts` (`lf.accent`) e `src/styles/globals.css` (`--lf-accent`).
Ícones do PWA (192/512 px) serão gerados a partir dele na Etapa 8.
