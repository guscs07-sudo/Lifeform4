# LIFEFORM

Plataforma de transformação pessoal em três pilares: **Corpo**, **Mente** e **Estilo de vida**.

> Status: **Fundação, avaliação, diagnóstico e jornada local implementados. Sincronização completa adiada; próxima etapa é qualidade, acabamento e validação antes da publicação.**

## Stack

Next.js 15 (App Router) · React 19 · TypeScript estrito · Tailwind 3 · Supabase (Auth + Postgres + RLS) · Vitest.
A interface usa CSS e componentes próprios nesta fase; bibliotecas adicionais só serão incluídas quando houver necessidade real e sem custo obrigatório.
Hospedagem: Vercel. Tudo dentro dos planos gratuitos; nenhum serviço pago é ativado.

## Comandos

```bash
npm install
npm run dev        # http://localhost:3000
npm run typecheck
npm run lint
npm run test
npm run build
```

Copie `.env.example` para `.env.local` quando configurar o Supabase. Sem essas variáveis, a autenticação real permanece desativada.

## Estrutura

```
src/
  app/                 rotas (App Router)
  components/
    brand/             Logo
    media/             AssetImage (carregamento progressivo + fallback)
    ui/                Button, Card, ProgressBar, Skeleton, StateViews
  features/            auth (formulários), assessment (questionário adaptativo), landing (apresentação)
  config/              pilares, módulos, fases (metadados tipados)
  content/assets/      registro de slots de imagem
  i18n/                catálogo pt-BR + tradutor tipado
  lib/                 utils, env, auth (validação, serviço), supabase (cliente)
  styles/              globals.css
public/
  brand/               logo oficial (a adicionar)
  images/              ilustrações anime e fotografias (a adicionar)
docs/                  arquitetura, assets visuais, validação
```

Módulos previstos para as próximas entregas: `src/lib/engine` (motor), `src/features/dashboard`, `src/lib/supabase` (integração de servidor) e `supabase/migrations`.

## Documentação

- `docs/ARCHITECTURE.md`: camadas, motor, modelo de dados planejado, segurança.
- `docs/VISUAL_ASSETS.md`: lista de slots, convenção de arquivos, direção de arte, licenciamento.
- `docs/VALIDATION.md`: como validar localmente e na Vercel.

## Avaliação

O fluxo adaptativo, seus limites e o armazenamento local temporário estão documentados em [`docs/ASSESSMENT.md`](docs/ASSESSMENT.md).

## Etapa 4 — Diagnóstico personalizado

A conclusão do questionário apresenta agora um relatório dos pilares Corpo, Mente e Estilo de vida. A lógica determinística e suas limitações estão documentadas em [`docs/DIAGNOSIS.md`](docs/DIAGNOSIS.md). Os indicadores são heurísticos e autorreferidos; não constituem avaliação clínica.

## Revisão da Etapa 4

A revisão complementar refinou a personalização do objetivo e a explicação da prioridade, normalizou a opção "Não tenho uma dificuldade específica" e tornou a validação de idade inteira (18+). Consulte `docs/DIAGNOSIS.md` para regras e limites. A compilação isolada do motor foi verificada; build Next.js e Vitest ainda precisam de ambiente com dependências instaladas.

## Dashboard inicial (Etapa 5)

A rota `/painel` apresenta o primeiro dashboard pós-avaliação. Ela consulta a sessão Supabase e lê a avaliação concluída no `localStorage` do mesmo dispositivo, usando a mesma chave `lifeform:assessment:v1:<userId>` do questionário. Os indicadores exibidos são recalculados pelo motor `buildDiagnosis`; não há métricas fictícias de treinos, hábitos, missões ou conquistas. Esses módulos aparecem identificados como “Em preparação” até que suas funcionalidades e dados reais sejam implementados.

A ilustração vetorial original `public/images/illustrations/dashboard-horizon.svg` é usada no hero do painel. Ela é um elemento gráfico provisório de direção de arte, não substitui a futura biblioteca de fotografias e ilustrações anime definitivas.

O botão “Ir para meu painel” aparece ao final do relatório de diagnóstico. Sem Supabase configurado, o painel informa que o acesso ainda não está ativo; não cria uma sessão simulada. As respostas da avaliação permanecem locais neste estágio.

## Jornada pessoal (Etapa 5 — atualização)

O painel inclui registro de atividades, hábitos, metas, uma missão semanal e conquistas calculadas a partir dos registros reais. Nesta versão, os registros ficam no armazenamento local do navegador e não são sincronizados entre dispositivos. Consulte `docs/JOURNEY_MODULES.md` para os limites e detalhes.

## Evolução semanal

O painel inclui uma leitura descritiva que compara os últimos sete dias com os sete dias anteriores, baseada exclusivamente nos treinos registrados pelo usuário. A leitura não estima condicionamento físico nem recomenda aumento de carga/intensidade. A rotina continua armazenada localmente por perfil até a integração com Supabase.

## Backup dos dados locais

Na visão geral da jornada, o usuário pode exportar atividades, hábitos, metas e sessões de treino em um arquivo JSON versionado. Nesta fase, os dados ainda são locais ao navegador; a exportação ajuda a criar uma cópia de segurança, mas não substitui a futura sincronização segura com Supabase.

## Infraestrutura Supabase

A primeira migração SQL e o guia de configuração estão em `supabase/migrations/` e `docs/SUPABASE_SETUP.md`. A migração deve ser aplicada manualmente em um projeto Supabase exclusivo do LIFEFORM; ela ainda não foi executada em um projeto real e não ativa sincronização por si só. Para verificar a estrutura estática localmente, execute `npm run validate:schema`.


## Sincronização manual da avaliação

A avaliação inicial agora consulta e pode sincronizar manualmente a tabela `assessments`. Quando não há cópia local, a versão da nuvem pode ser recuperada; quando as versões divergem, o usuário escolhe explicitamente qual manter. O painel também consegue usar uma avaliação concluída da nuvem se não houver uma versão concluída local. Esta integração ainda depende de configuração e validação em um projeto Supabase real.


## Próxima etapa — qualidade e acabamento

A sincronização completa das coleções da jornada foi adiada para um ciclo posterior. As integrações manuais já existentes não foram removidas, mas não devem ser consideradas validadas sem um projeto Supabase real. O foco imediato é corrigir achados estáticos, revisar acessibilidade e experiência mobile, executar testes, lint, typecheck e build, e então preparar a publicação. Consulte `docs/STATUS-ATUAL.md` e `docs/VALIDATION.md` para o estado real e os bloqueios.


### Retorno seguro após login

Ao proteger uma rota privada, o middleware preserva o destino solicitado no parâmetro `next`. Após login ou cadastro, o app só aceita destinos internos sob `/painel` ou `/avaliacao`; URLs externas ou rotas públicas são descartadas.
\n\n## Validação da primeira etapa\nConsulte `docs/VALIDACAO-ETAPA-1.md` para o escopo revisado, verificações executadas e bloqueios ainda pendentes.\n