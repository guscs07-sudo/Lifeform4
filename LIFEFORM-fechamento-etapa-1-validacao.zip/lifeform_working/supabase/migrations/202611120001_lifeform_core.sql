-- LIFEFORM core schema — project Supabase exclusivo do LIFEFORM.
-- Execute em um projeto novo. Nunca reutilize o projeto/credenciais do OPERAÇÃO TAF.
-- Todas as tabelas pertencentes ao usuário usam RLS e auth.uid() como proprietário.

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '' check (char_length(display_name) <= 80),
  adult_confirmed_at timestamptz,
  onboarding_completed_at timestamptz,
  preferences jsonb not null default '{}'::jsonb check (jsonb_typeof(preferences) = 'object'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.assessments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  version integer not null default 1 check (version > 0),
  status text not null default 'draft' check (status in ('draft', 'completed')),
  answers jsonb not null default '{}'::jsonb check (jsonb_typeof(answers) = 'object'),
  diagnosis jsonb check (diagnosis is null or jsonb_typeof(diagnosis) = 'object'),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint assessments_completion_consistency check (
    (status = 'draft' and completed_at is null) or (status = 'completed' and completed_at is not null)
  )
);

create index if not exists assessments_user_created_idx on public.assessments (user_id, created_at desc);

create table if not exists public.journey_states (
  user_id uuid primary key references auth.users(id) on delete cascade,
  schema_version integer not null default 1 check (schema_version > 0),
  current_phase text not null default 'reconstruction' check (current_phase in ('reconstruction', 'development', 'evolution', 'consolidation')),
  state jsonb not null default '{}'::jsonb check (jsonb_typeof(state) = 'object'),
  updated_at timestamptz not null default now()
);

create table if not exists public.weekly_reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  week_start date not null,
  energy text check (energy is null or energy in ('low', 'medium', 'high')),
  recovery text check (recovery is null or recovery in ('poor', 'fair', 'good')),
  perceived_difficulty text check (perceived_difficulty is null or perceived_difficulty in ('easy', 'moderate', 'hard')),
  routine_changed boolean not null default false,
  notes text check (notes is null or char_length(notes) <= 2000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, week_start)
);

create index if not exists weekly_reviews_user_week_idx on public.weekly_reviews (user_id, week_start desc);

create table if not exists public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  activity_type text not null check (char_length(activity_type) between 1 and 60),
  title text not null check (char_length(title) between 1 and 120),
  completed_at timestamptz not null default now(),
  duration_minutes integer check (duration_minutes is null or duration_minutes between 1 and 1440),
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz not null default now()
);

create index if not exists activity_logs_user_completed_idx on public.activity_logs (user_id, completed_at desc);

create table if not exists public.habits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  description text check (description is null or char_length(description) <= 500),
  cadence text not null default 'daily' check (cadence in ('daily', 'weekly', 'custom')),
  is_active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists habits_user_active_idx on public.habits (user_id, is_active, sort_order);

create table if not exists public.habit_completions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  habit_id uuid not null references public.habits(id) on delete cascade,
  completed_on date not null,
  created_at timestamptz not null default now(),
  unique (user_id, habit_id, completed_on)
);

create index if not exists habit_completions_user_date_idx on public.habit_completions (user_id, completed_on desc);

create table if not exists public.goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 140),
  description text check (description is null or char_length(description) <= 1000),
  pillar text not null check (pillar in ('body', 'mind', 'lifestyle')),
  status text not null default 'active' check (status in ('active', 'completed', 'paused', 'archived')),
  target_date date,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists goals_user_status_idx on public.goals (user_id, status, created_at desc);

create table if not exists public.workout_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 140),
  plan jsonb not null default '{}'::jsonb check (jsonb_typeof(plan) = 'object'),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists workout_plans_user_active_idx on public.workout_plans (user_id, is_active, updated_at desc);

create table if not exists public.workout_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id uuid references public.workout_plans(id) on delete set null,
  title text not null check (char_length(title) between 1 and 140),
  exercises jsonb not null default '[]'::jsonb check (jsonb_typeof(exercises) = 'array'),
  status text not null default 'planned' check (status in ('planned', 'completed', 'skipped')),
  scheduled_for date,
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists workout_sessions_user_date_idx on public.workout_sessions (user_id, scheduled_for desc nulls last);

create table if not exists public.achievements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  achievement_key text not null check (char_length(achievement_key) between 1 and 80),
  unlocked_at timestamptz not null default now(),
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  unique (user_id, achievement_key)
);

create table if not exists public.mission_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  mission_key text not null check (char_length(mission_key) between 1 and 80),
  period_start date not null,
  progress integer not null default 0 check (progress >= 0),
  target integer not null check (target > 0),
  completed_at timestamptz,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  unique (user_id, mission_key, period_start)
);

-- Atualização automática de updated_at.
do $$
declare
  table_name text;
begin
  foreach table_name in array array['profiles','assessments','journey_states','weekly_reviews','habits','goals','workout_plans','workout_sessions'] loop
    execute format('drop trigger if exists set_updated_at on public.%I', table_name);
    execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()', table_name);
  end loop;
end;
$$;

-- Perfil mínimo criado no cadastro; metadados são tratados como entrada não confiável.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(left(new.raw_user_meta_data ->> 'display_name', 80), ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_lifeform on auth.users;
create trigger on_auth_user_created_lifeform
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- RLS em todas as tabelas de dados pessoais.
do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'assessments','journey_states','weekly_reviews','activity_logs',
    'habits','habit_completions','goals','workout_plans','workout_sessions',
    'achievements','mission_progress'
  ] loop
    execute format('alter table public.%I enable row level security', table_name);
    execute format('drop policy if exists owner_select on public.%I', table_name);
    execute format('drop policy if exists owner_insert on public.%I', table_name);
    execute format('drop policy if exists owner_update on public.%I', table_name);
    execute format('drop policy if exists owner_delete on public.%I', table_name);
    execute format('create policy owner_select on public.%I for select to authenticated using (auth.uid() = user_id)', table_name);
    execute format('create policy owner_insert on public.%I for insert to authenticated with check (auth.uid() = user_id)', table_name);
    execute format('create policy owner_update on public.%I for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id)', table_name);
    execute format('create policy owner_delete on public.%I for delete to authenticated using (auth.uid() = user_id)', table_name);
  end loop;
end;
$$;

-- profiles usa id como identificador do proprietário, não user_id.
drop policy if exists owner_select on public.profiles;
drop policy if exists owner_insert on public.profiles;
drop policy if exists owner_update on public.profiles;
drop policy if exists owner_delete on public.profiles;
create policy owner_select on public.profiles for select to authenticated using (auth.uid() = id);
create policy owner_insert on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy owner_update on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy owner_delete on public.profiles for delete to authenticated using (auth.uid() = id);

-- Grants mínimos para o papel autenticado; RLS continua sendo a barreira de acesso.
grant usage on schema public to authenticated;
grant select, insert, update, delete on
  public.profiles, public.assessments, public.journey_states, public.weekly_reviews,
  public.activity_logs, public.habits, public.habit_completions, public.goals,
  public.workout_plans, public.workout_sessions, public.achievements, public.mission_progress
  to authenticated;
