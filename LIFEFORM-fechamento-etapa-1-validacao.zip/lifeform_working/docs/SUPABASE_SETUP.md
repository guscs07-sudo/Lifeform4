# LIFEFORM — preparação do Supabase

Esta pasta contém a primeira migração relacional do LIFEFORM. Ela **não conecta nem cria** um projeto Supabase automaticamente.

## Regra de separação

- Crie um projeto Supabase exclusivo chamado LIFEFORM.
- Não reutilize URL, chaves, banco ou projeto do OPERAÇÃO TAF.
- Não compartilhe senha, `service_role` ou chave secreta no chat, no navegador ou no GitHub.

## Aplicar a migração

1. No painel do projeto Supabase do LIFEFORM, abra **SQL Editor**.
2. Crie uma consulta nova.
3. Copie o conteúdo de `supabase/migrations/202611120001_lifeform_core.sql`.
4. Revise se está no projeto correto e execute.
5. Em **Table Editor**, confira se as 12 tabelas foram criadas e se RLS está habilitado.
6. Em Authentication, configure confirmação de e-mail e URLs de redirecionamento antes de testar cadastro.

A migração cria tabelas para perfil, avaliação, estado da jornada, revisões semanais, atividades, hábitos, conclusões de hábitos, metas, planos e sessões de treino, conquistas e missões. Os registros são isolados por `auth.uid()`.

## Variáveis de ambiente

Configure apenas no ambiente de desenvolvimento/deploy:

```env
NEXT_PUBLIC_SUPABASE_URL=https://SEU-PROJETO.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=SUA_CHAVE_PUBLICA_ANON_OU_PUBLISHABLE
NEXT_PUBLIC_APP_URL=https://SEU-DOMINIO
```

Use a chave pública/anon apropriada ao projeto. **Nunca** coloque `service_role` ou `sb_secret_` em variável `NEXT_PUBLIC_*`, no código do navegador ou em repositório.

## Limites desta entrega

- A migração SQL foi escrita, mas não foi executada contra um projeto Supabase real.
- O cliente de autenticação existente ainda precisa de sessão SSR, proteção de rotas e recuperação de senha.
- As telas atuais ainda usam armazenamento local para a jornada; sincronização remota não está implementada nesta migração.
- A confirmação de maioridade existente é uma declaração de cadastro, não uma verificação independente de idade.
- Antes de dados reais, revisar políticas RLS, fluxos de conta, privacidade e requisitos legais com testes de duas contas distintas.

## Teste de isolamento obrigatório antes do uso

1. Crie duas contas de teste diferentes.
2. Registre um dado na conta A.
3. Entre na conta B e confirme que não consegue consultar, alterar ou excluir o dado da conta A.
4. Repita para avaliação, jornada, revisões, atividades, hábitos, metas e treinos.
5. Teste logout, expiração de sessão e recuperação de senha.

Não use dados pessoais sensíveis reais até concluir essa validação.

## Sessão SSR e proteção de rotas (preparação adicionada)

O projeto agora inclui:

- `src/middleware.ts`: renova a sessão Supabase usando cookies e valida o usuário com `auth.getUser()` antes de liberar `/painel` e `/avaliacao`.
- `src/lib/supabase/server.ts`: cria cliente Supabase para Server Components/Route Handlers usando cookies do Next.js 15.
- `src/lib/auth/protectedRoutes.ts`: centraliza a lista de rotas privadas e a URL segura de retorno ao login.

O middleware só ativa a validação remota quando URL e chave pública do Supabase estiverem configuradas. Sem configuração, não simula uma sessão: as telas existentes continuam exibindo o aviso de integração pendente.

### Antes de liberar para uso real

1. Aplicar a migração SQL no projeto Supabase exclusivo do LIFEFORM.
2. Configurar URL e chave pública nas variáveis de ambiente da Vercel.
3. Configurar no Supabase as URLs permitidas de site e redirecionamento para cadastro/confirmação de e-mail.
4. Executar o fluxo completo de cadastro, confirmação, login, renovação de sessão e logout em dois usuários distintos.
5. Verificar no navegador que cookies de sessão são renovados e que `/painel` e `/avaliacao` redirecionam usuários anônimos para `/entrar`.

A proteção de middleware complementa, mas não substitui, RLS no banco. Toda consulta de dados pessoais deve continuar usando a sessão do usuário e as políticas `auth.uid()`.

## Sincronização manual da jornada (implementada no cliente)

A área `JourneyCloudSync` usa a tabela `journey_states` com a sessão do usuário autenticado e as políticas RLS. A sincronização é manual e deliberada:

- Ao abrir a jornada, consulta a linha do `user_id` autenticado.
- Se só existir cópia remota, carrega essa cópia no armazenamento local do perfil.
- Se houver dados locais e remotos diferentes, apresenta uma escolha explícita entre manter este aparelho ou usar a nuvem.
- Se só houver dados locais, permite enviar a primeira cópia para a nuvem.
- Depois de sincronizado, o usuário pode enviar alterações pelo botão; não há sobrescrita automática em segundo plano.
- Falhas de consulta ou envio preservam os dados locais e mostram uma mensagem de erro.

A sincronização atual cobre o estado agregado da jornada (atividades, hábitos, metas, sessões de treino e revisões semanais) na coluna `journey_states.state`, e a avaliação inicial na tabela `assessments`. Ambas são manuais e apresentam conflito quando as versões local e remota divergem. A sincronização da jornada ainda não substitui a normalização/replicação de cada coleção nas tabelas específicas. O teste real depende de aplicar a migração e configurar as variáveis do Supabase.
