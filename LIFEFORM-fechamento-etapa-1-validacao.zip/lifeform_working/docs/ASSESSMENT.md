# LIFEFORM — Avaliação (Etapa 3)

## Fluxo implementado

- 22 perguntas essenciais distribuídas nos 10 módulos planejados.
- 7 perguntas condicionais que aparecem apenas quando a resposta anterior as torna relevantes.
- Tipos de pergunta: escolha única, múltipla escolha, escala de 0 a 10, número e texto curto/livre.
- Navegação uma pergunta por tela, barra de progresso, voltar, validação de obrigatoriedade e retomada do rascunho.
- O questionário só é exibido para uma sessão autenticada pelo serviço de autenticação existente. Se o Supabase não estiver configurado, a tela mantém o aviso de acesso inativo; não há login ou usuário fictício.

## Armazenamento nesta etapa

Até a integração do banco, as respostas ficam no `localStorage` do navegador, com chave por ID de usuário (`lifeform:assessment:v1:<userId>`). A tela informa isso antes de começar e oferece a opção de apagar e recomeçar. As respostas ainda não são sincronizadas entre dispositivos nem enviadas ao servidor. Em dispositivo compartilhado, não iniciar a avaliação.

## Limites funcionais

- Esta etapa coleta respostas; não gera diagnóstico, classificação de saúde ou prescrição.
- O diagnóstico e a priorização pertencem à Etapa 4; o motor de programas pertence à Etapa 5.
- A avaliação concluída é um estado local. A persistência remota, RLS e sincronização serão implementadas na etapa de banco/integração.
- As ilustrações usam os slots existentes. Enquanto os arquivos finais não forem adicionados, o componente mostra o fallback previsto no design system, sem imagens genéricas.

## Testes

`src/lib/assessment/questions.test.ts` cobre quantidade de perguntas essenciais, condições de exibição e validação de obrigatoriedade. Build e testes React ainda precisam ser executados em ambiente com dependências instaladas.

## Saída da avaliação

Ao concluir as perguntas obrigatórias, a interface abre o relatório da Etapa 4. A leitura é feita por `src/lib/assessment/diagnosis.ts`; consulte `docs/DIAGNOSIS.md` para conhecer os critérios, limitações e avisos de segurança.
