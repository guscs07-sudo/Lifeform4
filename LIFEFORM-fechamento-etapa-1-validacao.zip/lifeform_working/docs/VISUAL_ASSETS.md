# Ativos visuais

O LIFEFORM combina três linguagens: **anime cinematográfico adulto**, **fotografia realista** e **elementos gráficos/tecnológicos** (estes últimos são código: SVG, gráficos, animações).

Os slots abaixo estão definidos em `src/content/assets/registry.ts`. Cada imagem tem uma função na tela; nenhuma é decorativa.

## Convenção de arquivos

`public/images/<anime|photo>/<slug>-<largura>.webp`, com larguras **480, 960 e 1440**.
Exemplo: `public/images/anime/modules/01-identity-960.webp`.

- Formato: WebP, qualidade ~80, ≤ 150 KB na largura 960.
- Proporções: anime 16:9, fotografia 4:5 (módulos) ou 16:9 (cabeçalhos).
- Compor com a área central livre, pois o app sobrepõe título e gradiente nas bordas.

## Slots

| Slug (anime) | Função |
|---|---|
| `onboarding/welcome` | Boas-vindas e apresentação |
| `modules/01-identity` … `modules/10-goals` | Abertura de cada módulo do assessment |
| `phases/1-reconstruction` … `phases/4-consolidation` | Identidade de cada fase |
| `achievements/hero` | Cabeçalho de conquistas |
| `pillars/body`, `pillars/mind`, `pillars/lifestyle` | Identidade visual dos três pilares |
| `training/library` | Cabeçalho da biblioteca de exercícios |

| Slug (photo) | Função |
|---|---|
| `onboarding/welcome` | Variação fotográfica da entrada |
| `modules/01-identity` … `modules/10-goals` | Apoio visual das perguntas em cartões |
| `diagnostic/hero` | Cabeçalho do diagnóstico |
| `pillars/body`, `pillars/mind`, `pillars/lifestyle` | Fotografias de apoio dos três pilares |
| `training/library` | Fotografia de apoio da biblioteca de exercícios |

Total atual do registro: 20 slots anime e 16 slots fotográficos (36 no total). Os arquivos WebP finais ainda precisam ser produzidos e adicionados; o registro de slots não significa que as imagens já estejam presentes. Imagens por pergunta e por opção de cartão também precisarão ser adicionadas conforme o questionário visual for finalizado.

## Direção de arte por módulo

| Módulo | Anime | Fotografia |
|---|---|---|
| 01 Identidade | Personagem adulto diante de um horizonte urbano ao amanhecer | Retrato de pessoa comum em ambiente cotidiano |
| 02 Corpo | Treino em luz laranja, foco no esforço | Corrida ou aquecimento ao ar livre |
| 03 Treinamento | Sequência de movimento em academia escura | Equipamentos e treino em casa/academia |
| 04 Alimentação | Refeição preparada em cozinha à noite | Refeição equilibrada, ingredientes frescos |
| 05 Sono | Quarto em penumbra azulada, descanso | Cama, luz suave, ambiente sem telas |
| 06 Mente | Personagem concentrado, ambiente minimalista | Mesa de trabalho organizada |
| 07 Rotina | Cidade em movimento, relógio ou transporte | Rotina de trabalho e estudo |
| 08 Hábitos | Pequena ação repetida (acordar, caminhar) | Hábitos simples do dia a dia |
| 09 Saúde | Tom sereno e cuidadoso, sem imagem de dor | Alongamento, caminhada leve |
| 10 Metas | Personagem no topo de um percurso, visão de futuro | Trilha ou paisagem aberta |

Estética anime: adulta, cinematográfica, paleta preto/grafite com laranja de destaque, sem traço infantil ou caricato.

## Licenciamento

- Ilustrações geradas ou encomendadas: guardar prova de licença/termos da ferramenta usada.
- Fotografias: apenas bancos com licença comercial (ex.: Unsplash, Pexels) ou fotos próprias; registrar autor e URL de origem em `docs/ASSET_LICENSES.md` ao adicionar cada arquivo.
- Nunca referenciar URLs externas no app: todos os arquivos ficam em `public/images`.
- Não usar personagens, marcas ou obras de terceiros.

## Comportamento no app

`<AssetImage slotId="…" />` reserva a proporção (sem salto de layout), faz fade-in ao carregar, usa `srcset`, carrega as imagens abaixo da dobra com `loading="lazy"` e mostra um fallback "Imagem em preparação" se o arquivo faltar ou falhar.

## Estado real dos arquivos

O registro define os destinos e a função de cada imagem, mas não substitui a arte final de toda a biblioteca. Nesta atualização foram adicionadas três larguras WebP para `anime.onboarding/welcome` e `photo.training/library`, integradas aos caminhos já consumidos por `AssetImage`. Os demais slots ainda aguardam suas artes finais. Consulte `docs/ASSET_LICENSES.md` para a origem dos dois conjuntos adicionados. Não marcar outros slots como concluídos até que seus arquivos 480, 960 e 1440 tenham sido adicionados e conferidos.

## Ativos integrados — pilares (novembro/2026)

Foram adicionadas variantes WebP responsivas (480, 960 e 1440 px) para os três cartões da seção de pilares:
- `photo/pillars/body-*`: imagem fotográfica conceitual para Corpo.
- `anime/pillars/mind-*`: ilustração anime conceitual para Mente.
- `photo/pillars/lifestyle-*`: imagem fotográfica conceitual para Estilo de Vida.

Os cartões da landing page usam `AssetImage` com os slots já definidos no registro. As imagens são recortes de arte conceitual gerada para o projeto; devem ser substituídas por artes finais individuais de maior resolução antes do lançamento público, se a revisão visual assim indicar.
