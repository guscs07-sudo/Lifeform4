# Registro de origem dos ativos visuais

## Ativos adicionados nesta atualização

| Arquivo-base | Tipo | Origem | Observação |
|---|---|---|---|
| `public/images/anime/onboarding/welcome-*.webp` | Ilustração anime cinematográfica | Gerada originalmente por IA para o LIFEFORM em 12/11/2026 | Recorte do personagem e cenário, sem interface ou texto incorporado. |
| `public/images/photo/training/library-*.webp` | Imagem fotográfica estilizada | Gerada originalmente por IA para o LIFEFORM em 12/11/2026 | Recorte de imagem de exercício do painel visual conceitual; não representa demonstração técnica de execução. |

Os arquivos foram produzidos para este projeto e não reproduzem personagens, marcas ou obras identificáveis de terceiros. Manter este registro atualizado quando novos ativos forem adicionados.
