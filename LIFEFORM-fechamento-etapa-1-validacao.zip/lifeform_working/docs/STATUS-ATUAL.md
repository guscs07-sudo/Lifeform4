# LIFEFORM — status técnico atual

## Escopo preservado

O objetivo original permanece: plataforma de transformação pessoal organizada em Corpo, Mente e Estilo de Vida, com avaliação adaptativa, diagnóstico, painel, jornada em quatro fases (Reconstrução, Desenvolvimento, Evolução e Consolidação), módulos de hábitos, metas, atividades, treinos, revisões, histórico e gamificação. O produto continua inicialmente restrito a dois perfis independentes (usuário e namorada), sem priorizar cadastro público.

## O que está no pacote

- Next.js 15, React 19, TypeScript estrito e Tailwind.
- Landing page, identidade visual, design system e ativos visuais locais.
- Cadastro/login e proteção de rotas preparados para Supabase.
- Avaliação adaptativa, diagnóstico e painel.
- Jornada local com fases, hábitos, metas, atividades, sessões de treino, revisão semanal, orientação, progresso e gamificação.
- Biblioteca de exercícios e construtor de plano.
- Backup local com validação de perfil.
- Gráficos SVG de evolução.
- Migração inicial Supabase com 12 tabelas e políticas RLS.
- Sincronização manual inicial da avaliação e do estado agregado da jornada.

## Limites que continuam explícitos

- A migração SQL não foi aplicada nem testada em um projeto Supabase real.
- A sincronização completa das coleções normalizadas da jornada foi adiada por decisão do produto; não está concluída.
- A sincronização manual já existente não foi validada com duas contas reais nem em dois dispositivos.
- Confirmação de e-mail, recuperação de senha e exclusão de conta ainda precisam de validação ponta a ponta.
- Safari/iPhone real não foi testado neste ambiente.
- Não há evidência de deploy de produção neste pacote.

## Validação desta entrega

- Integridade do ZIP de entrada: aprovada.
- `node scripts/validate-supabase-schema.mjs`: aprovado (12 tabelas e verificações estáticas RLS/perfil/gatilho).
- Instalação de dependências: excedeu o limite de tempo do ambiente; não foi concluída.
- Consequentemente, Vitest, ESLint, TypeScript com dependências reais e build de produção não foram executados aqui.

## Próximas dependências externas para lançamento

1. Concluir e validar o aplicativo localmente, sem iniciar ainda o fluxo de publicação.
2. Depois da etapa do aplicativo, enviar a versão consolidada ao GitHub.
3. Configurar projeto Supabase independente, aplicar a migração e testar RLS com duas contas distintas.
4. Validar fluxos de cadastro, confirmação, login, recuperação, logout e troca de perfil.
5. Testar no Safari/iPhone e em desktop.
6. Só então avançar para hospedagem e publicação.

Não marcar como pronto para produção até os itens acima passarem.

## Revisão adicional — isolamento local ao trocar de perfil (12/11/2026)

- Corrigido o carregamento do espaço local da jornada quando o `userId` muda sem desmontar o componente: o estado anterior é limpo antes de ler a chave do novo perfil.
- A persistência agora só grava quando a chave carregada corresponde à chave do perfil atualmente ativo. Isso evita gravar dados do perfil anterior na chave do perfil seguinte durante a troca de conta.
- A sincronização completa entre dispositivos permanece fora desta etapa, conforme decisão do produto.
- Esta correção foi revisada estaticamente; ainda depende de teste funcional com duas contas reais no navegador para validação ponta a ponta.

## Revisão de experiência e consistência dos perfis (12/11/2026)

- O organizador semanal de treinos agora limpa e recarrega seu estado ao trocar o `userId`, bloqueia salvar/apagar enquanto a chave do perfil ainda não foi carregada e valida o formato do plano lido do armazenamento local. Isso evita exibir ou gravar a rotina do perfil anterior durante a troca de conta.
- O salvamento do organizador valida título, foco, dia e duração; erros de leitura/gravação agora são apresentados na interface em vez de falharem silenciosamente.
- Hábitos com frequência semanal agora são contabilizados e marcados por semana (segunda a domingo), enquanto hábitos diários continuam vinculados ao dia atual. O resumo e o estado visual usam a mesma regra.
- Navegação por âncoras no painel recebeu margem de rolagem para não deixar os títulos ocultos pela navegação fixa inferior.
- A validação de sintaxe TypeScript/JSX dos dois componentes alterados passou via transpiler TypeScript. A validação estática Supabase continua aprovada (12 tabelas e políticas RLS).
- `npm install` excedeu 120 segundos neste ambiente; por isso Vitest, ESLint e build completo continuam sem execução. Não declarar esta revisão pronta para produção.

## Revisão de progressão e consistência semanal (12/11/2026)

- O painel de evolução por fases agora identifica a chave de armazenamento carregada para o perfil ativo. Ao trocar `userId`, volta ao estado de carregamento, limpa a confirmação visual anterior e repõe a fase inicial antes de ler a fase persistida do novo perfil.
- A confirmação de avanço fica bloqueada até a fase do perfil atual estar carregada, evitando gravar uma mudança na chave errada durante a troca de conta.
- O cálculo de prontidão agora deduplica datas repetidas e limita cada hábito semanal a uma conclusão por semana, impedindo que dados antigos/importados inflem artificialmente a consistência.
- Foram adicionados testes unitários para hábito semanal, datas diárias duplicadas e registros fora da semana atual.
- A sintaxe TSX/TypeScript dos três arquivos alterados passou via `transpileModule`; a validação estática Supabase passou (12 tabelas e políticas RLS); ZIP de entrega será validado após empacotamento.
- Dependências não foram instaladas nesta rodada; Vitest, ESLint, typecheck completo, build e testes reais com duas contas/Safari continuam pendentes. Não declarar pronto para produção.


## Revisão de integração entre diagnóstico e plano inicial (12/11/2026)

- O plano personalizado do painel agora recebe explicitamente o pilar prioritário calculado pelo diagnóstico, em vez de recalcular o foco apenas a partir da preferência declarada no questionário. Isso alinha o foco exibido no plano com a prioridade baseada nas respostas e evidências dos três pilares.
- A função geradora mantém compatibilidade com chamadas anteriores: quando não recebe prioridade calculada, continua usando a preferência declarada no questionário.
- Adicionado teste unitário para garantir que a prioridade do diagnóstico prevaleça na geração integrada do plano.
- Validação estática do esquema Supabase aprovada (12 tabelas e políticas RLS). A instalação de dependências não está disponível nesta rodada; Vitest, ESLint, typecheck completo, build e testes de navegador permanecem pendentes.


## Integração consolidada de treinos, evolução e recompensas (12/11/2026)

- Criado `summarizeJourneyRewards` como fonte única dos totais usados por XP, missões e conquistas: movimentos independentes, sessões válidas, hábitos concluídos sem datas duplicadas e metas concluídas.
- O treino registrado passa a gravar `trainingSessionId` na atividade-espelho. XP, missão semanal e indicadores não contam a mesma sessão duas vezes.
- Registros antigos são conciliados pelo formato exato da atividade-espelho anterior; vínculos órfãos continuam sendo tratados como atividades independentes.
- Datas impossíveis, registros futuros e durações não positivas são excluídos dos indicadores e do XP. Conclusões repetidas do mesmo hábito na mesma data não geram XP extra.
- Gráficos, comparação semanal e minutos acumulados passam a consumir sessões validadas; insights semanais recebem atividades independentes, sem espelhos de treino.
- Quatro cenários isolados passaram: treino espelhado sem XP duplicado; conciliação de registro legado; filtro de datas/durações e deduplicação de hábitos; preservação de vínculo órfão.
- Validação estática Supabase aprovada (12 tabelas/RLS/trigger). Transpilação sintática de 90 arquivos TS/TSX aprovada. Vitest completo, typecheck, ESLint, build Next.js e validação em navegador/iPhone continuam pendentes porque as dependências do projeto não estão instaladas neste ambiente.

## Revisão de persistência local e integridade de backup (12/11/2026)

- A jornada agora exibe um aviso explícito quando o armazenamento local falha ao ler ou gravar, em vez de ocultar silenciosamente a falha.
- Se a leitura do armazenamento falhar, a gravação automática fica bloqueada para não substituir imediatamente os dados potencialmente recuperáveis por um estado vazio.
- A leitura do arquivo de backup passou a tratar falhas de `file.text()` sem interromper a interface.
- O validador de backup agora verifica datas reais do calendário (ex.: rejeita 30/02), IDs repetidos por coleção e semanas de revisão duplicadas.
- O campo `trainingSessionId` é preservado na exportação/importação validada, mantendo a associação da atividade-espelho com a sessão de treino.
- Foram adicionados três testes aos casos de backup: vínculo preservado, data impossível rejeitada e identificadores duplicados rejeitados.
- Validação estática Supabase aprovada (12 tabelas/RLS/trigger); transpilação sintática de 90 arquivos TS/TSX aprovada. Vitest completo, typecheck, ESLint, build e testes reais em Safari/iPhone continuam pendentes por ausência de `node_modules` neste ambiente.


## Bloco de isolamento de perfil e comparação de nuvem — 12/11/2026

- A tela da jornada agora é remontada ao trocar o `userId`, evitando reaproveitar estado React do perfil anterior.
- A sincronização aguarda a confirmação de que o armazenamento local carregado corresponde à chave do perfil atual.
- O estado visual da sincronização é limpo enquanto o perfil atual ainda está carregando.
- A comparação local/nuvem agora ignora apenas a ordem das chaves dos objetos; a ordem dos arrays continua significativa.
- Adicionado teste para impedir conflito falso causado somente pela ordem das propriedades serializadas.
- Validação completa de dependências, typecheck, lint, Vitest e build continua pendente.


## Bloco de retorno seguro após autenticação (12/11/2026)

- O middleware já preservava a rota privada solicitada em `next`; login e cadastro agora respeitam esse destino depois de autenticar.
- Criado `getSafePostAuthRedirect`, que aceita somente caminhos internos protegidos (`/painel` e `/avaliacao`, incluindo subrotas), preservando query/hash.
- URLs absolutas, protocol-relative, caminhos públicos, valores vazios e caminhos com barra invertida são rejeitados e levam ao destino padrão `/avaliacao`.
- Adicionados sete cenários isolados para validar destinos legítimos e tentativas de redirecionamento externo.
- Transpilação sintática dos 90 arquivos TS/TSX aprovada; validação estática Supabase aprovada (12 tabelas/RLS/trigger); sete cenários do helper executados diretamente no Node e aprovados.
- Vitest completo, typecheck, ESLint, build Next.js e teste de navegação real continuam pendentes porque as dependências não estão instaladas.
\n\n## Consolidação da Etapa 1 — estabilidade e proteção (12/11/2026)\n\n- Consolidada a revisão de persistência local, isolamento de perfil, sincronização condicionada ao perfil carregado, validação de backup e retorno seguro após autenticação.\n- Validador estático Supabase aprovado: 12 tabelas, RLS por proprietário, políticas de perfil e trigger de autenticação.\n- Transpilação sintática de 90 arquivos TypeScript/TSX aprovada, sem erros.\n- Sete verificações diretas dos helpers de autenticação, backup e estado local/nuvem aprovadas.\n- Etapa ainda em validação final: sem `package-lock.json`, sem dependências instaladas, sem execução completa de Vitest/typecheck/ESLint/build e sem teste real de duas contas no Safari/iPhone. Não declarar concluída antes dessas verificações.\n