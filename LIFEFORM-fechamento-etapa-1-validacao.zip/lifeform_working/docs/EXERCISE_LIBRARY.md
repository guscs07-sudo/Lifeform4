# Biblioteca de exercícios

A biblioteca inicial contém oito movimentos educativos, organizados por categoria. Cada registro inclui foco, músculos envolvidos, equipamento, nível de referência, instruções, erros comuns, alternativas por nível e alertas de cautela.

## Categorias
- Força
- Mobilidade
- Core
- Cardio

## Uso no aplicativo
A seção `ExerciseLibrary` oferece busca por nome, foco, equipamento e músculos, além de filtros por categoria. O usuário pode expandir cada exercício para consultar a execução, erros frequentes e alternativas. A seleção de um exercício continua conectada ao registro de treino da jornada.

## Limites e segurança
Os níveis e alternativas são referências educativas, não uma prescrição individual. O catálogo não substitui avaliação profissional, não define carga ou volume obrigatório e orienta a interrupção diante de dor aguda, tontura ou sintomas incomuns. Exercícios e variações devem ser adaptados à capacidade e às limitações da pessoa.

## Imagens
O cabeçalho usa o slot visual fotográfico `photo.training/library`. Ainda não há uma fotografia individual verificada para cada exercício; não reutilizar a mesma imagem como se representasse movimentos diferentes. A produção e integração de imagens específicas por exercício permanece pendente.
