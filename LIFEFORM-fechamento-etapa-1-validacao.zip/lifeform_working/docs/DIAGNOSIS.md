# Etapa 4 — Diagnóstico e leitura inicial

## O que esta etapa entrega

- `src/lib/assessment/diagnosis.ts`: motor determinístico e sem dependências externas para organizar respostas em três indicadores autorreferidos.
- `src/features/assessment/DiagnosisReport.tsx`: relatório visual com fase inicial, três pilares, prioridade, próximos passos e aviso de segurança.
- `src/lib/assessment/diagnosis.test.ts`: testes para cobertura, determinismo, ausência de dados e sinalização de cautela.
- A conclusão do questionário agora abre o relatório, em vez da tela de confirmação genérica.

## Como interpretar os indicadores

Os valores de 0 a 100 são resumos heurísticos de hábitos e percepções informados pelo próprio usuário. Não são percentis, escalas clínicas, avaliação médica, psicológica ou nutricional, nem previsão de resultados. O relatório mostra evidências usadas para cada pilar em uma seção expansível.

Quando não há respostas suficientes para um pilar, o sistema mostra `Dados insuficientes` e não inventa uma pontuação. A prioridade considera o menor indicador disponível e a preferência declarada, quando a diferença entre os dois é pequena.

## Fase inicial

O motor só pode sugerir `Reconstrução` ou `Desenvolvimento` como ponto de partida. `Evolução` e `Consolidação` dependem de histórico real e critérios de progresso futuro; não podem ser atribuídas por um questionário isolado.

## Segurança

Se a pessoa informar lesão, orientação profissional ou preferir conversar sobre saúde depois, o relatório mostra um aviso e não sugere exercícios específicos. Este sinal não é diagnóstico nem substitui avaliação profissional. A ausência desse sinal não significa liberação médica para exercício.

## Limitações atuais

- As respostas continuam em `localStorage`, neste navegador/dispositivo, associadas ao ID de conta. Ainda não há sincronização com Supabase.
- A tela usa slots de imagens já registrados. As imagens finais ainda não foram entregues em `public/images`; por isso o componente mostra os fundos de reserva, sem substituir por imagens genéricas.
- Os indicadores são uma primeira versão de regras transparentes. A Etapa 5 deve usar estes resultados como entrada para programas graduais, sem transformar pontuações em prescrição médica.
- Build Next.js, testes Vitest, lint e teste visual em Safari ainda precisam ser executados após instalar as dependências e integrar o projeto ao ambiente de implantação.

## Revisão complementar — novembro de 2026

- O resumo do objetivo agora é personalizado a partir da resposta `main_goal` e aparece explicitamente no relatório.
- O relatório explica por que um pilar foi escolhido como prioridade, distinguindo preferência pessoal de menor indicador disponível.
- A opção "Não tenho uma dificuldade específica" não é somada como obstáculo quando calculamos o indicador de consistência.
- A fase Desenvolvimento exige resposta válida de atividade atual, disposição declarada, no máximo um obstáculo efetivo e ausência do sinal de cautela. A fase continua sendo apenas uma sugestão inicial.
- A idade é validada como número inteiro entre 18 e 100 na avaliação. Isso é uma validação de formulário, não verificação documental de idade.
- Cenários adicionais foram adicionados aos testes de perguntas e diagnóstico.

## Validação executada nesta revisão

- TypeScript estrito nos módulos independentes `questions.ts` e `diagnosis.ts`: aprovado.
- Execução dos cenários do motor compilado isoladamente: perfil completo, ausência de dados, sinalização de segurança e normalização de obstáculos: aprovado.
- Vitest, lint e build Next.js: não executados, pois a instalação de dependências não concluiu neste ambiente.
