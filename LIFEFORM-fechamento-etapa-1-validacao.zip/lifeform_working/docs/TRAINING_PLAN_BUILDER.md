# Organizador semanal de rotina

O componente `TrainingPlanBuilder` permite que cada perfil organize dias, foco geral e tempo disponível para sua semana. Ele não prescreve exercícios, cargas, intensidade ou progressões. Os dados são salvos no `localStorage` com chave isolada por `userId` neste dispositivo.

A sincronização entre dispositivos e a persistência no Supabase ficam para a etapa de integração. O organizador é uma ferramenta de planejamento pessoal, não uma avaliação clínica ou prescrição profissional.
