# Validação técnica e preparação para publicação

Nada aqui foi executado pelo autor do código: o ambiente de desenvolvimento não instala pacotes.
**A Etapa 1 só está concluída quando o deploy na Vercel terminar com sucesso e o checklist final passar.**

## Como a validação automática funciona

A Vercel executa, nesta ordem:

1. `npm install`
2. `npm run vercel-build`, que roda os **testes** (`vitest`) e depois `next build` (que também faz **typecheck** e **lint**)

Qualquer falha em testes, tipos, lint ou build interrompe o deploy e aparece no log da Vercel.
Envie o texto (ou captura de tela) do erro e o código é corrigido.

## 1. Validação local obrigatória

Em um ambiente com Node.js 20+ e dependências instaladas, execute nesta ordem:

```bash
npm install
npm run validate:schema
npm run typecheck
npm run lint
npm run test
npm run build
```

A publicação só deve avançar quando todos os comandos terminarem com sucesso. Se não existir `package-lock.json`, use `npm install` uma vez para gerar o lockfile e depois mantenha-o versionado.

## 2. Enviar para o GitHub pelo celular

1. No GitHub (Safari ou app), crie um repositório **novo**, privado, **sem** README (independente do OPERAÇÃO TAF).
2. No repositório: **Add file → Create new file**. No nome do arquivo digite `.github/workflows/unpack-zip.yml` (as barras criam as pastas). Cole o conteúdo de `docs/unpack-zip.workflow.yml`. Toque em **Commit changes**.
3. **Add file → Upload files** e escolha `lifeform.zip` (do app Arquivos). Toque em **Commit changes**.
4. Aba **Actions**: o fluxo "Unpack project zip" roda por ~1 minuto. Quando ficar verde, o repositório terá todas as pastas e arquivos.
   - Se não iniciar sozinho: Actions → "Unpack project zip" → **Run workflow**.
   - Se falhar na parte do `package-lock.json`, ela é ignorada (não impede nada).

## 3. Publicar na Vercel

1. vercel.com → entre com o GitHub → **Add New… → Project** → escolha o repositório → **Import**.
2. Framework: Next.js (detectado). Não precisa de variáveis de ambiente na Etapa 1. Plano Hobby.
3. **Deploy** e acompanhe o log.

## 4. Checklist após o deploy verde (Safari no iPhone)

- [ ] `/` e `/design-system` abrem sem erro.
- [ ] Sem rolagem horizontal; conteúdo respeita o notch e a barra inferior.
- [ ] Botões confortáveis para toque.
- [ ] Fontes carregam.
- [ ] Os slots de imagem mostram "Imagem em preparação" (sem ícone de imagem quebrada).
- [ ] Logotipo em texto "LIFEFORM" aparece sem espaço vazio antes dele.

## 5. Checklist de autenticação (Safari no iPhone, sem Supabase configurado)

Com o deploy verde (testes novos incluídos), abra o endereço da Vercel:

- [ ] `/` mostra a abertura com título, os dois botões ("Iniciar avaliação" e "Já tenho conta"), os 3 pilares e "Como funciona".
- [ ] Ao lado de "LIFEFORM" aparece uma moldura tracejada vazia (reserva do símbolo). Não há imagem de enfeite no fundo, só gradiente.
- [ ] A animação de entrada roda uma vez e os anéis geométricos giram bem devagar.
- [ ] `/cadastro`: aviso "O acesso ainda não está ativo neste ambiente".
- [ ] Tocar em **Criar conta** com tudo vazio mostra os erros em cada campo, o aviso "Revise os campos destacados" e leva o foco ao primeiro campo com erro.
- [ ] Ao tocar nos campos, o Safari **não dá zoom** na página.
- [ ] E-mail inválido, senha curta, senha só com letras, senhas diferentes e caixa de maioridade desmarcada mostram a mensagem certa.
- [ ] "Mostrar/Ocultar" altera a visibilidade da senha.
- [ ] Com tudo válido, tocar em **Criar conta** mostra o carregamento e depois o erro "O acesso ainda não está ativo neste ambiente".
- [ ] `/entrar`: validação de e-mail e senha vazios; mesmo comportamento sem Supabase.
- [ ] `/avaliacao`: mostra o aviso de acesso inativo (sem Supabase).
- [ ] Nenhuma rolagem horizontal; nenhum conteúdo escondido atrás do notch ou da barra inferior.

Com o Supabase configurado (ver `docs/AUTH.md`): criar conta → (confirmar e-mail) → entrar → `/avaliacao` mostra seu nome e e-mail → **Sair** volta para `/entrar`.

## 6. Checklist da avaliação

- [ ] Com Supabase configurado e sessão autenticada, `/avaliacao` abre a introdução do questionário.
- [ ] A introdução explica duração aproximada, 22 perguntas essenciais e aprofundamentos condicionais.
- [ ] A privacidade informa que as respostas ficam no armazenamento local deste navegador até a integração do banco.
- [ ] As perguntas permitem voltar, responder, pular aprofundamentos opcionais e ver o progresso.
- [ ] As perguntas condicionais aparecem conforme as respostas e desaparecem/recalculam quando uma resposta anterior muda.
- [ ] Idade, altura e peso rejeitam valores fora dos intervalos apresentados.
- [ ] A conclusão informa que as respostas foram salvas localmente, sem afirmar que já existe diagnóstico.
- [ ] Apagar avaliação remove o rascunho local e permite recomeçar.

## 7. Lembretes

- A logo e as imagens não bloqueiam a validação técnica; entram depois em `public/brand/` e `public/images/`.
- Ao trocar uma imagem mantendo o nome, o navegador pode levar até 1 dia para renovar o cache.
- Login real, persistência remota, diagnóstico, gráficos e motor ainda dependem das próximas integrações e não devem ser considerados validados nesta etapa.

## Validação estática do esquema Supabase

Execute `npm run validate:schema` para conferir a presença das 12 tabelas centrais, das políticas de propriedade por `auth.uid()`, das políticas especiais de `profiles` e do gatilho de criação do perfil. Esta checagem estática não substitui executar a migração em um projeto Supabase de teste nem validar RLS com duas contas distintas.


## Revisão de experiência — 12/11/2026

- [x] Verificação de sintaxe TypeScript/JSX dos componentes de jornada e organizador de treinos via `typescript.transpileModule`.
- [x] Validação estática do esquema Supabase (12 tabelas e políticas RLS).
- [ ] Instalação de dependências, Vitest, ESLint e build de produção (instalação excedeu 120s no ambiente desta revisão).
- [ ] Troca real entre duas contas no navegador e validação de isolamento ponta a ponta.
- [ ] Teste Safari/iPhone e desktop.

## Revisão 12/11/2026 — progressão por perfil e prontidão semanal

- [x] Sintaxe TSX/TypeScript dos arquivos alterados verificada via transpiler TypeScript.
- [x] Validação estática do esquema Supabase: 12 tabelas e políticas RLS.
- [ ] Vitest completo (dependências não instaladas nesta rodada).
- [ ] ESLint, typecheck completo e build de produção.
- [ ] Troca de duas contas reais e confirmação de fase no Safari/iPhone.
