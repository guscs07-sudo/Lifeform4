# Módulos de jornada — Etapa 5

## Implementado nesta entrega

- Registro manual de atividades com nome, duração, data do registro e observação opcional.
- Histórico local de atividades, com opção de exclusão.
- Cadastro de hábitos diários ou semanais e marcação de conclusão por dia.
- Cadastro de metas, descrição opcional e marcação de conclusão.
- Visão geral com contagens calculadas a partir dos registros do usuário.
- Missão semanal de registrar três atividades, com progresso calculado a partir do histórico real.
- Conquistas desbloqueadas por critérios objetivos derivados dos registros reais.
- XP calculado por atividades, conclusões de hábitos e metas concluídas.

## Limites conhecidos

- Os dados são armazenados no `localStorage`, separados pelo ID do usuário autenticado neste dispositivo. Não há sincronização entre aparelhos nem persistência no servidor nesta etapa.
- O módulo de atividades é um diário de atividades realizadas. Ele não prescreve exercícios, cargas, séries ou intensidade. Programas de treino personalizados exigem regras de segurança, dados suficientes e validação específica antes de serem disponibilizados.
- A missão semanal é uma meta genérica de registro, não uma recomendação médica ou obrigação de exercício. Deve ser adaptada ou ignorada quando não for apropriada.
- Os dados do navegador podem ser apagados pelo usuário ou pelo sistema operacional. A sincronização e backup serão tratados na integração de banco de dados.
- XP e conquistas são elementos de engajamento, não medidas de saúde ou desempenho clínico.

## Privacidade

A chave de armazenamento inclui o ID retornado pela autenticação para separar os dados locais entre contas usadas no mesmo navegador. Isso não substitui autorização e isolamento no banco de dados, que serão implementados na etapa de integração.

## Módulo de treinos (implementação local)

A área `Treinos` inclui uma biblioteca educativa de movimentos com instruções em etapas e observações de segurança, seleção de exercícios para um registro, campos de duração/séries/repetições/carga opcional, observações e histórico. Os registros são salvos no `localStorage` por usuário neste estágio; ainda não há sincronização com Supabase. A biblioteca não é uma prescrição individual e não determina cargas ou frequência adequadas ao usuário. O usuário registra somente o que realizou.

## Exportação local de dados

A visão geral oferece exportação dos registros locais do perfil autenticado em JSON (`formatVersion: 1`). O arquivo inclui atividades, hábitos, metas e sessões de treino, além do identificador do perfil e da data de exportação. Ele é um backup portátil, não uma sincronização nem uma importação automática. Como pode conter dados pessoais, o usuário recebe um aviso para armazená-lo em local privado. A exportação é executada no navegador e não envia os dados para terceiros.

## Proteção ao trocar de perfil no mesmo navegador

Ao trocar a conta sem desmontar a área da jornada, o componente limpa o estado anterior, carrega os registros vinculados ao novo identificador e só permite persistir quando a chave carregada corresponde ao perfil ativo. Isso evita que dados locais de uma conta sejam reaproveitados ou gravados sob a chave de outra conta. A validação ponta a ponta com duas contas reais continua pendente.
