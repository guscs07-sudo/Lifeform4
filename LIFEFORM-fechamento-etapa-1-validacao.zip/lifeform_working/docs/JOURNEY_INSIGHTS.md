# Visão integrada da jornada

O módulo `src/lib/progress/journeyInsights.ts` consolida registros locais de atividades, hábitos, metas e a revisão semanal atual em um resumo descritivo para o painel.

## Regras

- Considera a semana iniciada na segunda-feira, usando a data local do dispositivo.
- Conta atividades e marcações de hábitos dentro da semana atual.
- Resume metas concluídas e em aberto.
- Só usa a revisão semanal quando `weekOf` corresponde à semana atual.
- Prioriza recuperação quando a energia está baixa ou a recuperação foi marcada como ruim.
- Recomenda simplificar quando a rotina está corrida ou as atividades foram percebidas como pesadas.
- Na ausência desses sinais, sugere manter o ritmo registrado ou começar com um passo possível.

O resumo não é diagnóstico, avaliação clínica ou prescrição de treino. Não calcula carga nem aumenta automaticamente a intensidade. Os dados continuam no armazenamento local por perfil nesta etapa; sincronização segura com Supabase ainda é uma etapa futura.

## Testes

`src/lib/progress/journeyInsights.test.ts` cobre contagem semanal, foco em recuperação, simplificação, descarte de revisão antiga e resumo de metas.


## Integração com o diagnóstico inicial

O painel passa a encaminhar ao gerador do plano o pilar prioritário calculado por `buildDiagnosis`. Assim, a seção “Foco escolhido” reflete a leitura integrada das respostas (incluindo sinais observáveis dos três pilares), em vez de depender exclusivamente da preferência informada em `priority_pillar`. A preferência declarada continua sendo considerada pelo diagnóstico e pode prevalecer quando está próxima do menor indicador.
