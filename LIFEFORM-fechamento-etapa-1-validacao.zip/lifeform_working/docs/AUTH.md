# Autenticação (Etapa 2)

## Como está organizada

```
src/lib/auth/
  types.ts        contrato AuthService (signUp, signIn, signOut, getUser) e códigos de erro
  validation.ts   validação pura dos formulários (devolve chaves de tradução)
  errors.ts       erros do provedor -> códigos internos estáveis
  service.ts      implementação com Supabase (ou serviço "não configurado")
src/lib/supabase/browser.ts   cliente Supabase do navegador, criado sob demanda
src/lib/env.ts                leitura segura das variáveis (recusa chave secreta no navegador)
src/features/auth/            formulários, moldura das telas, hook useAuthService
src/features/assessment/      AssessmentGate: controle de sessão e entrada no questionário adaptativo
```

Telas e rotas: `/` (apresentação), `/cadastro`, `/entrar`, `/avaliacao` (provisória).

## Comportamento sem Supabase configurado

Nada é simulado. Os formulários validam normalmente, exibem um aviso de que o acesso ainda não está ativo e, ao enviar, mostram "O acesso ainda não está ativo neste ambiente". Nenhuma conta falsa é criada.

## Independência do OPERAÇÃO TAF

O código não contém URL, chave ou referência de outro projeto. Tudo vem de `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_ANON_KEY` do **projeto Supabase novo do LIFEFORM**. Se alguém colocar uma chave `service_role`/`sb_secret_` nessa variável, ela é recusada e um erro aparece no console.

## Ativar o login de verdade (opcional agora, obrigatório antes do lançamento)

1. Crie um projeto novo no Supabase (plano gratuito), separado do OPERAÇÃO TAF.
2. *Project Settings → API*: copie **Project URL** e a chave **anon / publishable**. Nunca use a `service_role`.
3. Na Vercel: *Project → Settings → Environment Variables*, adicione `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_ANON_KEY` (Production, Preview e Development) e faça um novo deploy.
4. *Authentication → URL Configuration* no Supabase:
   - **Site URL**: o endereço do app na Vercel (ex.: `https://seu-app.vercel.app`).
   - **Redirect URLs**: `https://seu-app.vercel.app/**`.
5. *Authentication → Providers → Email*: mantenha "Confirm email" ligado (recomendado). O app trata os dois cenários: com confirmação mostra "Confirme seu e-mail"; sem confirmação, entra direto.

## Limitações conhecidas desta etapa

- **Maioridade:** a caixa "Declaro ter 18 anos ou mais" é gravada nos metadados da conta, mas metadados podem ser alterados pelo próprio usuário. A trava confiável (campo em `profiles` com `check` no banco) será implementada na integração de banco de dados.
- **Sessão:** guardada pelo cliente do navegador. Proteção de rotas no servidor (middleware) e leitura da sessão em Server Components entram na Etapa 7.
- **Link do e-mail de confirmação:** precisa ser aberto no mesmo navegador em que o cadastro foi feito. Em outro navegador, a conta fica confirmada, mas é preciso entrar manualmente em `/entrar`.
- **Termos de uso e política de privacidade:** ainda não existem textos. Antes do lançamento público é preciso redigi-los e acrescentar o aceite no cadastro.
- **Recuperação de senha:** não faz parte desta etapa e não foi implementada.
