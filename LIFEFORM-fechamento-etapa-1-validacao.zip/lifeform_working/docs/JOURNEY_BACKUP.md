# Backup local da jornada

A área de jornada permite exportar os registros deste navegador em JSON e importar um backup compatível.

## Segurança e compatibilidade

- O arquivo é limitado a 5 MB na importação.
- O formato precisa identificar `LIFEFORM` e `formatVersion: 1`.
- O `userId` do arquivo precisa corresponder ao perfil atualmente aberto; backups de outro perfil são recusados.
- Os registros são validados antes de alterar o estado local.
- A importação substitui os registros locais do perfil somente após confirmação explícita.
- A exportação contém dados pessoais e deve ser guardada em local privado.

Este mecanismo é uma cópia local e não substitui a sincronização autenticada do Supabase, que permanece pendente na etapa de infraestrutura.
