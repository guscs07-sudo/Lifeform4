# Arquitetura do LIFEFORM

## Princípios

1. **Motor próprio primeiro, IA depois.** Todo o fluxo (validação → segurança → perfil → fase → programa → revisão semanal) é TypeScript puro, determinístico e testável, sem rede.
2. **Segurança acima de personalização.** Bloqueios de saúde são calculados pelo motor. Nem a IA nem o front-end podem desfazê-los.
3. **Dados por conteúdo, não por código.** Perguntas, exercícios, hábitos, conquistas e imagens são estruturas tipadas. Mudar conteúdo não exige mexer em lógica.
4. **Privacidade por padrão.** Cada tabela do usuário tem RLS; o navegador só usa a anon key.
5. **Custo zero obrigatório.** IA é opcional e só roda em função de servidor com chave em variável de ambiente.

## Camadas

```
UI (components, features)
   ↓ usa
Estado e persistência (autosave local + Supabase)
   ↓ chama
Motor (src/lib/engine)  ←  Conteúdo (perguntas, exercícios, hábitos)
   ↓ opcionalmente
Rota de servidor de IA (somente explica/adapta comunicação)
```

## Motor de inteligência e diagnóstico (próxima entrega)

Pipeline em funções puras, cada uma com testes:

| # | Passo | Entrada → Saída |
|---|-------|-----------------|
| 1 | validate | respostas brutas → respostas válidas + erros |
| 2 | safety | respostas → `SafetyResult` (`clear`, `caution`, `block_intense`, `needs_professional`) |
| 3 | goals | respostas → objetivos priorizados |
| 4 | experience | respostas → nível de experiência |
| 5 | constraints | equipamentos, dias, tempo → restrições |
| 6 | priorities | pilar prioritário + lacunas |
| 7 | phase | perfil + histórico → fase da jornada (critérios reais) |
| 8 | program | tudo acima + biblioteca → programa semanal |
| 9 | weekly | dados da semana → ajuste (nunca aumenta carga automaticamente) |

Regra: se `safety` retornar `needs_professional`, o gerador não produz sessões intensas e a UI mostra a orientação de procurar avaliação profissional. Não há diagnóstico.

## Questionário adaptativo (implementado nesta entrega)

Definido por dados: cada pergunta tem `id`, `module`, `format` (`image_cards`, `single`, `multi`, `scale`, `slider`, `open`, `time`, `weekdays`, `visual_compare`), `required`, `showIf` (condição sobre respostas), opções e `imageSlot`. Um renderizador por formato; autosave a cada resposta; retomada pelo último índice respondido; voltar e corrigir recalcula quais perguntas condicionais continuam visíveis.

## Modelo de dados planejado (SQL e integração na etapa de banco de dados)

Todas as tabelas têm `user_id uuid references auth.users` e RLS `auth.uid() = user_id`.

| Tabela | Conteúdo |
|--------|----------|
| `profiles` | nome, data de nascimento (validação 18+), idioma, fase atual, XP, nível |
| `assessment_sessions` | status, versão do questionário, último passo |
| `assessment_answers` | `session_id`, `question_id`, valor (jsonb), atualizado em |
| `safety_flags` | resultado da triagem, motivos, versão das regras |
| `programs` | versão, fase, parâmetros usados na geração |
| `program_sessions` | treinos planejados por dia (exercícios da biblioteca) |
| `workout_logs` | treino concluído, esforço percebido, notas |
| `habit_logs` | hábito, data, concluído |
| `missions` / `mission_progress` | missões diárias e semanais |
| `xp_events` | histórico auditável de XP |
| `achievements_unlocked` | conquistas liberadas |
| `weekly_reviews` | métricas da semana e ajustes aplicados |
| `user_preferences` | incentivo preferido, lembretes, tema |

Bibliotecas de exercícios e hábitos ficam em JSON versionado no repositório (leitura pública, sem dados pessoais). Se precisarem virar tabelas, terão RLS de somente leitura.

## Segurança

- Anon key no navegador; `service_role` nunca usada.
- RLS em todas as tabelas com dados do usuário, com políticas separadas para `select`, `insert`, `update`, `delete`.
- Maioridade (18+) validada no cadastro e reforçada por `check` no banco.
- Cabeçalhos de segurança em `next.config.mjs`.
- IA: rota de servidor; resposta passa pelo motor de segurança antes de chegar ao usuário.

## PWA e offline (entrega futura)

Manifest, ícones a partir da logo oficial, service worker com cache de shell e imagens, fila local de respostas quando offline.
