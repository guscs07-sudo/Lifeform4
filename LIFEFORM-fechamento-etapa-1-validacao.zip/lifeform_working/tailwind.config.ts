import type { Config } from "tailwindcss";

/**
 * Tokens do LIFEFORM.
 * ATENÇÃO: o laranja abaixo é provisório. Quando o arquivo da logo aprovada
 * for adicionado, o valor exato deve ser extraído dela e atualizado aqui
 * (e em src/styles/globals.css, variável --lf-accent).
 */
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        lf: {
          ink: "#07070A", // preto profundo
          graphite: {
            950: "#0C0D10",
            900: "#111216",
            800: "#181A1F",
            700: "#22252B",
            600: "#2E3239",
          },
          gray: {
            500: "#6B7078",
            400: "#8A8F98",
            300: "#B1B5BC",
            200: "#D3D6DB",
          },
          white: "#F5F5F2",
          accent: {
            DEFAULT: "#FF6A1A",
            soft: "#FF8A4C",
            deep: "#D9500A",
          },
          success: "#3DDC97",
          warning: "#FFC24D",
          danger: "#FF5A5F",
        },
      },
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        display: ["var(--font-display)", "var(--font-sans)", "sans-serif"],
      },
      borderRadius: {
        card: "20px",
      },
      boxShadow: {
        glow: "0 0 40px -8px rgba(255, 106, 26, 0.45)",
        card: "0 10px 40px -20px rgba(0, 0, 0, 0.8)",
      },
      keyframes: {
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "spin-slow": {
          "0%": { transform: "rotate(0deg)" },
          "100%": { transform: "rotate(360deg)" },
        },
      },
      animation: {
        shimmer: "shimmer 1.8s linear infinite",
        "fade-up": "fade-up 0.7s ease-out both",
        "spin-slow": "spin-slow 90s linear infinite",
      },
    },
  },
  plugins: [],
};

export default config;
