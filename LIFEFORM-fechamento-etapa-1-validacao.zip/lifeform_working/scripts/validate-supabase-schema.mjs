import { readFileSync } from 'node:fs';

const migrationPath = new URL('../supabase/migrations/202611120001_lifeform_core.sql', import.meta.url);
const sql = readFileSync(migrationPath, 'utf8');
const requiredTables = [
  'profiles', 'assessments', 'journey_states', 'weekly_reviews', 'activity_logs',
  'habits', 'habit_completions', 'goals', 'workout_plans', 'workout_sessions',
  'achievements', 'mission_progress',
];
const missingTables = requiredTables.filter((name) => !new RegExp(`create table if not exists public\\.${name}\\s*\\(`, 'i').test(sql));
const hasDynamicRls = /alter table public\.%I enable row level security/i.test(sql)
  && /create policy owner_select on public\.%I for select to authenticated using \(auth\.uid\(\) = user_id\)/i.test(sql)
  && /create policy owner_insert on public\.%I for insert to authenticated with check \(auth\.uid\(\) = user_id\)/i.test(sql)
  && /create policy owner_update on public\.%I for update to authenticated using \(auth\.uid\(\) = user_id\) with check \(auth\.uid\(\) = user_id\)/i.test(sql)
  && /create policy owner_delete on public\.%I for delete to authenticated using \(auth\.uid\(\) = user_id\)/i.test(sql);
const profilePolicies = ['select', 'insert', 'update', 'delete'].every((action) =>
  new RegExp(`create policy owner_${action} on public\\.profiles for ${action} to authenticated`, 'i').test(sql),
);
const hasAuthTrigger = /create trigger on_auth_user_created_lifeform\s+after insert on auth\.users/i.test(sql);
const hasNoPublicSecrets = !/service_role|sb_secret_/i.test(sql);

if (missingTables.length || !hasDynamicRls || !profilePolicies || !hasAuthTrigger || !hasNoPublicSecrets) {
  console.error(JSON.stringify({ missingTables, hasDynamicRls, profilePolicies, hasAuthTrigger, hasNoPublicSecrets }, null, 2));
  process.exit(1);
}

console.log(`Supabase schema static validation passed: ${requiredTables.length} tables, owner RLS policies, profile policies and auth trigger.`);
