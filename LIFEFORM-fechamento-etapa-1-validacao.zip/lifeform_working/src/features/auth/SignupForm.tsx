"use client";

import { useRouter } from "next/navigation";
import { useMemo, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { Button, buttonClasses } from "@/components/ui/Button";
import { Checkbox } from "@/components/ui/Checkbox";
import { FormAlert } from "@/components/ui/FormAlert";
import { TextField } from "@/components/ui/TextField";
import { SuccessState } from "@/components/ui/StateViews";
import { t } from "@/i18n";
import {
  validateSignup,
  type FieldErrors,
  type SignupField,
} from "@/lib/auth/validation";
import Link from "next/link";
import { useAuthService } from "./useAuthService";
import { getSafePostAuthRedirect } from "@/lib/auth/protectedRoutes";

type TextValues = Record<"name" | "email" | "password" | "confirmPassword", string>;

export function SignupForm() {
  const router = useRouter();
  const auth = useAuthService();
  const formRef = useRef<HTMLFormElement>(null);

  const [values, setValues] = useState<TextValues>({ name: "", email: "", password: "", confirmPassword: "" });
  const [ageConfirmed, setAgeConfirmed] = useState(false);
  const [touched, setTouched] = useState<Partial<Record<SignupField, boolean>>>({});
  const [attempted, setAttempted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [confirmedEmail, setConfirmedEmail] = useState<string | null>(null);

  const validation = useMemo(() => validateSignup({ ...values, ageConfirmed }), [values, ageConfirmed]);
  const errors: FieldErrors<SignupField> = validation.ok ? {} : validation.errors;

  const fieldError = (field: SignupField): string | undefined => {
    const key = attempted || touched[field] ? errors[field] : undefined;
    return key ? t(key) : undefined;
  };

  const onText = (field: keyof TextValues) => (event: ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    setValues((prev) => ({ ...prev, [field]: value }));
  };
  const onBlur = (field: SignupField) => () => setTouched((prev) => ({ ...prev, [field]: true }));

  const focusFirstInvalid = () => {
    setTimeout(() => {
      formRef.current?.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus();
    }, 0);
  };

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting) return;
    setAttempted(true);
    setFormError(null);

    if (!validation.ok) {
      focusFirstInvalid();
      return;
    }

    setSubmitting(true);
    const result = await auth.signUp(validation.value);

    if (!result.ok) {
      setSubmitting(false);
      setFormError(`auth.errors.${result.error}`);
      return;
    }
    if (result.data.status === "signed_in") {
      router.replace(getSafePostAuthRedirect(new URLSearchParams(window.location.search).get("next"))); // mantém o carregamento até a navegação
      return;
    }
    setSubmitting(false);
    setConfirmedEmail(validation.value.email);
  }

  if (confirmedEmail) {
    return (
      <SuccessState
        title={t("auth.signup.successTitle")}
        description={t("auth.signup.successText", { email: confirmedEmail })}
        action={
          <Link href="/entrar" className={buttonClasses({ size: "lg" })}>
            {t("auth.signup.goLogin")}
          </Link>
        }
      />
    );
  }

  const hasVisibleErrors = attempted && !validation.ok;

  return (
    <form ref={formRef} onSubmit={onSubmit} noValidate className="flex flex-col gap-5">
      {!auth.isConfigured && <FormAlert variant="info">{t("auth.notice.notConfigured")}</FormAlert>}

      <TextField
        label={t("auth.signup.name")}
        name="name"
        value={values.name}
        onChange={onText("name")}
        onBlur={onBlur("name")}
        error={fieldError("name")}
        placeholder={t("auth.signup.namePlaceholder")}
        autoComplete="name"
        autoCapitalize="words"
        enterKeyHint="next"
        disabled={submitting}
      />
      <TextField
        label={t("auth.signup.email")}
        name="email"
        type="email"
        inputMode="email"
        value={values.email}
        onChange={onText("email")}
        onBlur={onBlur("email")}
        error={fieldError("email")}
        placeholder={t("auth.signup.emailPlaceholder")}
        autoComplete="email"
        autoCapitalize="none"
        autoCorrect="off"
        spellCheck={false}
        enterKeyHint="next"
        disabled={submitting}
      />
      <TextField
        label={t("auth.signup.password")}
        name="password"
        revealable
        value={values.password}
        onChange={onText("password")}
        onBlur={onBlur("password")}
        error={fieldError("password")}
        hint={t("auth.hints.password")}
        autoComplete="new-password"
        enterKeyHint="next"
        disabled={submitting}
      />
      <TextField
        label={t("auth.signup.confirmPassword")}
        name="confirmPassword"
        revealable
        value={values.confirmPassword}
        onChange={onText("confirmPassword")}
        onBlur={onBlur("confirmPassword")}
        error={fieldError("confirmPassword")}
        autoComplete="new-password"
        enterKeyHint="done"
        disabled={submitting}
      />
      <Checkbox
        name="ageConfirmed"
        checked={ageConfirmed}
        onChange={(event) => setAgeConfirmed(event.target.checked)}
        onBlur={onBlur("ageConfirmed")}
        label={t("auth.signup.ageConfirm")}
        error={fieldError("ageConfirmed")}
        disabled={submitting}
      />

      {hasVisibleErrors && <FormAlert variant="warning">{t("auth.formSummary")}</FormAlert>}
      {formError && <FormAlert variant="error">{t(formError)}</FormAlert>}

      <Button type="submit" size="lg" fullWidth loading={submitting}>
        {submitting ? t("auth.signup.submitting") : t("auth.signup.submit")}
      </Button>
    </form>
  );
}
