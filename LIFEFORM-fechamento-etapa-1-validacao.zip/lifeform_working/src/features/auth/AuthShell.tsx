import Link from "next/link";
import type { ReactNode } from "react";
import { Logo } from "@/components/brand/Logo";
import { t } from "@/i18n";

interface AuthShellProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
}

/** Moldura comum das telas de cadastro, login e área provisória da avaliação. */
export function AuthShell({ title, subtitle, children, footer }: AuthShellProps) {
  return (
    <main className="lf-grid-bg mx-auto flex w-full max-w-md flex-1 flex-col gap-8 px-5 pb-10 pt-6">
      <header>
        <Link href="/" aria-label={t("auth.backHome")} className="inline-flex min-h-11 items-center">
          <Logo />
        </Link>
      </header>
      <div className="flex flex-col gap-2 animate-fade-up">
        <h1 className="font-display text-3xl font-semibold leading-tight">{title}</h1>
        {subtitle && <p className="text-lf-gray-300">{subtitle}</p>}
      </div>
      {children}
      {footer && <div className="text-center text-sm text-lf-gray-300">{footer}</div>}
    </main>
  );
}
