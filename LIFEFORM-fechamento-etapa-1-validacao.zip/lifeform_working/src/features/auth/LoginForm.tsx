"use client";

import { useRouter } from "next/navigation";
import { useMemo, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { Button } from "@/components/ui/Button";
import { FormAlert } from "@/components/ui/FormAlert";
import { TextField } from "@/components/ui/TextField";
import { t } from "@/i18n";
import { validateLogin, type FieldErrors, type LoginField } from "@/lib/auth/validation";
import { useAuthService } from "./useAuthService";
import { getSafePostAuthRedirect } from "@/lib/auth/protectedRoutes";

export function LoginForm() {
  const router = useRouter();
  const auth = useAuthService();
  const formRef = useRef<HTMLFormElement>(null);

  const [values, setValues] = useState({ email: "", password: "" });
  const [touched, setTouched] = useState<Partial<Record<LoginField, boolean>>>({});
  const [attempted, setAttempted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const validation = useMemo(() => validateLogin(values), [values]);
  const errors: FieldErrors<LoginField> = validation.ok ? {} : validation.errors;

  const fieldError = (field: LoginField): string | undefined => {
    const key = attempted || touched[field] ? errors[field] : undefined;
    return key ? t(key) : undefined;
  };

  const onChange = (field: LoginField) => (event: ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    setValues((prev) => ({ ...prev, [field]: value }));
  };
  const onBlur = (field: LoginField) => () => setTouched((prev) => ({ ...prev, [field]: true }));

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting) return;
    setAttempted(true);
    setFormError(null);

    if (!validation.ok) {
      setTimeout(() => {
        formRef.current?.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus();
      }, 0);
      return;
    }

    setSubmitting(true);
    const result = await auth.signIn(validation.value);
    if (!result.ok) {
      setSubmitting(false);
      setFormError(`auth.errors.${result.error}`);
      return;
    }
    router.replace(getSafePostAuthRedirect(new URLSearchParams(window.location.search).get("next"))); // mantém o carregamento até a navegação
  }

  return (
    <form ref={formRef} onSubmit={onSubmit} noValidate className="flex flex-col gap-5">
      {!auth.isConfigured && <FormAlert variant="info">{t("auth.notice.notConfigured")}</FormAlert>}

      <TextField
        label={t("auth.login.email")}
        name="email"
        type="email"
        inputMode="email"
        value={values.email}
        onChange={onChange("email")}
        onBlur={onBlur("email")}
        error={fieldError("email")}
        autoComplete="email"
        autoCapitalize="none"
        autoCorrect="off"
        spellCheck={false}
        enterKeyHint="next"
        disabled={submitting}
      />
      <TextField
        label={t("auth.login.password")}
        name="password"
        revealable
        value={values.password}
        onChange={onChange("password")}
        onBlur={onBlur("password")}
        error={fieldError("password")}
        autoComplete="current-password"
        enterKeyHint="go"
        disabled={submitting}
      />

      {formError && <FormAlert variant="error">{t(formError)}</FormAlert>}

      <Button type="submit" size="lg" fullWidth loading={submitting}>
        {submitting ? t("auth.login.submitting") : t("auth.login.submit")}
      </Button>
    </form>
  );
}
