"use client";

import { useMemo } from "react";
import { createAuthService } from "@/lib/auth/service";
import type { AuthService } from "@/lib/auth/types";

/** Acesso ao serviço de autenticação nos componentes de cliente. */
export function useAuthService(): AuthService {
  return useMemo(() => createAuthService(), []);
}
