"use client";

import { useEffect, useMemo, useState } from "react";
import { getSupabaseBrowserClient } from "@/lib/supabase/browser";
import { assessmentDraftsMatch, hasAssessmentData, isAssessmentAnswers, type AssessmentDraft, type CloudAssessment } from "@/lib/assessment/cloudAssessment";

 type Mode = "checking" | "unavailable" | "empty" | "local-only" | "conflict" | "synced" | "syncing" | "error";

/** Sincronização deliberada da avaliação: conflitos nunca são resolvidos por sobrescrita automática. */
export function AssessmentCloudSync({ userId, localDraft, ready, onLoadCloud }: {
  userId: string;
  localDraft: AssessmentDraft | null;
  ready: boolean;
  onLoadCloud: (draft: AssessmentDraft) => void;
}) {
  const [mode, setMode] = useState<Mode>("checking");
  const [cloudRecord, setCloudRecord] = useState<CloudAssessment | null>(null);
  const [message, setMessage] = useState("Verificando a cópia da avaliação na nuvem…");
  const localHasData = useMemo(() => hasAssessmentData(localDraft), [localDraft]);
  const isDirty = Boolean(cloudRecord && localDraft && !assessmentDraftsMatch(localDraft, cloudRecord));

  useEffect(() => {
    let active = true;
    async function inspect() {
      if (!ready) return;
      const supabase = getSupabaseBrowserClient();
      if (!supabase) {
        if (active) { setMode("unavailable"); setMessage("Supabase ainda não configurado. A avaliação continua salva neste aparelho."); }
        return;
      }
      const { data, error } = await supabase.from("assessments")
        .select("id, answers, status, completed_at, updated_at")
        .eq("user_id", userId).order("updated_at", { ascending: false }).limit(1).maybeSingle();
      if (!active) return;
      if (error) { setMode("error"); setMessage("Não foi possível consultar a avaliação na nuvem. Seus dados locais foram preservados."); return; }
      if (!data) {
        setMode(localHasData ? "local-only" : "empty");
        setMessage(localHasData ? "Sua avaliação está neste aparelho e ainda não tem cópia na nuvem." : "Nenhuma avaliação encontrada. Você pode começar normalmente.");
        return;
      }
      if (!isAssessmentAnswers(data.answers) || typeof data.id !== "string") {
        setMode("error"); setMessage("A cópia remota tem um formato inesperado. Nada foi alterado."); return;
      }
      const record: CloudAssessment = { id: data.id, answers: data.answers, status: data.status === "completed" ? "completed" : "draft", completedAt: data.completed_at, updatedAt: data.updated_at };
      setCloudRecord(record);
      if (!localHasData) {
        onLoadCloud({ answers: record.answers, updatedAt: record.updatedAt, ...(record.completedAt ? { completedAt: record.completedAt } : {}) });
        setMode("synced"); setMessage("Sua avaliação foi recuperada da nuvem para este aparelho.");
      } else if (assessmentDraftsMatch(localDraft, record)) {
        setMode("synced"); setMessage("A avaliação deste aparelho já corresponde à cópia na nuvem.");
      } else {
        setMode("conflict"); setMessage("Encontramos versões diferentes. Escolha qual avaliação deseja manter; nenhuma será sobrescrita sem sua confirmação.");
      }
    }
    void inspect();
    return () => { active = false; };
  // A leitura inicial acontece uma vez após o rascunho local ser carregado.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, ready]);

  async function saveLocalToCloud() {
    if (!localDraft || !hasAssessmentData(localDraft)) return;
    const supabase = getSupabaseBrowserClient();
    if (!supabase) { setMode("unavailable"); setMessage("Configure o Supabase antes de sincronizar."); return; }
    setMode("syncing"); setMessage("Enviando sua avaliação com segurança…");
    const payload = { user_id: userId, version: 1, status: localDraft.completedAt ? "completed" : "draft", answers: localDraft.answers, completed_at: localDraft.completedAt ?? null };
    const result = cloudRecord
      ? await supabase.from("assessments").update(payload).eq("id", cloudRecord.id).eq("user_id", userId).select("id, answers, status, completed_at, updated_at").single()
      : await supabase.from("assessments").insert(payload).select("id, answers, status, completed_at, updated_at").single();
    if (result.error || !result.data) { setMode("error"); setMessage("Não foi possível sincronizar. Sua avaliação local continua intacta."); return; }
    const saved: CloudAssessment = { id: result.data.id, answers: result.data.answers as AssessmentDraft["answers"], status: result.data.status, completedAt: result.data.completed_at, updatedAt: result.data.updated_at };
    setCloudRecord(saved); setMode("synced"); setMessage("Avaliação sincronizada com a conta LIFEFORM.");
  }

  function useCloudVersion() {
    if (!cloudRecord) return;
    onLoadCloud({ answers: cloudRecord.answers, updatedAt: cloudRecord.updatedAt, ...(cloudRecord.completedAt ? { completedAt: cloudRecord.completedAt } : {}) });
    setMode("synced"); setMessage("A versão da nuvem foi carregada neste aparelho.");
  }

  if (!ready || mode === "unavailable") return <div className="rounded-xl border border-white/10 bg-white/[.03] p-3 text-xs leading-5 text-white/50" role="status">{message}</div>;
  return <section className="rounded-xl border border-[#FF762E]/20 bg-[#FF762E]/[.05] p-3" aria-label="Sincronização da avaliação">
    <p className="text-[10px] font-semibold uppercase tracking-[.16em] text-[#FF9A63]">Avaliação na nuvem</p>
    <p className="mt-1 text-xs leading-5 text-white/60" role="status">{message}</p>
    <div className="mt-2 flex flex-wrap gap-2">
      {(mode === "local-only" || mode === "empty" || mode === "error" || (mode === "synced" && isDirty)) && localHasData && <button type="button" onClick={() => void saveLocalToCloud()} className="min-h-9 rounded-lg bg-[#FF762E] px-3 text-[11px] font-bold text-black">Enviar avaliação deste aparelho</button>}
      {mode === "conflict" && <>
        <button type="button" onClick={() => void saveLocalToCloud()} className="min-h-9 rounded-lg bg-[#FF762E] px-3 text-[11px] font-bold text-black">Manter este aparelho</button>
        <button type="button" onClick={useCloudVersion} className="min-h-9 rounded-lg border border-white/15 px-3 text-[11px] font-semibold text-white/80">Usar versão da nuvem</button>
      </>}
    </div>
  </section>;
}
