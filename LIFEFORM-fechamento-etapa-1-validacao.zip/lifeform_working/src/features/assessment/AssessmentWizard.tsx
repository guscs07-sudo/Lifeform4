"use client";

import { useEffect, useMemo, useState } from "react";
import { AssetImage } from "@/components/media/AssetImage";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { getModule, type ModuleId } from "@/config/modules";
import { DiagnosisReport } from "@/features/assessment/DiagnosisReport";
import { AssessmentCloudSync } from "@/features/assessment/AssessmentCloudSync";
import type { AssessmentDraft } from "@/lib/assessment/cloudAssessment";
import { t } from "@/i18n";
import {
  getMissingRequired,
  getVisibleQuestions,
  isAnswered,
  type AssessmentAnswers,
  type AssessmentQuestion,
} from "@/lib/assessment/questions";

interface AssessmentWizardProps {
  userId: string;
}
const STORAGE_PREFIX = "lifeform:assessment:v1:";
const MODULE_COPY: Record<ModuleId, string> = {
  identity: "Vamos entender seu momento atual e o que você deseja transformar.",
  body: "Não existe ponto de partida certo ou errado. Queremos entender sua realidade.",
  training: "O melhor plano é aquele que respeita suas preferências e recursos.",
  nutrition: "Vamos conhecer seus hábitos sem julgamentos ou dietas prontas.",
  sleep: "Descanso e recuperação também fazem parte da evolução.",
  mind: "Disciplina não é perfeição. É encontrar estratégias que funcionem para você.",
  routine: "Seu programa precisa caber na vida que você realmente tem.",
  habits: "Pequenas mudanças sustentáveis podem construir uma rotina melhor.",
  health: "Estas respostas ajudam a evitar recomendações inadequadas. Não fazemos diagnósticos.",
  goals: "Vamos transformar intenção em objetivos possíveis e progressivos.",
};

export function AssessmentWizard({ userId }: AssessmentWizardProps) {
  const storageKey = `${STORAGE_PREFIX}${userId}`;
  const [answers, setAnswers] = useState<AssessmentAnswers>({});
  const [index, setIndex] = useState(0);
  const [started, setStarted] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [completedAt, setCompletedAt] = useState<string | null>(null);
  const [showPrivacy, setShowPrivacy] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) {
        const draft = JSON.parse(raw) as AssessmentDraft;
        setAnswers(draft.answers ?? {});
        setCompletedAt(draft.completedAt ?? null);
        setStarted(Object.keys(draft.answers ?? {}).length > 0);
      }
    } catch {
      // Um rascunho inválido não impede uma nova avaliação.
      try { window.localStorage.removeItem(storageKey); } catch { /* armazenamento indisponível */ }
    } finally {
      setHydrated(true);
    }
  }, [storageKey]);

  useEffect(() => {
    if (!hydrated) return;
    const draft: AssessmentDraft = { answers, updatedAt: new Date().toISOString(), ...(completedAt ? { completedAt } : {}) };
    try { window.localStorage.setItem(storageKey, JSON.stringify(draft)); } catch { /* quota ou modo privado: a avaliação continua na sessão */ }
  }, [answers, completedAt, hydrated, storageKey]);

  const questions = useMemo(() => getVisibleQuestions(answers), [answers]);
  const current = questions[Math.min(index, Math.max(questions.length - 1, 0))];
  const currentModule = current?.module ?? "identity";
  const module = getModule(currentModule);
  const answeredCount = questions.filter((question) => isAnswered(question, answers)).length;
  const progress = questions.length ? (answeredCount / questions.length) * 100 : 0;
  const missing = getMissingRequired(answers);
  const localDraft: AssessmentDraft = { answers, updatedAt: new Date().toISOString(), ...(completedAt ? { completedAt } : {}) };

  function loadCloudDraft(draft: AssessmentDraft) {
    setAnswers(draft.answers);
    setCompletedAt(draft.completedAt ?? null);
    setStarted(Object.keys(draft.answers).length > 0);
    setIndex(0);
  }

  useEffect(() => {
    if (index > questions.length - 1) setIndex(Math.max(0, questions.length - 1));
  }, [index, questions.length]);

  function updateAnswer(id: string, value: string | number | string[]) {
    setAnswers((previous) => ({ ...previous, [id]: value }));
    setCompletedAt(null);
  }
  function goNext() {
    if (!current || (current.required && !isAnswered(current, answers))) return;
    if (index < questions.length - 1) setIndex((value) => value + 1);
    else if (missing.length === 0) setCompletedAt(new Date().toISOString());
  }
  function reset() {
    setAnswers({}); setIndex(0); setStarted(false); setCompletedAt(null);
    try { window.localStorage.removeItem(storageKey); } catch { /* ignore */ }
  }
  function toggleMulti(question: AssessmentQuestion, value: string) {
    const selected = Array.isArray(answers[question.id]) ? answers[question.id] as string[] : [];
    const next = selected.includes(value) ? selected.filter((item) => item !== value) : [...selected, value];
    updateAnswer(question.id, next);
  }

  if (!hydrated) return <div className="h-56 animate-pulse rounded-card bg-lf-graphite-800" />;

  if (completedAt) {
    return (
      <div className="flex flex-col gap-5">
        <AssessmentCloudSync key={userId} userId={userId} localDraft={localDraft} ready={hydrated} onLoadCloud={loadCloudDraft} />
        <DiagnosisReport
          answers={answers}
          onReview={() => { setIndex(0); setCompletedAt(null); }}
          onRestart={reset}
        />
      </div>
    );
  }

  if (!started) {
    return (
      <div className="flex flex-col gap-5">
        <AssessmentCloudSync key={userId} userId={userId} localDraft={localDraft} ready={hydrated} onLoadCloud={loadCloudDraft} />
        <div className="relative overflow-hidden rounded-2xl border border-lf-graphite-700">
          <div className="h-52"><AssetImage slotId="anime.onboarding/welcome" fill priority /></div>
          <div className="absolute inset-0 bg-gradient-to-t from-lf-ink via-lf-ink/30 to-transparent" />
          <div className="absolute bottom-0 p-5">
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-lf-accent">LIFEFORM · ASSESSMENT</span>
            <h2 className="mt-2 font-display text-3xl font-semibold">Sua jornada começa com você.</h2>
          </div>
        </div>
        <Card>
          <h3 className="font-display text-xl font-semibold">Uma avaliação que se adapta às suas respostas.</h3>
          <p className="mt-2 text-sm leading-6 text-lf-gray-300">São 22 perguntas essenciais, distribuídas em 10 módulos, com perguntas extras apenas quando forem relevantes. Reserve cerca de 5 a 10 minutos. Você pode pausar e continuar depois neste dispositivo.</p>
          <div className="mt-4 flex flex-wrap gap-2">{["Corpo", "Mente", "Estilo de vida"].map((label) => <span key={label} className="rounded-full border border-lf-graphite-600 px-3 py-1 text-xs text-lf-gray-300">{label}</span>)}</div>
        </Card>
        <Card className="border-lf-accent/40">
          <button type="button" className="flex w-full items-start gap-3 text-left" onClick={() => setShowPrivacy((value) => !value)} aria-expanded={showPrivacy}>
            <span className="mt-0.5 text-lf-accent">ⓘ</span><span className="flex-1"><strong className="text-sm">Privacidade das respostas</strong><span className="mt-1 block text-xs text-lf-gray-400">Leia como seus dados serão armazenados nesta versão.</span></span><span className="text-lf-gray-400">{showPrivacy ? "−" : "+"}</span>
          </button>
          {showPrivacy && <p className="mt-3 border-t border-lf-graphite-700 pt-3 text-xs leading-5 text-lf-gray-300">As respostas ficam salvas neste dispositivo. Quando o Supabase do LIFEFORM estiver configurado, você poderá enviar uma cópia para sua conta ou recuperar uma avaliação da nuvem. Se houver versões diferentes, o aplicativo pedirá que você escolha antes de substituir qualquer uma. Evite preencher em aparelhos compartilhados.</p>}
        </Card>
        <Button fullWidth size="lg" onClick={() => setStarted(true)}>Começar avaliação <span aria-hidden>→</span></Button>
      </div>
    );
  }

  if (!current) return null;
  const selected = answers[current.id];
  return (
    <div className="flex flex-col gap-5">
      <AssessmentCloudSync key={userId} userId={userId} localDraft={localDraft} ready={hydrated} onLoadCloud={loadCloudDraft} />
      <div className="flex items-center justify-between text-[11px] font-medium tracking-[0.16em] text-lf-gray-400"><span>MÓDULO {String(module.number).padStart(2, "0")} · {t(module.titleKey).toUpperCase()}</span><span>{String(index + 1).padStart(2, "0")} / {questions.length}</span></div>
      <ProgressBar value={progress} label="Progresso da avaliação" />
      <section className="lf-assessment-scene relative isolate min-h-[260px] overflow-hidden rounded-2xl border border-white/10 sm:min-h-[330px]">
        <AssetImage slotId={`anime.modules/${String(module.number).padStart(2, "0")}-${module.id}`} fill priority quietFallback className="absolute inset-0 !rounded-none" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#08090d] via-[#08090d]/35 to-black/5" />
        <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7">
          <span className="inline-flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.24em] text-lf-accent"><span className="h-1.5 w-1.5 rounded-full bg-lf-accent shadow-[0_0_12px_#ff6a1a]" /> {current.required ? "Ponto de partida" : "Vamos aprofundar"}</span>
          <p className="mt-2 max-w-md font-display text-2xl font-semibold leading-tight text-white sm:text-3xl">{MODULE_COPY[currentModule]}</p>
        </div>
        <div aria-hidden className="pointer-events-none absolute right-5 top-5 h-16 w-16 rounded-full border border-white/15 sm:h-24 sm:w-24"><div className="absolute inset-2 rounded-full border border-lf-accent/30" /></div>
      </section>
      <section className="lf-question-panel rounded-2xl border border-white/10 bg-[#111216] p-5 shadow-2xl sm:p-7">
        <div className="mb-3 flex items-center justify-between gap-3"><span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-lf-gray-400">{current.required ? "Pergunta essencial" : "Pergunta complementar"}</span><span className="text-[10px] text-lf-gray-500">Resposta rápida</span></div>
        <h2 className="font-display text-[1.65rem] font-semibold leading-tight tracking-tight text-white sm:text-3xl">{current.title}</h2>
        {current.description && <p className="mt-2 max-w-xl text-sm leading-6 text-lf-gray-400">{current.description}</p>}
        <div className="mt-5 space-y-2.5">
          {current.type === "single" && current.options?.map((option) => {
            const active = selected === option.value;
            return <button key={option.value} type="button" onClick={() => updateAnswer(current.id, option.value)} aria-pressed={active} className={`w-full rounded-xl border p-4 text-left transition ${active ? "border-lf-accent bg-lf-accent/10" : "border-lf-graphite-700 bg-black/10 hover:border-lf-gray-500"}`}><span className="flex items-center gap-3"><span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border ${active ? "border-lf-accent bg-lf-accent" : "border-lf-gray-500"}`}>{active && <span className="h-2 w-2 rounded-full bg-lf-ink"/>}</span><span><strong className="text-sm">{option.label}</strong>{option.description && <span className="mt-1 block text-xs text-lf-gray-400">{option.description}</span>}</span></span></button>;
          })}
          {current.type === "multi" && current.options?.map((option) => {
            const values = Array.isArray(selected) ? selected : [];
            const active = values.includes(option.value);
            return <button key={option.value} type="button" onClick={() => toggleMulti(current, option.value)} aria-pressed={active} className={`w-full rounded-xl border p-4 text-left transition ${active ? "border-lf-accent bg-lf-accent/10" : "border-lf-graphite-700 bg-black/10 hover:border-lf-gray-500"}`}><span className="flex items-center gap-3"><span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${active ? "border-lf-accent bg-lf-accent text-lf-ink" : "border-lf-gray-500"}`}>{active ? "✓" : ""}</span><strong className="text-sm">{option.label}</strong></span></button>;
          })}
          {current.type === "scale" && <div><div className="grid grid-cols-6 gap-2 sm:grid-cols-11">{Array.from({ length: (current.max ?? 10) - (current.min ?? 0) + 1 }, (_, n) => n + (current.min ?? 0)).map((value) => <button key={value} type="button" onClick={() => updateAnswer(current.id, value)} aria-pressed={selected === value} className={`min-h-12 rounded-xl border text-sm font-semibold ${selected === value ? "border-lf-accent bg-lf-accent text-lf-ink" : "border-lf-graphite-700 bg-black/10 text-lf-gray-300"}`}>{value}</button>)}</div><div className="mt-2 flex justify-between text-xs text-lf-gray-500"><span>Baixo</span><span>Alto</span></div></div>}
          {current.type === "number" && <label className="block"><span className="sr-only">{current.title}</span><div className="flex items-center gap-3 rounded-xl border border-lf-graphite-600 bg-black/20 px-4"><input type="number" inputMode="decimal" min={current.min} max={current.max} value={selected ?? ""} onChange={(event) => updateAnswer(current.id, event.target.value === "" ? "" : Number(event.target.value))} className="min-h-14 w-full bg-transparent text-xl outline-none" placeholder="Digite aqui"/><span className="text-sm text-lf-gray-400">{current.unit}</span></div><span className="mt-2 block text-xs text-lf-gray-500">Entre {current.min} e {current.max} {current.unit}</span></label>}
          {current.type === "text" && <textarea value={typeof selected === "string" ? selected : ""} onChange={(event) => updateAnswer(current.id, event.target.value)} rows={4} maxLength={500} placeholder={current.placeholder ?? "Escreva sua resposta…"} className="w-full resize-y rounded-xl border border-lf-graphite-600 bg-black/20 p-4 text-base text-white outline-none placeholder:text-lf-gray-500 focus:border-lf-accent"/>}
        </div>
        {current.required && selected === undefined && <p className="mt-3 text-xs text-lf-gray-500">Esta resposta é necessária para continuar.</p>}
        {current.type === "number" && selected !== undefined && !isAnswered(current, answers) && <p className="mt-3 text-xs text-red-300">Informe um valor entre {current.min} e {current.max} {current.unit}.</p>}
      </section>
      <div className="flex gap-3">
        <Button variant="secondary" fullWidth disabled={index === 0} onClick={() => setIndex((value) => Math.max(0, value - 1))}>Voltar</Button>
        <Button fullWidth disabled={Boolean(current.required && !isAnswered(current, answers))} onClick={goNext}>{index === questions.length - 1 ? "Concluir avaliação" : "Continuar"}</Button>
      </div>
      <div className="flex items-center justify-between"><span className="text-xs text-lf-gray-500">Rascunho salvo neste dispositivo</span><button type="button" onClick={reset} className="min-h-10 text-xs text-lf-gray-400 underline underline-offset-4">Apagar e recomeçar</button></div>
    </div>
  );
}
