"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Button, buttonClasses } from "@/components/ui/Button";
import { FormAlert } from "@/components/ui/FormAlert";
import { EmptyState, ErrorState, LoadingState } from "@/components/ui/StateViews";
import { useAuthService } from "@/features/auth/useAuthService";
import { t } from "@/i18n";
import type { AuthErrorCode, AuthUser } from "@/lib/auth/types";
import { AssessmentWizard } from "@/features/assessment/AssessmentWizard";

type GateState =
  | { kind: "loading" }
  | { kind: "not_configured" }
  | { kind: "anonymous" }
  | { kind: "ready"; user: AuthUser }
  | { kind: "error"; code: AuthErrorCode };

/** Área autenticada do LIFEFORM: confirma a conta e libera a avaliação pessoal. */
export function AssessmentGate() {
  const router = useRouter();
  const auth = useAuthService();
  const [state, setState] = useState<GateState>({ kind: "loading" });
  const [signingOut, setSigningOut] = useState(false);
  const [signOutFailed, setSignOutFailed] = useState(false);

  useEffect(() => {
    let active = true;
    async function load() {
      if (!auth.isConfigured) {
        setState({ kind: "not_configured" });
        return;
      }
      const result = await auth.getUser();
      if (!active) return;
      if (!result.ok) setState({ kind: "error", code: result.error });
      else if (!result.data) setState({ kind: "anonymous" });
      else setState({ kind: "ready", user: result.data });
    }
    void load();
    return () => {
      active = false;
    };
  }, [auth]);

  async function onSignOut() {
    setSigningOut(true);
    setSignOutFailed(false);
    const result = await auth.signOut();
    if (!result.ok) {
      setSigningOut(false);
      setSignOutFailed(true);
      return;
    }
    router.replace("/entrar");
  }

  switch (state.kind) {
    case "loading":
      return <LoadingState />;
    case "not_configured":
      return <FormAlert variant="info">{t("auth.notice.notConfigured")}</FormAlert>;
    case "anonymous":
      return (
        <EmptyState
          title={t("assessmentGate.needLogin")}
          action={
            <Link href="/entrar" className={buttonClasses({ size: "lg" })}>
              {t("assessmentGate.goLogin")}
            </Link>
          }
        />
      );
    case "error":
      return (
        <ErrorState
          description={t(`auth.errors.${state.code}`)}
          action={
            <Button variant="secondary" onClick={() => window.location.reload()}>
              {t("common.retry")}
            </Button>
          }
        />
      );
    case "ready":
      return (
        <div className="flex flex-col gap-5">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate text-sm text-lf-gray-300">{state.user.name ? t("assessmentGate.hello", { name: state.user.name }) : t("assessmentGate.helloNoName")}</p>
              <p className="truncate text-xs text-lf-gray-500">{state.user.email}</p>
            </div>
            <Button variant="ghost" size="md" loading={signingOut} onClick={onSignOut}>{signingOut ? t("assessmentGate.signingOut") : t("assessmentGate.signOut")}</Button>
          </div>
          {signOutFailed && <FormAlert variant="error">{t("assessmentGate.signOutError")}</FormAlert>}
          <AssessmentWizard userId={state.user.id} />
        </div>
      );
  }
}
