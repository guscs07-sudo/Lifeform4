"use client";

import { useMemo } from "react";
import Link from "next/link";
import { buttonClasses } from "@/components/ui/Button";
import { AssetImage } from "@/components/media/AssetImage";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import type { AssessmentAnswers } from "@/lib/assessment/questions";
import { buildDiagnosis, type PillarId, type SignalLevel } from "@/lib/assessment/diagnosis";

interface DiagnosisReportProps {
  answers: AssessmentAnswers;
  onReview: () => void;
  onRestart: () => void;
}

const LEVEL_LABEL: Record<SignalLevel, string> = {
  needs_attention: "Ponto de atenção",
  building: "Em construção",
  steady: "Base percebida",
  insufficient_data: "Dados insuficientes",
};
const PILLAR_IMAGE: Record<PillarId, string> = {
  body: "photo.modules/02-body",
  mind: "photo.modules/06-mind",
  lifestyle: "photo.modules/05-sleep",
};

export function DiagnosisReport({ answers, onReview, onRestart }: DiagnosisReportProps) {
  const diagnosis = useMemo(() => buildDiagnosis(answers), [answers]);
  const priorityTitle = diagnosis.pillars.find((pillar) => pillar.id === diagnosis.priority)?.title ?? "Corpo";

  return (
    <div className="flex flex-col gap-5" data-testid="diagnosis-report">
      <section className="relative isolate overflow-hidden rounded-2xl border border-white/10">
        <div className="h-56 sm:h-72"><AssetImage slotId="photo.diagnostic/hero" fill priority quietFallback /></div>
        <div className="absolute inset-0 bg-gradient-to-t from-[#08090d] via-[#08090d]/45 to-black/5" />
        <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7">
          <span className="text-[10px] font-semibold uppercase tracking-[0.24em] text-lf-accent">LIFEFORM · SEU PONTO DE PARTIDA</span>
          <h2 className="mt-2 max-w-xl font-display text-3xl font-semibold leading-tight text-white sm:text-4xl">Seu momento, visto por inteiro.</h2>
          <p className="mt-2 max-w-lg text-sm leading-6 text-white/75">Uma leitura inicial das respostas que você compartilhou. Não é uma nota sobre quem você é.</p>
        </div>
      </section>

      <Card className="border-lf-accent/30">
        <div className="flex items-center justify-between gap-3">
          <div>
            <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-lf-accent">Sua fase inicial</span>
            <h3 className="mt-1 font-display text-2xl font-semibold">{diagnosis.phaseTitle}</h3>
          </div>
          <div className="flex h-14 w-14 items-center justify-center rounded-full border border-lf-accent/40 bg-lf-accent/10 text-xl font-semibold text-lf-accent">0{diagnosis.phase === "reconstruction" ? 1 : 2}</div>
        </div>
        <p className="mt-3 text-sm leading-6 text-lf-gray-300">{diagnosis.phaseReason}</p>
        <p className="mt-3 text-xs text-lf-gray-500">Cobertura das respostas consideradas: {diagnosis.overallCoverage}%</p>
      </Card>

      <section className="space-y-3">
        <div>
          <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-lf-accent">Seus três pilares</span>
          <h3 className="mt-1 font-display text-2xl font-semibold">Cada parte conta.</h3>
          <p className="mt-1 text-sm text-lf-gray-400">Os indicadores resumem hábitos e percepções informados, não medem saúde ou valor pessoal.</p>
        </div>
        <div className="grid gap-3">
          {diagnosis.pillars.map((pillar) => (
            <Card key={pillar.id} className="overflow-hidden p-0">
              <div className="relative h-32">
                <AssetImage slotId={PILLAR_IMAGE[pillar.id]} fill quietFallback />
                <div className="absolute inset-0 bg-gradient-to-t from-[#090a0d] via-black/20 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-4">
                  <h4 className="font-display text-xl font-semibold text-white">{pillar.title}</h4>
                  <span className="rounded-full border border-white/15 bg-black/40 px-3 py-1 text-[10px] font-medium text-white backdrop-blur">{LEVEL_LABEL[pillar.level]}</span>
                </div>
              </div>
              <div className="p-4">
                <p className="text-sm leading-6 text-lf-gray-300">{pillar.summary}</p>
                {pillar.score !== null ? (
                  <div className="mt-4">
                    <div className="mb-2 flex items-center justify-between text-xs"><span className="text-lf-gray-400">Indicador de hábitos e percepção</span><strong className="text-white">{pillar.score}/100</strong></div>
                    <div className="h-2 overflow-hidden rounded-full bg-lf-graphite-700"><div className="h-full rounded-full bg-lf-accent transition-all" style={{ width: `${pillar.score}%` }} /></div>
                  </div>
                ) : <p className="mt-3 text-xs text-lf-gray-500">Ainda não há respostas suficientes para este indicador.</p>}
                {pillar.strengths.length > 0 && <div className="mt-3 space-y-1">{pillar.strengths.map((item) => <p key={item} className="text-xs text-emerald-300">↗ {item}</p>)}</div>}
                {pillar.opportunities.length > 0 && <div className="mt-3 space-y-1">{pillar.opportunities.map((item) => <p key={item} className="text-xs text-lf-gray-300">• {item}</p>)}</div>}
                <details className="mt-3 border-t border-lf-graphite-700 pt-3">
                  <summary className="min-h-10 cursor-pointer text-xs font-medium text-lf-gray-400">Como chegamos a esta leitura</summary>
                  <ul className="mt-2 space-y-1">{pillar.evidence.map((item) => <li key={item} className="text-xs leading-5 text-lf-gray-500">{item}</li>)}</ul>
                </details>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <Card>
        <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-lf-accent">Seu objetivo</span>
        <h3 className="mt-1 font-display text-xl font-semibold">O que vamos construir.</h3>
        <p className="mt-2 text-sm leading-6 text-lf-gray-300">{diagnosis.goalSummary}</p>
      </Card>

      <Card>
        <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-lf-accent">Prioridade inicial</span>
        <h3 className="mt-1 font-display text-2xl font-semibold">Vamos começar por {priorityTitle.toLowerCase()}.</h3>
        <p className="mt-2 text-sm leading-6 text-lf-gray-300">{diagnosis.priorityReason} Esta prioridade pode mudar conforme sua rotina e seus registros evoluírem.</p>
      </Card>

      {diagnosis.safety.needsProfessionalGuidance && (
        <Card className="border-amber-500/40 bg-amber-500/5">
          <div className="flex gap-3"><span className="text-xl" aria-hidden>ⓘ</span><div><h3 className="font-semibold text-amber-200">Cuidado e orientação vêm primeiro</h3><p className="mt-2 text-sm leading-6 text-lf-gray-300">{diagnosis.safety.message}</p></div></div>
        </Card>
      )}

      <Card>
        <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-lf-accent">Primeiros passos</span>
        <h3 className="mt-1 font-display text-xl font-semibold">Sem pressa. Com direção.</h3>
        <ol className="mt-3 space-y-3">{diagnosis.nextSteps.map((step, index) => <li key={step} className="flex gap-3 text-sm leading-6 text-lf-gray-300"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-lf-accent/15 text-xs font-semibold text-lf-accent">{index + 1}</span>{step}</li>)}</ol>
      </Card>

      <p className="px-1 text-xs leading-5 text-lf-gray-500">{diagnosis.disclaimer}</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <Link href="/painel" className={buttonClasses({ size: "lg", fullWidth: true })}>Ir para meu painel <span aria-hidden>→</span></Link>
        <Button fullWidth variant="secondary" onClick={onReview}>Revisar respostas</Button>
        <Button fullWidth variant="ghost" onClick={onRestart} className="sm:col-span-2">Refazer avaliação</Button>
      </div>
    </div>
  );
}
