"use client";

import { useEffect, useMemo, useState } from "react";
import { getSupabaseBrowserClient } from "@/lib/supabase/browser";
import { hasJourneyRecords, isJourneyCloudState, journeyStatesMatch, type JourneyCloudState } from "@/lib/journey/cloudState";

type Mode = "checking" | "unavailable" | "local-only" | "conflict" | "ready" | "syncing" | "synced" | "error";

/** Sincronização manual e com resolução explícita de conflitos; nunca sobrescreve dados silenciosamente. */
export function JourneyCloudSync({
  userId,
  localState,
  onLoadCloudState,
  ready,
}: {
  userId: string;
  localState: JourneyCloudState;
  onLoadCloudState: (state: JourneyCloudState) => void;
  ready: boolean;
}) {
  const [mode, setMode] = useState<Mode>("checking");
  const [cloudState, setCloudState] = useState<JourneyCloudState | null>(null);
  const [message, setMessage] = useState("Verificando se a nuvem está disponível…");
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);
  const localHasRecords = useMemo(() => hasJourneyRecords(localState), [localState]);

  useEffect(() => {
    let active = true;
    async function inspectCloud() {
      if (!ready) {
        setMode("checking");
        setCloudState(null);
        setLastSyncedAt(null);
        setMessage("Aguardando o carregamento dos dados deste perfil…");
        return;
      }
      const supabase = getSupabaseBrowserClient();
      if (!supabase) {
        if (active) { setMode("unavailable"); setMessage("Supabase ainda não configurado. Seus registros continuam salvos neste aparelho."); }
        return;
      }
      const { data, error } = await supabase
        .from("journey_states")
        .select("state, updated_at")
        .eq("user_id", userId)
        .maybeSingle();
      if (!active) return;
      if (error) {
        setMode("error");
        setMessage("Não foi possível consultar a nuvem. Seus dados locais foram preservados.");
        return;
      }
      if (!data) {
        setMode(localHasRecords ? "local-only" : "ready");
        setMessage(localHasRecords ? "Encontramos registros neste aparelho, mas ainda não há uma cópia na nuvem." : "Nuvem conectada. Ainda não há registros sincronizados.");
        return;
      }
      if (!isJourneyCloudState(data.state)) {
        setMode("error");
        setMessage("A cópia da nuvem tem um formato inesperado. Nada foi alterado.");
        return;
      }
      setCloudState(data.state);
      if (!localHasRecords) {
        onLoadCloudState(data.state);
        setMode("synced");
        setLastSyncedAt(data.updated_at ?? null);
        setMessage("Seus registros foram carregados da nuvem neste perfil.");
      } else if (journeyStatesMatch(localState, data.state)) {
        setMode("synced");
        setLastSyncedAt(data.updated_at ?? null);
        setMessage("Este aparelho e a nuvem já estão sincronizados.");
      } else {
        setMode("conflict");
        setMessage("Há diferenças entre este aparelho e a nuvem. Escolha qual versão deve prevalecer; nada será sobrescrito sem sua confirmação.");
      }
    }
    void inspectCloud();
    return () => { active = false; };
  // A leitura inicial é intencional: alterações posteriores são enviadas pelo botão explícito.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, ready]);

  async function saveToCloud(state: JourneyCloudState) {
    const supabase = getSupabaseBrowserClient();
    if (!supabase) { setMode("unavailable"); setMessage("Configure o Supabase antes de sincronizar."); return; }
    setMode("syncing");
    setMessage("Enviando seus registros com segurança…");
    const { error } = await supabase.from("journey_states").upsert({
      user_id: userId,
      schema_version: 1,
      state,
    }, { onConflict: "user_id" });
    if (error) {
      setMode("error");
      setMessage("A sincronização falhou. Seus dados locais continuam intactos; tente novamente.");
      return;
    }
    setMode("synced");
    setCloudState(state);
    setLastSyncedAt(new Date().toISOString());
    setMessage("Sincronização concluída. Esta cópia pertence somente à sua conta.");
  }

  function useCloudVersion() {
    if (!cloudState) return;
    onLoadCloudState(cloudState);
    setMode("synced");
    setMessage("A versão da nuvem foi carregada neste aparelho. Você pode sincronizar novas alterações quando quiser.");
  }

  const busy = mode === "checking" || mode === "syncing";
  return (
    <section className="rounded-2xl border border-[#FF762E]/25 bg-[linear-gradient(120deg,rgba(255,118,46,.09),rgba(17,19,24,.96)_70%)] p-4" aria-label="Sincronização da jornada">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Cópia na nuvem</p>
          <p className="mt-1 text-sm font-semibold text-white">Sincronização da sua jornada</p>
          <p className="mt-1 text-xs leading-5 text-white/55" role="status">{message}</p>
          {lastSyncedAt && <p className="mt-1 text-[10px] text-white/35">Última cópia: {new Date(lastSyncedAt).toLocaleString("pt-BR")}</p>}
        </div>
        <span className={`rounded-full border px-3 py-1 text-[10px] ${mode === "synced" ? "border-emerald-400/25 text-emerald-200" : mode === "error" ? "border-red-400/25 text-red-200" : "border-white/10 text-white/50"}`}>
          {mode === "synced" ? "Sincronizado" : mode === "syncing" ? "Enviando…" : mode === "checking" ? "Verificando…" : mode === "error" ? "Atenção" : "Aguardando ação"}
        </span>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {(mode === "local-only" || mode === "ready" || mode === "synced" || mode === "error") && <button type="button" disabled={busy || !localHasRecords && mode !== "ready"} onClick={() => void saveToCloud(localState)} className="min-h-10 rounded-xl bg-[#FF762E] px-4 text-xs font-bold text-black disabled:opacity-40">Enviar dados deste aparelho</button>}
        {mode === "conflict" && <>
          <button type="button" onClick={() => void saveToCloud(localState)} className="min-h-10 rounded-xl bg-[#FF762E] px-4 text-xs font-bold text-black">Manter este aparelho</button>
          <button type="button" onClick={useCloudVersion} className="min-h-10 rounded-xl border border-white/15 px-4 text-xs font-semibold text-white/80">Usar versão da nuvem</button>
        </>}
        {mode === "unavailable" && <span className="text-[10px] text-white/35">A sincronização será liberada após configurar as variáveis do Supabase.</span>}
      </div>
      <p className="mt-2 text-[10px] leading-4 text-white/30">A sincronização é manual nesta versão. Isso evita sobrescrever alterações de outro dispositivo sem você perceber.</p>
    </section>
  );
}
