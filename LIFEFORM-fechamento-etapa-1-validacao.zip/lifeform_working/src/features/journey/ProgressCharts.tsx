"use client";

type Session = { date: string; durationMinutes: number };
type Activity = { date: string; minutes: number };
type WeekPoint = { label: string; training: number; activities: number };

function buildWeeks(sessions: Session[], activities: Activity[]): WeekPoint[] {
  const now = new Date();
  const monday = new Date(now);
  monday.setHours(0, 0, 0, 0);
  monday.setDate(monday.getDate() - ((monday.getDay() + 6) % 7));
  return Array.from({ length: 4 }, (_, index) => {
    const start = new Date(monday);
    start.setDate(start.getDate() - (3 - index) * 7);
    const end = new Date(start);
    end.setDate(end.getDate() + 7);
    const key = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    const from = key(start);
    const until = key(end);
    return {
      label: index === 3 ? "Esta" : `-${3 - index} sem.`,
      training: sessions.filter((item) => item.date >= from && item.date < until).reduce((sum, item) => sum + item.durationMinutes, 0),
      activities: activities.filter((item) => item.date >= from && item.date < until).length,
    };
  });
}

function LineChart({ values, color, title, unit }: { values: number[]; color: string; title: string; unit: string }) {
  const max = Math.max(1, ...values);
  const points = values.map((value, index) => `${24 + index * 84},${86 - (value / max) * 62}`).join(" ");
  return <div className="rounded-xl border border-white/10 bg-black/20 p-3">
    <div className="flex items-center justify-between gap-2"><p className="text-xs font-semibold text-white/75">{title}</p><span className="text-[10px] text-white/35">{unit}</span></div>
    <svg viewBox="0 0 300 112" role="img" aria-label={`${title}: ${values.map((value, index) => `${["três semanas atrás", "duas semanas atrás", "semana passada", "esta semana"][index]}: ${value} ${unit}`).join("; ")}`} className="mt-2 h-28 w-full overflow-visible">
      {[24, 55, 86].map((y) => <line key={y} x1="18" x2="282" y1={y} y2={y} stroke="rgba(255,255,255,.10)" strokeDasharray="3 5" />)}
      <polyline points={points} fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      {values.map((value, index) => <g key={index}><circle cx={24 + index * 84} cy={86 - (value / max) * 62} r="4" fill={color} /><text x={24 + index * 84} y="105" textAnchor="middle" fill="rgba(255,255,255,.42)" fontSize="9">{["-3 sem.", "-2 sem.", "-1 sem.", "Esta"][index]}</text><text x={24 + index * 84} y={Math.max(13, 77 - (value / max) * 62)} textAnchor="middle" fill="rgba(255,255,255,.75)" fontSize="9">{value}</text></g>)}
    </svg>
  </div>;
}

export function ProgressCharts({ sessions, activities }: { sessions: Session[]; activities: Activity[] }) {
  const weeks = buildWeeks(sessions, activities);
  return <section aria-label="Gráficos de evolução" className="grid gap-3 md:grid-cols-2">
    <LineChart title="Minutos de treino por semana" values={weeks.map((week) => week.training)} color="#FF8A50" unit="minutos" />
    <LineChart title="Atividades registradas por semana" values={weeks.map((week) => week.activities)} color="#70C6B1" unit="registros" />
    <p className="md:col-span-2 text-[10px] leading-4 text-white/35">Gráficos descritivos dos registros informados no aplicativo; não representam avaliação clínica, condicionamento físico ou qualidade do treino.</p>
  </section>;
}
