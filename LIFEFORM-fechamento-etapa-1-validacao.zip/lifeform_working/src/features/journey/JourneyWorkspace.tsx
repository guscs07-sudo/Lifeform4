"use client";

import { useEffect, useMemo, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { Card } from "@/components/ui/Card";
import { TrainingPlanBuilder } from "@/features/training/TrainingPlanBuilder";
import { ExerciseLibrary } from "@/features/training/ExerciseLibrary";
import { EXERCISES } from "@/content/training/exercises";
import { summarizeTrainingProgress } from "@/lib/progress/trainingProgress";
import { summarizeJourneyRewards } from "@/lib/progress/journeyRewards";
import { buildWeeklyGuidance } from "@/lib/coach/weeklyGuidance";
import { buildJourneyInsights } from "@/lib/progress/journeyInsights";
import { PhaseProgressPanel } from "@/features/journey/PhaseProgressPanel";
import { parseJourneyBackup } from "@/lib/journey/backup";
import { JourneyCloudSync } from "@/features/journey/JourneyCloudSync";
import { ProgressCharts } from "@/features/journey/ProgressCharts";
import type { PhaseId } from "@/config/phases";

type Activity = { id: string; title: string; minutes: number; date: string; note?: string; trainingSessionId?: string };
type Habit = { id: string; title: string; frequency: "daily" | "weekly"; doneDates: string[] };
type Goal = { id: string; title: string; detail: string; createdAt: string; completed: boolean };
type TrainingEntry = { exerciseId: string; exerciseName: string; sets: number; reps: number; loadKg?: number };
type TrainingSession = { id: string; title: string; date: string; durationMinutes: number; entries: TrainingEntry[]; note?: string };
type WeeklyReview = { weekOf: string; energy: "low" | "medium" | "high"; recovery: "poor" | "okay" | "good"; difficulty: "easy" | "right" | "hard"; routine: "stable" | "changed" | "busy"; note: string; submittedAt: string };
type JourneyData = { activities: Activity[]; habits: Habit[]; goals: Goal[]; trainingSessions: TrainingSession[]; weeklyReviews: WeeklyReview[] };
type Tab = "overview" | "training" | "activities" | "habits" | "goals";

const EMPTY: JourneyData = { activities: [], habits: [], goals: [], trainingSessions: [], weeklyReviews: [] };
const weekStartKey = (source = new Date()) => { const date = new Date(source); date.setHours(0, 0, 0, 0); date.setDate(date.getDate() - ((date.getDay() + 6) % 7)); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`; };
const todayKey = () => { const date = new Date(); const year = date.getFullYear(); const month = String(date.getMonth() + 1).padStart(2, "0"); const day = String(date.getDate()).padStart(2, "0"); return `${year}-${month}-${day}`; };
const isHabitDone = (habit: Habit, today: string, weekStart: string) => habit.frequency === "daily" ? habit.doneDates.includes(today) : habit.doneDates.some((date) => date >= weekStart && date <= today);
const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const inputClass = "min-h-11 w-full rounded-xl border border-white/10 bg-black/30 px-3 text-sm text-white outline-none placeholder:text-white/30 focus:border-[#FF762E]/70";

export function JourneyWorkspace({ userId, initialPhase = "reconstruction", safetyHold = false }: { userId: string; initialPhase?: PhaseId; safetyHold?: boolean }) {
  const storageKey = `lifeform:journey:v1:${userId}`;
  const [data, setData] = useState<JourneyData>(EMPTY);
  const [tab, setTab] = useState<Tab>("overview");
  const [ready, setReady] = useState(false);
  const [loadedStorageKey, setLoadedStorageKey] = useState<string | null>(null);
  const [activityTitle, setActivityTitle] = useState("");
  const [activityMinutes, setActivityMinutes] = useState("20");
  const [activityNote, setActivityNote] = useState("");
  const [habitTitle, setHabitTitle] = useState("");
  const [habitFrequency, setHabitFrequency] = useState<"daily" | "weekly">("daily");
  const [goalTitle, setGoalTitle] = useState("");
  const [goalDetail, setGoalDetail] = useState("");
  const [sessionTitle, setSessionTitle] = useState("Meu treino");
  const [sessionMinutes, setSessionMinutes] = useState("30");
  const [selectedExercises, setSelectedExercises] = useState<string[]>([]);
  const [sessionNote, setSessionNote] = useState("");
  const [entrySets, setEntrySets] = useState("3");
  const [entryReps, setEntryReps] = useState("10");
  const [entryLoad, setEntryLoad] = useState("");
  const [reviewEnergy, setReviewEnergy] = useState<WeeklyReview["energy"]>("medium");
  const [reviewRecovery, setReviewRecovery] = useState<WeeklyReview["recovery"]>("okay");
  const [reviewDifficulty, setReviewDifficulty] = useState<WeeklyReview["difficulty"]>("right");
  const [reviewRoutine, setReviewRoutine] = useState<WeeklyReview["routine"]>("stable");
  const [reviewNote, setReviewNote] = useState("");
  const [backupMessage, setBackupMessage] = useState<string | null>(null);
  const [storageMessage, setStorageMessage] = useState<string | null>(null);
  const [storageWritable, setStorageWritable] = useState(false);
  const profileStorageReady = ready && loadedStorageKey === storageKey;

  useEffect(() => {
    setReady(false);
    setLoadedStorageKey(null);
    setStorageWritable(false);
    setData(EMPTY);
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<JourneyData>;
        setData({ activities: Array.isArray(parsed.activities) ? parsed.activities : [], habits: Array.isArray(parsed.habits) ? parsed.habits : [], goals: Array.isArray(parsed.goals) ? parsed.goals : [], trainingSessions: Array.isArray(parsed.trainingSessions) ? parsed.trainingSessions : [], weeklyReviews: Array.isArray(parsed.weeklyReviews) ? parsed.weeklyReviews : [] });
      }
      setStorageWritable(true);
      setStorageMessage(null);
    } catch {
      setData(EMPTY);
      setStorageWritable(false);
      setStorageMessage("Não foi possível ler os dados salvos neste dispositivo. Seus registros anteriores não foram sobrescritos automaticamente.");
    }
    setLoadedStorageKey(storageKey);
    setReady(true);
  }, [storageKey]);

  useEffect(() => {
    if (!ready || loadedStorageKey !== storageKey || !storageWritable) return;
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(data));
      setStorageMessage(null);
    } catch {
      setStorageMessage("Não foi possível salvar as alterações neste dispositivo. O armazenamento pode estar cheio ou indisponível. Exporte um backup antes de continuar.");
    }
  }, [data, ready, loadedStorageKey, storageKey, storageWritable]);

  const today = todayKey();
  const currentWeek = weekStartKey();
  const currentReview = data.weeklyReviews.find((review) => review.weekOf === currentWeek);
  useEffect(() => {
    if (!currentReview) return;
    setReviewEnergy(currentReview.energy);
    setReviewRecovery(currentReview.recovery);
    setReviewDifficulty(currentReview.difficulty);
    setReviewRoutine(currentReview.routine);
    setReviewNote(currentReview.note);
  }, [currentReview]);
  const completedHabits = data.habits.filter((habit) => isHabitDone(habit, today, currentWeek)).length;
  const activeGoals = data.goals.filter((goal) => !goal.completed).length;
  const rewards = useMemo(() => summarizeJourneyRewards({
    activities: data.activities,
    trainingSessions: data.trainingSessions,
    habits: data.habits,
    goals: data.goals,
    today,
  }), [data.activities, data.trainingSessions, data.habits, data.goals, today]);
  const gamification = rewards.gamification;
  const xp = gamification.xp;
  const weeklyActivities = rewards.movementsThisWeek;
  const todayActivities = rewards.movementsToday;
  const lastSevenDays = useMemo(() => Array.from({ length: 7 }, (_, index) => {
    const date = new Date(); date.setHours(0, 0, 0, 0); date.setDate(date.getDate() - (6 - index));
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    return { key, label: new Intl.DateTimeFormat("pt-BR", { weekday: "short" }).format(date).replace(".", ""), minutes: rewards.validTrainingSessions.filter((session) => session.date === key).reduce((sum, session) => sum + session.durationMinutes, 0), sessions: rewards.validTrainingSessions.filter((session) => session.date === key).length };
  }), [rewards.validTrainingSessions]);
  const totalTrainingMinutes = rewards.trainingMinutesTotal;
  const trainingProgress = useMemo(() => summarizeTrainingProgress(rewards.validTrainingSessions), [rewards.validTrainingSessions]);
  const journeyInsights = useMemo(() => buildJourneyInsights({ activities: rewards.independentActivityRecords, habits: data.habits, goals: data.goals, review: currentReview, referenceDate: new Date() }), [rewards.independentActivityRecords, data.habits, data.goals, currentReview]);
  const completedHabitChecks = rewards.completedHabitChecks;
  const achievements = [
    { title: "Primeiro passo", detail: "Registrou seu primeiro movimento", earned: rewards.totalMovements >= 1, icon: "✦" },
    { title: "Em movimento", detail: "Registrou 5 movimentos", earned: rewards.totalMovements >= 5, icon: "↗" },
    { title: "Primeiro treino", detail: "Concluiu e registrou um treino", earned: data.trainingSessions.length >= 1, icon: "⌁" },
    { title: "Ritmo constante", detail: "Registrou 5 treinos", earned: data.trainingSessions.length >= 5, icon: "◆" },
    { title: "Criador de hábitos", detail: "Criou 3 hábitos", earned: data.habits.length >= 3, icon: "◈" },
    { title: "Hábito em ação", detail: "Concluiu 10 hábitos", earned: completedHabitChecks >= 10, icon: "✓" },
    { title: "Meta alcançada", detail: "Concluiu uma meta", earned: data.goals.some((goal) => goal.completed), icon: "◎" },
  ];

  function toggleExercise(id: string) {
    setSelectedExercises((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }
  function saveTrainingSession(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const minutes = Number(sessionMinutes);
    const sets = Number(entrySets);
    const reps = Number(entryReps);
    const load = entryLoad.trim() ? Number(entryLoad) : undefined;
    if (!sessionTitle.trim() || !Number.isInteger(minutes) || minutes < 1 || minutes > 600 || selectedExercises.length === 0) return;
    if (!Number.isInteger(sets) || sets < 1 || sets > 20 || !Number.isInteger(reps) || reps < 1 || reps > 300) return;
    if (load !== undefined && (!Number.isFinite(load) || load < 0 || load > 1000)) return;
    const entries = selectedExercises.map((id) => {
      const exercise = EXERCISES.find((item) => item.id === id);
      return { exerciseId: id, exerciseName: exercise?.name ?? "Exercício", sets, reps, ...(load !== undefined ? { loadKg: load } : {}) };
    });
    const session: TrainingSession = { id: uid(), title: sessionTitle.trim(), date: today, durationMinutes: minutes, entries, note: sessionNote.trim() || undefined };
    setData((current) => ({ ...current, trainingSessions: [session, ...current.trainingSessions], activities: [{ id: uid(), title: session.title, minutes, date: today, note: `${entries.length} exercício(s) registrado(s)`, trainingSessionId: session.id }, ...current.activities] }));
    setSessionTitle("Meu treino"); setSessionMinutes("30"); setSelectedExercises([]); setSessionNote(""); setEntryLoad("");
  }
  function addActivity(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const minutes = Number(activityMinutes);
    if (!activityTitle.trim() || !Number.isInteger(minutes) || minutes < 1 || minutes > 600) return;
    setData((current) => ({ ...current, activities: [{ id: uid(), title: activityTitle.trim(), minutes, date: today, note: activityNote.trim() || undefined }, ...current.activities] }));
    setActivityTitle(""); setActivityMinutes("20"); setActivityNote("");
  }
  function addHabit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!habitTitle.trim()) return;
    setData((current) => ({ ...current, habits: [...current.habits, { id: uid(), title: habitTitle.trim(), frequency: habitFrequency, doneDates: [] }] }));
    setHabitTitle("");
  }
  function addGoal(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!goalTitle.trim()) return;
    setData((current) => ({ ...current, goals: [{ id: uid(), title: goalTitle.trim(), detail: goalDetail.trim(), createdAt: today, completed: false }, ...current.goals] }));
    setGoalTitle(""); setGoalDetail("");
  }
  function toggleHabit(id: string) {
    setData((current) => ({ ...current, habits: current.habits.map((habit) => {
      if (habit.id !== id) return habit;
      const done = isHabitDone(habit, today, currentWeek);
      const doneDates = habit.frequency === "weekly"
        ? (done ? habit.doneDates.filter((date) => date < currentWeek || date > today) : [...habit.doneDates, today])
        : (done ? habit.doneDates.filter((date) => date !== today) : [...habit.doneDates, today]);
      return { ...habit, doneDates };
    }) }));
  }
  function toggleGoal(id: string) {
    setData((current) => ({ ...current, goals: current.goals.map((goal) => goal.id === id ? { ...goal, completed: !goal.completed } : goal) }));
  }
  function saveWeeklyReview(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const review: WeeklyReview = { weekOf: currentWeek, energy: reviewEnergy, recovery: reviewRecovery, difficulty: reviewDifficulty, routine: reviewRoutine, note: reviewNote.trim().slice(0, 500), submittedAt: new Date().toISOString() };
    setData((current) => ({ ...current, weeklyReviews: [review, ...current.weeklyReviews.filter((item) => item.weekOf !== currentWeek)].sort((a, b) => b.weekOf.localeCompare(a.weekOf)) }));
  }

  function exportBackup() {
    const backup = {
      app: "LIFEFORM",
      formatVersion: 1,
      exportedAt: new Date().toISOString(),
      userId,
      data,
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `lifeform-backup-${today}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  async function importBackup(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      setBackupMessage("O arquivo ultrapassa o limite de 5 MB.");
      return;
    }
    let raw: string;
    try { raw = await file.text(); } catch {
      setBackupMessage("Não foi possível ler o arquivo selecionado.");
      return;
    }
    const result = parseJourneyBackup(raw, userId);
    if (!result.ok) {
      const messages = {
        "invalid-json": "Não foi possível ler o JSON deste arquivo.",
        "invalid-file": "Este arquivo não contém um backup válido do LIFEFORM.",
        "wrong-profile": "Este backup pertence a outro perfil. Para proteger seus dados, a importação foi bloqueada.",
        "unsupported-version": "A versão deste backup não é compatível com esta versão do LIFEFORM."
      };
      setBackupMessage(messages[result.reason]);
      return;
    }
    if (!window.confirm("Importar este backup substituirá os registros atuais deste perfil neste dispositivo. Deseja continuar?")) return;
    setData(result.data);
    setBackupMessage("Backup importado. Seus registros foram restaurados neste dispositivo.");
  }

  function removeItem(kind: "activity" | "habit" | "goal", id: string) {
    setData((current) => kind === "activity" ? { ...current, activities: current.activities.filter((item) => item.id !== id) } : kind === "habit" ? { ...current, habits: current.habits.filter((item) => item.id !== id) } : { ...current, goals: current.goals.filter((item) => item.id !== id) });
  }

  const tabs: { id: Tab; label: string }[] = [{ id: "overview", label: "Visão geral" }, { id: "training", label: "Treinos" }, { id: "activities", label: "Atividades" }, { id: "habits", label: "Hábitos" }, { id: "goals", label: "Metas" }];
  return <section className="space-y-4" aria-label="Sua jornada pessoal" aria-busy={!ready}>
    <JourneyCloudSync
      userId={userId}
      ready={profileStorageReady}
      localState={data}
      onLoadCloudState={(remote) => setData({
        activities: remote.activities as Activity[],
        habits: remote.habits as Habit[],
        goals: remote.goals as Goal[],
        trainingSessions: remote.trainingSessions as TrainingSession[],
        weeklyReviews: remote.weeklyReviews as WeeklyReview[],
      })}
    />
    <div className="flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Seções da jornada">
      {tabs.map((item) => <button key={item.id} type="button" role="tab" aria-selected={tab === item.id} onClick={() => setTab(item.id)} className={`min-h-10 shrink-0 rounded-full border px-4 text-xs font-semibold transition ${tab === item.id ? "border-[#FF762E] bg-[#FF762E] text-black" : "border-white/10 bg-white/5 text-white/65 hover:border-white/30"}`}>{item.label}</button>)}
    </div>

    {tab === "overview" && <>
      {storageMessage && <Card className="border-amber-400/30 bg-amber-400/[.06] p-3"><p className="text-xs leading-5 text-amber-100" role="alert">{storageMessage}</p></Card>}
      <Card className="border-white/10 bg-[#111318] p-4 sm:flex sm:items-center sm:justify-between sm:gap-4">
        <div><p className="text-sm font-semibold">Seus dados, sob seu controle</p><p className="mt-1 text-xs leading-5 text-white/45">Baixe uma cópia dos seus registros deste dispositivo. O arquivo contém informações pessoais; guarde-o em local privado.</p></div>
        <div className="mt-3 flex shrink-0 flex-wrap gap-2 sm:mt-0">
          <button type="button" onClick={exportBackup} disabled={!ready} className="min-h-11 rounded-xl border border-[#FF762E]/40 px-4 text-xs font-semibold text-[#FFAD83] transition hover:bg-[#FF762E]/10 disabled:opacity-40">Exportar dados ↓</button>
          <label className="flex min-h-11 cursor-pointer items-center rounded-xl border border-white/15 px-4 text-xs font-semibold text-white/75 transition hover:bg-white/5">Importar backup ↑<input type="file" accept="application/json,.json" onChange={importBackup} className="sr-only" disabled={!ready}/></label>
        </div>
        {backupMessage && <p className="mt-3 text-xs leading-5 text-[#FFAD83]" role="status">{backupMessage}</p>}
      </Card>
      <Card className="border-[#FF762E]/25 bg-[linear-gradient(110deg,rgba(255,118,46,.12),rgba(17,19,24,.96)_72%)] p-4">
        <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Sua jornada</p><h3 className="mt-1 text-lg font-semibold">Nível {gamification.level} · {gamification.title}</h3><p className="mt-1 text-xs text-white/45">{gamification.currentLevelXp} de {gamification.nextLevelXp} XP para o próximo nível</p></div><div className="rounded-xl border border-[#FF762E]/30 bg-black/20 px-4 py-2 text-center"><p className="text-2xl font-bold text-[#FF9A63]">{xp}</p><p className="text-[9px] uppercase tracking-wider text-white/40">XP total</p></div></div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-[#FF762E] to-[#FFB07D] transition-all" style={{ width: `${gamification.progressPercent}%` }} /></div>
        <p className="mt-2 text-[10px] text-white/35">XP calculado a partir de atividades, treinos, hábitos concluídos e metas alcançadas registrados neste perfil.</p>
      </Card>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[{ label: "Movimentos nos últimos 7 dias", value: weeklyActivities, suffix: "registros" }, { label: "Movimentos hoje", value: todayActivities, suffix: "registros" }, { label: "Hábitos concluídos hoje", value: `${completedHabits}/${data.habits.length}`, suffix: "hábitos" }, { label: "XP acumulado", value: xp, suffix: "pontos" }].map((item) => <Card key={item.label} className="border-white/10 bg-[#111318] p-4"><p className="text-[11px] leading-4 text-white/45">{item.label}</p><p className="mt-2 font-display text-2xl font-semibold text-white">{item.value}</p><p className="mt-1 text-[10px] text-white/35">{item.suffix}</p></Card>)}
      </div>
      <Card className="border-[#FF762E]/20 bg-[linear-gradient(145deg,rgba(255,118,46,.07),rgba(17,19,24,.98)_72%)] p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Visão integrada da jornada</p><h3 className="mt-1 text-lg font-semibold">{journeyInsights.headline}</h3><p className="mt-2 max-w-2xl text-sm leading-6 text-white/60">{journeyInsights.recommendation}</p></div>
          <span className="rounded-full border border-white/10 px-3 py-1 text-[10px] text-white/50">{journeyInsights.focus === "recovery" ? "Foco: recuperação" : journeyInsights.focus === "simplify" ? "Foco: simplificar" : journeyInsights.focus === "maintain" ? "Foco: manter" : "Foco: começar"}</span>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[{ label: "Atividades na semana", value: journeyInsights.activitiesThisWeek }, { label: "Hábitos concluídos", value: journeyInsights.habitChecksThisWeek }, { label: "Hábitos com progresso", value: `${journeyInsights.habitsWithProgress}/${data.habits.length}` }, { label: "Metas concluídas", value: `${journeyInsights.completedGoals}/${data.goals.length}` }].map((item) => <div key={item.label} className="rounded-xl bg-white/[.035] p-3"><p className="text-[10px] leading-4 text-white/40">{item.label}</p><p className="mt-1 text-lg font-semibold text-white">{item.value}</p></div>)}
        </div>
        <p className="mt-3 text-[10px] leading-4 text-white/30">Resumo calculado a partir dos registros deste perfil e da revisão da semana atual. Não é uma avaliação clínica nem uma prescrição de treino.</p>
      </Card>
      <PhaseProgressPanel userId={userId} initialPhase={initialPhase} activities={data.activities} habits={data.habits} reviews={data.weeklyReviews} hasUnresolvedSafetyConcern={safetyHold} />
      <ProgressCharts sessions={rewards.validTrainingSessions as TrainingSession[]} activities={rewards.independentActivityRecords as unknown as Activity[]} />
      <Card className="border-white/10 bg-[#111318] p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Leitura da sua evolução</p><h3 className="mt-1 text-lg font-semibold">Comparação entre semanas</h3><p className="mt-2 max-w-2xl text-sm leading-6 text-white/60">{trainingProgress.message}</p></div>
          <span className="rounded-full border border-white/10 px-3 py-1 text-[10px] text-white/50">{trainingProgress.currentSessions} nesta · {trainingProgress.previousSessions} na anterior</span>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div className="rounded-xl bg-white/[.035] p-3"><p className="text-[10px] uppercase tracking-wider text-white/40">Tempo registrado · atual</p><p className="mt-1 text-xl font-semibold">{trainingProgress.currentMinutes} min</p></div>
          <div className="rounded-xl bg-white/[.035] p-3"><p className="text-[10px] uppercase tracking-wider text-white/40">Tempo registrado · anterior</p><p className="mt-1 text-xl font-semibold">{trainingProgress.previousMinutes} min</p></div>
        </div>
        <p className="mt-3 text-xs leading-5 text-[#FFAD83]">Próximo passo: {trainingProgress.nextStep}</p>
        <p className="mt-2 text-[10px] text-white/30">Comparação descritiva baseada apenas nos treinos registrados. Não mede condicionamento nem recomenda aumentar carga ou intensidade.</p>
      </Card>
      <Card className="border-[#FF762E]/25 bg-[linear-gradient(145deg,rgba(255,118,46,.08),rgba(17,19,24,.98)_70%)] p-5">
        <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Revisão semanal</p><h3 className="mt-1 text-lg font-semibold">Como foi sua semana de verdade?</h3><p className="mt-2 max-w-2xl text-xs leading-5 text-white/50">Uma revisão rápida para entender energia, recuperação e mudanças na rotina. Ela não é uma avaliação médica nem uma nota de desempenho.</p></div><span className="rounded-full border border-white/10 px-3 py-1 text-[10px] text-white/45">Semana de {new Date(`${currentWeek}T12:00:00`).toLocaleDateString("pt-BR")}</span></div>
        {currentReview ? <div className="mt-4 rounded-xl border border-emerald-400/20 bg-emerald-400/[.06] p-4"><p className="text-sm font-semibold text-emerald-200">Revisão desta semana registrada ✓</p><p className="mt-1 text-xs leading-5 text-white/55">Energia: {currentReview.energy === "low" ? "baixa" : currentReview.energy === "high" ? "alta" : "moderada"} · Recuperação: {currentReview.recovery === "poor" ? "ruim" : currentReview.recovery === "good" ? "boa" : "regular"} · Dificuldade: {currentReview.difficulty === "hard" ? "alta" : currentReview.difficulty === "easy" ? "leve" : "adequada"}</p>{currentReview.note && <p className="mt-2 text-xs text-white/55">“{currentReview.note}”</p>}<p className="mt-2 text-[10px] text-white/35">Você pode atualizar suas respostas abaixo.</p></div> : null}
        {currentReview ? <div className="mt-3 space-y-2" aria-live="polite"><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Orientação da semana</p>{buildWeeklyGuidance(currentReview).map((item) => <div key={item.title} className={`rounded-xl border p-4 ${item.tone === "care" ? "border-amber-400/25 bg-amber-400/[.06]" : item.tone === "adapt" ? "border-[#FF762E]/25 bg-[#FF762E]/[.06]" : "border-white/10 bg-white/[.03]"}`}><p className="text-sm font-semibold text-white">{item.title}</p><p className="mt-1 text-xs leading-5 text-white/60">{item.message}</p><p className="mt-2 text-xs leading-5 text-[#FFAD83]">Próxima ação: {item.action}</p></div>)}<p className="text-[10px] leading-4 text-white/30">Orientações gerais baseadas no seu check-in. Não são diagnóstico nem prescrição; não substituem orientação profissional.</p></div> : null}
        <form onSubmit={saveWeeklyReview} className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="block text-xs text-white/65">Como esteve sua energia?<select className={`${inputClass} mt-1`} value={reviewEnergy} onChange={(event) => setReviewEnergy(event.target.value as WeeklyReview["energy"])}><option value="low">Baixa</option><option value="medium">Moderada</option><option value="high">Alta</option></select></label>
          <label className="block text-xs text-white/65">Como foi sua recuperação?<select className={`${inputClass} mt-1`} value={reviewRecovery} onChange={(event) => setReviewRecovery(event.target.value as WeeklyReview["recovery"])}><option value="poor">Ruim / insuficiente</option><option value="okay">Regular</option><option value="good">Boa</option></select></label>
          <label className="block text-xs text-white/65">Como você sentiu a dificuldade das atividades?<select className={`${inputClass} mt-1`} value={reviewDifficulty} onChange={(event) => setReviewDifficulty(event.target.value as WeeklyReview["difficulty"])}><option value="easy">Leve</option><option value="right">Adequada</option><option value="hard">Pesada</option></select></label>
          <label className="block text-xs text-white/65">Sua rotina mudou?<select className={`${inputClass} mt-1`} value={reviewRoutine} onChange={(event) => setReviewRoutine(event.target.value as WeeklyReview["routine"])}><option value="stable">Permaneceu estável</option><option value="changed">Mudou um pouco</option><option value="busy">Fiquei com pouco tempo</option></select></label>
          <label className="block text-xs text-white/65 sm:col-span-2">Quer registrar algo importante? (opcional)<textarea className={`${inputClass} mt-1 min-h-20 py-3`} value={reviewNote} onChange={(event) => setReviewNote(event.target.value)} maxLength={500} placeholder="Ex.: tive uma semana corrida, dormi menos ou precisei adaptar os treinos." /></label>
          <div className="sm:col-span-2 flex flex-wrap items-center gap-3"><button type="submit" className="min-h-11 rounded-xl bg-[#FF762E] px-5 text-xs font-bold text-black">{currentReview ? "Atualizar revisão" : "Salvar revisão da semana"}</button><span className="text-[10px] text-white/35">Salva apenas neste dispositivo e neste perfil.</span></div>
        </form>
      </Card>
      <div className="grid gap-3 md:grid-cols-2">
        <Card className="border-white/10 bg-[#111318] p-5">
          <div className="flex items-center justify-between gap-3"><div><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Ritmo de treino</p><h3 className="mt-1 text-lg font-semibold">Últimos 7 dias</h3></div><span className="text-xs text-white/45">{totalTrainingMinutes} min no total</span></div>
          <div className="mt-5 grid grid-cols-7 items-end gap-2" aria-label="Minutos de treino registrados nos últimos sete dias">
            {lastSevenDays.map((day) => <div key={day.key} className="flex min-w-0 flex-col items-center gap-2"><span className="text-[9px] text-white/45">{day.minutes || "—"}</span><div className="flex h-24 w-full items-end rounded-lg bg-white/[.04] p-1"><div className="w-full rounded-md bg-gradient-to-t from-[#FF762E]/60 to-[#FF9A63] transition-all" style={{ height: `${day.minutes ? Math.max(8, Math.min(100, day.minutes / Math.max(30, ...lastSevenDays.map((item) => item.minutes)) * 100)) : 3}%` }} /></div><span className="text-[9px] capitalize text-white/40">{day.label}</span></div>)}
          </div>
          <p className="mt-3 text-[10px] leading-4 text-white/35">Somente treinos que você registrou entram neste gráfico. Dias sem registro não significam falta de esforço.</p>
        </Card>
        <Card className="border-[#FF762E]/25 bg-[linear-gradient(145deg,rgba(255,118,46,.10),rgba(17,19,24,.96)_70%)] p-5">
          <p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Missão semanal</p>
          <div className="mt-2 flex items-end justify-between gap-3"><h3 className="text-lg font-semibold">Movimente-se 3 vezes</h3><span className="text-sm font-bold text-[#FF9A63]">{Math.min(weeklyActivities, 3)}/3</span></div>
          <p className="mt-1 text-xs leading-5 text-white/45">Registre três atividades nesta semana. Vale uma caminhada, treino, pedal ou outra atividade que seja adequada para você.</p>
          <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-[#FF762E] transition-all" style={{ width: `${Math.min(weeklyActivities / 3, 1) * 100}%` }}/></div>
          <p className="mt-2 text-[10px] text-white/40">{weeklyActivities >= 3 ? "Missão concluída. Boa consistência!" : `Faltam ${3 - weeklyActivities} registro(s) para concluir.`}</p>
        </Card>
        <Card className="border-white/10 bg-[#111318] p-5"><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Conquistas desbloqueadas</p><div className="mt-3 grid grid-cols-2 gap-2">
          {achievements.map((achievement) => <div key={achievement.title} className={`rounded-xl border p-3 ${achievement.earned ? "border-[#FF762E]/30 bg-[#FF762E]/10" : "border-white/10 bg-white/[.025] opacity-55"}`}><span className="text-lg text-[#FF9A63]">{achievement.icon}</span><p className="mt-1 text-xs font-semibold">{achievement.title}</p><p className="mt-1 text-[10px] leading-4 text-white/45">{achievement.detail}</p><p className="mt-2 text-[9px] font-semibold uppercase tracking-wider text-[#FF9A63]">{achievement.earned ? "Desbloqueada" : "Ainda não"}</p></div>)}
        </div></Card>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <Card className="border-white/10 bg-[#111318] p-5"><div className="flex items-center justify-between"><h3 className="font-semibold">Hábitos do período</h3><button onClick={() => setTab("habits")} className="text-xs font-semibold text-[#FF9A63]">Organizar →</button></div>{data.habits.length ? <ul className="mt-3 space-y-2">{data.habits.slice(0, 4).map((habit) => <li key={habit.id}><button onClick={() => toggleHabit(habit.id)} className="flex min-h-11 w-full items-center gap-3 rounded-xl bg-white/[.035] px-3 text-left"><span className={`flex h-5 w-5 items-center justify-center rounded-md border ${isHabitDone(habit, today, currentWeek) ? "border-[#FF762E] bg-[#FF762E] text-black" : "border-white/25"}`}>{isHabitDone(habit, today, currentWeek) ? "✓" : ""}</span><span className="text-sm text-white/80">{habit.title}</span></button></li>)}</ul> : <p className="mt-3 text-sm text-white/45">Adicione um hábito pequeno e possível para começar.</p>}</Card>
        <Card className="border-white/10 bg-[#111318] p-5"><div className="flex items-center justify-between"><h3 className="font-semibold">Próximas metas</h3><button onClick={() => setTab("goals")} className="text-xs font-semibold text-[#FF9A63]">Ver metas →</button></div>{data.goals.filter((goal) => !goal.completed).slice(0, 4).length ? <ul className="mt-3 space-y-3">{data.goals.filter((goal) => !goal.completed).slice(0, 4).map((goal) => <li key={goal.id} className="flex items-start gap-3"><span className="mt-1 text-[#FF9A63]">◎</span><span className="text-sm text-white/80">{goal.title}</span></li>)}</ul> : <p className="mt-3 text-sm text-white/45">Você ainda não cadastrou metas. Comece com uma mudança que faça sentido para sua rotina.</p>}</Card>
      </div>
    </>}

    {tab === "training" && <div className="space-y-3">
      <TrainingPlanBuilder userId={userId} />
      <ExerciseLibrary selectedIds={selectedExercises} onToggle={toggleExercise} />
      <div className="grid gap-3 md:grid-cols-[.9fr_1.1fr]">
        <Card className="border-white/10 bg-[#111318] p-5"><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Seu registro</p><h3 className="mt-2 text-lg font-semibold">Registrar treino realizado</h3><form onSubmit={saveTrainingSession} className="mt-4 space-y-3">
          <label className="block text-xs text-white/65">Nome do treino<input className={`${inputClass} mt-1`} value={sessionTitle} onChange={(event) => setSessionTitle(event.target.value)} maxLength={70} required/></label>
          <label className="block text-xs text-white/65">Duração em minutos<input className={`${inputClass} mt-1`} type="number" min="1" max="600" step="1" value={sessionMinutes} onChange={(event) => setSessionMinutes(event.target.value)} required/></label>
          <div className="grid grid-cols-2 gap-2"><label className="block text-xs text-white/65">Séries por exercício<input className={`${inputClass} mt-1`} type="number" min="1" max="20" value={entrySets} onChange={(event) => setEntrySets(event.target.value)} required/></label><label className="block text-xs text-white/65">Repetições<input className={`${inputClass} mt-1`} type="number" min="1" max="300" value={entryReps} onChange={(event) => setEntryReps(event.target.value)} required/></label></div>
          <label className="block text-xs text-white/65">Carga em kg (opcional)<input className={`${inputClass} mt-1`} type="number" min="0" max="1000" step="0.5" value={entryLoad} onChange={(event) => setEntryLoad(event.target.value)} placeholder="Deixe vazio se não se aplicar"/></label>
          <label className="block text-xs text-white/65">Observações (opcional)<textarea className={`${inputClass} mt-1 min-h-20 py-3`} value={sessionNote} onChange={(event) => setSessionNote(event.target.value)} maxLength={240} placeholder="Como foi o treino?"/></label>
          <p className="text-[11px] text-white/45">{selectedExercises.length} exercício(s) selecionado(s). Registre apenas o que realmente realizou.</p>
          <button disabled={selectedExercises.length === 0} className="min-h-11 w-full rounded-xl bg-[#FF762E] px-4 text-sm font-bold text-black disabled:cursor-not-allowed disabled:opacity-40">Salvar treino realizado</button>
        </form></Card>
        <Card className="border-white/10 bg-[#111318] p-5"><div className="flex items-center justify-between"><h3 className="font-semibold">Histórico de treinos</h3><span className="text-xs text-white/40">{data.trainingSessions.length} registro(s)</span></div>{data.trainingSessions.length ? <ul className="mt-3 space-y-3">{data.trainingSessions.slice(0, 12).map((session) => <li key={session.id} className="rounded-xl border border-white/10 bg-white/[.025] p-3"><div className="flex items-start justify-between gap-2"><div><p className="text-sm font-semibold">{session.title}</p><p className="mt-1 text-[10px] text-white/40">{new Date(`${session.date}T12:00:00`).toLocaleDateString("pt-BR")} · {session.durationMinutes} min</p></div><button type="button" onClick={() => setData((current) => ({ ...current, trainingSessions: current.trainingSessions.filter((item) => item.id !== session.id), activities: current.activities.filter((item) => item.trainingSessionId !== session.id && !(item.title === session.title && item.date === session.date && item.minutes === session.durationMinutes && item.note === `${session.entries.length} exercício(s) registrado(s)`)) }))} className="text-xs text-white/40 hover:text-red-300">Excluir</button></div><div className="mt-2 flex flex-wrap gap-1.5">{session.entries.map((entry) => <span key={entry.exerciseId} className="rounded-full bg-white/5 px-2 py-1 text-[10px] text-white/65">{entry.exerciseName} · {entry.sets}×{entry.reps}{entry.loadKg !== undefined ? ` · ${entry.loadKg} kg` : ""}</span>)}</div>{session.note && <p className="mt-2 text-xs text-white/45">{session.note}</p>}</li>)}</ul> : <p className="mt-4 text-sm text-white/45">Seus treinos registrados aparecerão aqui.</p>}</Card>
      </div>
      <p className="text-[10px] leading-5 text-white/35">Segurança: não inicie exercícios se estiver com dor, mal-estar ou sintomas incomuns. Procure orientação profissional para definir exercícios e cargas adequados ao seu caso.</p>
    </div>}

    {tab === "activities" && <div className="grid gap-3 md:grid-cols-[.85fr_1.15fr]">
      <Card className="border-white/10 bg-[#111318] p-5"><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Registro pessoal</p><h3 className="mt-2 text-lg font-semibold">Registrar atividade</h3><p className="mt-1 text-xs leading-5 text-white/45">Registre o que você realmente fez. Este espaço não substitui uma prescrição de treino.</p><form onSubmit={addActivity} className="mt-4 space-y-3"><label className="block text-xs text-white/65">Atividade<input className={`${inputClass} mt-1`} value={activityTitle} onChange={(e) => setActivityTitle(e.target.value)} placeholder="Ex.: caminhada, musculação…" maxLength={70} required/></label><label className="block text-xs text-white/65">Duração em minutos<input className={`${inputClass} mt-1`} type="number" min="1" max="600" step="1" value={activityMinutes} onChange={(e) => setActivityMinutes(e.target.value)} required/></label><label className="block text-xs text-white/65">Observação (opcional)<input className={`${inputClass} mt-1`} value={activityNote} onChange={(e) => setActivityNote(e.target.value)} placeholder="Como foi?" maxLength={160}/></label><button className="min-h-11 w-full rounded-xl bg-[#FF762E] px-4 text-sm font-bold text-black transition hover:bg-[#ff925c]">Salvar atividade</button></form></Card>
      <Card className="border-white/10 bg-[#111318] p-5"><h3 className="font-semibold">Seu histórico</h3>{data.activities.length ? <ul className="mt-3 divide-y divide-white/10">{data.activities.slice(0, 12).map((item) => <li key={item.id} className="flex items-start justify-between gap-3 py-3"><div><p className="text-sm font-medium">{item.title}</p><p className="mt-1 text-xs text-white/45">{new Date(`${item.date}T12:00:00`).toLocaleDateString("pt-BR")} · {item.minutes} min{item.note ? ` · ${item.note}` : ""}</p></div><button onClick={() => removeItem("activity", item.id)} className="min-h-9 px-2 text-xs text-white/40 hover:text-red-300" aria-label={`Excluir ${item.title}`}>Excluir</button></li>)}</ul> : <p className="mt-4 text-sm text-white/45">Nenhuma atividade registrada ainda. Seu histórico começa quando você registra a primeira.</p>}</Card>
    </div>}

    {tab === "habits" && <div className="grid gap-3 md:grid-cols-[.85fr_1.15fr]">
      <Card className="border-white/10 bg-[#111318] p-5"><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Pequenas ações</p><h3 className="mt-2 text-lg font-semibold">Criar hábito</h3><form onSubmit={addHabit} className="mt-4 space-y-3"><label className="block text-xs text-white/65">Qual hábito deseja desenvolver?<input className={`${inputClass} mt-1`} value={habitTitle} onChange={(e) => setHabitTitle(e.target.value)} placeholder="Ex.: beber água ao acordar" maxLength={70} required/></label><label className="block text-xs text-white/65">Frequência<select className={`${inputClass} mt-1`} value={habitFrequency} onChange={(e) => setHabitFrequency(e.target.value as "daily" | "weekly")}><option value="daily">Todos os dias</option><option value="weekly">Ao longo da semana</option></select></label><button className="min-h-11 w-full rounded-xl bg-[#FF762E] px-4 text-sm font-bold text-black">Adicionar hábito</button></form></Card>
      <Card className="border-white/10 bg-[#111318] p-5"><div className="flex items-center justify-between"><h3 className="font-semibold">Minha lista</h3><span className="text-xs text-white/40">{completedHabits} de {data.habits.length} no período</span></div>{data.habits.length ? <ul className="mt-3 space-y-2">{data.habits.map((habit) => <li key={habit.id} className="flex items-center gap-2 rounded-xl bg-white/[.035] p-3"><button onClick={() => toggleHabit(habit.id)} className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border text-xs ${isHabitDone(habit, today, currentWeek) ? "border-[#FF762E] bg-[#FF762E] text-black" : "border-white/25 text-transparent"}`} aria-label={`${isHabitDone(habit, today, currentWeek) ? "Desmarcar" : "Concluir"} ${habit.title} (${habit.frequency === "daily" ? "diário" : "semanal"})`}>✓</button><span className="min-w-0 flex-1"><span className="block text-sm">{habit.title}</span><span className="text-[10px] text-white/40">{habit.frequency === "daily" ? "Diário" : "Semanal"} · {habit.doneDates.length} conclusões</span></span><button onClick={() => removeItem("habit", habit.id)} className="px-2 text-xs text-white/40 hover:text-red-300">Excluir</button></li>)}</ul> : <p className="mt-4 text-sm text-white/45">Nenhum hábito cadastrado. Escolha algo simples para começar.</p>}</Card>
    </div>}

    {tab === "goals" && <div className="grid gap-3 md:grid-cols-[.85fr_1.15fr]">
      <Card className="border-white/10 bg-[#111318] p-5"><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Direção</p><h3 className="mt-2 text-lg font-semibold">Criar uma meta</h3><form onSubmit={addGoal} className="mt-4 space-y-3"><label className="block text-xs text-white/65">O que deseja alcançar?<input className={`${inputClass} mt-1`} value={goalTitle} onChange={(e) => setGoalTitle(e.target.value)} placeholder="Ex.: caminhar 3 vezes na semana" maxLength={90} required/></label><label className="block text-xs text-white/65">Por que isso importa? (opcional)<textarea className={`${inputClass} mt-1 min-h-20 py-3`} value={goalDetail} onChange={(e) => setGoalDetail(e.target.value)} placeholder="Escreva uma razão importante para você…" maxLength={240}/></label><button className="min-h-11 w-full rounded-xl bg-[#FF762E] px-4 text-sm font-bold text-black">Salvar meta</button></form></Card>
      <Card className="border-white/10 bg-[#111318] p-5"><div className="flex items-center justify-between"><h3 className="font-semibold">Minha jornada</h3><span className="text-xs text-white/40">{activeGoals} em andamento</span></div>{data.goals.length ? <ul className="mt-3 space-y-2">{data.goals.map((goal) => <li key={goal.id} className="flex items-start gap-3 rounded-xl bg-white/[.035] p-3"><button onClick={() => toggleGoal(goal.id)} className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border text-xs ${goal.completed ? "border-emerald-400 bg-emerald-400 text-black" : "border-white/25 text-transparent"}`} aria-label={`Alterar status de ${goal.title}`}>✓</button><span className="min-w-0 flex-1"><span className={`block text-sm ${goal.completed ? "text-white/40 line-through" : "text-white"}`}>{goal.title}</span>{goal.detail && <span className="mt-1 block text-xs text-white/45">{goal.detail}</span>}<span className="mt-1 block text-[10px] text-white/30">Criada em {new Date(`${goal.createdAt}T12:00:00`).toLocaleDateString("pt-BR")}</span></span><button onClick={() => removeItem("goal", goal.id)} className="px-2 text-xs text-white/40 hover:text-red-300">Excluir</button></li>)}</ul> : <p className="mt-4 text-sm text-white/45">Nenhuma meta criada. Defina um objetivo realista e que faça sentido para você.</p>}</Card>
    </div>}
    <p className="text-center text-[10px] leading-5 text-white/30">Seus registros desta versão ficam armazenados neste navegador e neste dispositivo. Ainda não há sincronização entre aparelhos.</p>
  </section>;
}
