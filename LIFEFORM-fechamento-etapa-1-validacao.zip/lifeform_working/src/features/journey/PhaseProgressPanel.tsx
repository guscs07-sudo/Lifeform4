"use client";

import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/Card";
import type { PhaseId } from "@/config/phases";
import { assessPhaseProgress } from "@/lib/journey/phaseProgression";
import { buildPhaseReadinessEvidence, type ReadinessActivity, type ReadinessHabit, type ReadinessReview } from "@/lib/journey/phaseReadiness";

const PHASE_LABELS: Record<PhaseId, string> = {
  reconstruction: "Reconstrução",
  development: "Desenvolvimento",
  evolution: "Evolução",
  consolidation: "Consolidação",
};

export function PhaseProgressPanel({
  userId,
  initialPhase,
  activities,
  habits,
  reviews,
  hasUnresolvedSafetyConcern = false,
}: {
  userId: string;
  initialPhase: PhaseId;
  activities: ReadinessActivity[];
  habits: ReadinessHabit[];
  reviews: ReadinessReview[];
  hasUnresolvedSafetyConcern?: boolean;
}) {
  const storageKey = `lifeform:phase:v1:${userId}`;
  const [phase, setPhase] = useState<PhaseId>(initialPhase);
  const [loadedStorageKey, setLoadedStorageKey] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const loaded = loadedStorageKey === storageKey;

  useEffect(() => {
    setLoadedStorageKey(null);
    setPhase(initialPhase);
    setConfirmed(false);
    try {
      const saved = window.localStorage.getItem(storageKey);
      if (saved && Object.prototype.hasOwnProperty.call(PHASE_LABELS, saved)) setPhase(saved as PhaseId);
    } catch { /* armazenamento local pode estar indisponível */ }
    setLoadedStorageKey(storageKey);
  }, [storageKey, initialPhase]);

  const assessment = useMemo(() => assessPhaseProgress(buildPhaseReadinessEvidence({
    currentPhase: phase,
    activities,
    habits,
    reviews,
    hasUnresolvedSafetyConcern,
  })), [phase, activities, habits, reviews, hasUnresolvedSafetyConcern]);

  function confirmAdvance() {
    if (!loaded || !assessment.canAdvance || assessment.recommendedPhase === phase) return;
    try { window.localStorage.setItem(storageKey, assessment.recommendedPhase); } catch { /* a fase continua válida nesta sessão */ }
    setPhase(assessment.recommendedPhase);
    setConfirmed(true);
  }

  const signalLabel = assessment.signal === "advance" ? "Pronto para avançar" : assessment.signal === "recover" ? "Progressão pausada por segurança" : assessment.signal === "simplify" ? "Priorize uma semana mais leve" : "Continue construindo consistência";

  return (
    <Card aria-busy={!loaded} className="border-[#FF762E]/25 bg-[linear-gradient(145deg,rgba(255,118,46,.09),rgba(17,19,24,.98)_70%)] p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Evolução por fases</p>
          <h3 className="mt-1 text-lg font-semibold">{PHASE_LABELS[phase]}</h3>
          <p className="mt-1 text-xs leading-5 text-white/55">{signalLabel}</p>
        </div>
        <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-white/60">{assessment.progressPercent}% dos critérios</span>
      </div>
      <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-[#FF762E] to-[#FFB07D] transition-all" style={{ width: `${assessment.progressPercent}%` }} /></div>
      {assessment.reasons.length > 0 && <ul className="mt-4 space-y-2">{assessment.reasons.map((reason) => <li key={reason} className="flex gap-2 text-xs leading-5 text-white/65"><span className="text-[#FF9A63]">•</span>{reason}</li>)}</ul>}
      {!loaded ? <p role="status" className="mt-4 text-xs text-white/45">Carregando a fase deste perfil…</p> : assessment.canAdvance ? <div className="mt-4 rounded-xl border border-[#FF762E]/25 bg-[#FF762E]/[.07] p-3"><p className="text-sm font-semibold">Próxima fase: {PHASE_LABELS[assessment.recommendedPhase]}</p><p className="mt-1 text-xs leading-5 text-white/55">Os critérios registrados foram alcançados. A mudança só acontece quando você confirmar.</p><button type="button" onClick={confirmAdvance} disabled={!loaded} className="mt-3 min-h-10 rounded-xl bg-[#FF762E] px-4 text-xs font-bold text-black disabled:opacity-50">Confirmar mudança de fase</button></div> : assessment.nextCriteria.length > 0 && <div className="mt-4"><p className="text-[10px] font-semibold uppercase tracking-wider text-white/40">O que falta observar</p><ul className="mt-2 space-y-2">{assessment.nextCriteria.map((criterion) => <li key={criterion} className="text-xs leading-5 text-white/55">— {criterion}</li>)}</ul></div>}
      {confirmed && <p role="status" className="mt-3 text-xs text-emerald-300">Fase atualizada neste dispositivo e neste perfil.</p>}
      <p className="mt-4 text-[10px] leading-5 text-white/30">A recomendação usa atividades, hábitos e revisões registradas. Não é avaliação clínica. A mudança exige sua confirmação.</p>
    </Card>
  );
}
