import { PillarGlyph } from "@/components/brand/PillarGlyph";
import { AssetImage } from "@/components/media/AssetImage";
import { Card } from "@/components/ui/Card";
import { PILLARS } from "@/config/pillars";
import { t } from "@/i18n";

export function Pillars() {
  return (
    <section aria-labelledby="pillars-title" className="mx-auto w-full max-w-md px-5 py-14">
      <h2 id="pillars-title" className="font-display text-2xl font-semibold">
        {t("landing.pillars.title")}
      </h2>
      <p className="mt-2 text-lf-gray-300">{t("landing.pillars.intro")}</p>
      <ul className="mt-6 grid gap-3">
        {PILLARS.map((pillar) => (
          <li key={pillar.id}>
            <Card className="flex items-center gap-4 overflow-hidden">
              <AssetImage
                slotId={`${pillar.id === "mind" ? "anime" : "photo"}.pillars/${pillar.id}`}
                className="h-24 w-20 shrink-0"
                fill
                sizes="80px"
                quietFallback
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <PillarGlyph id={pillar.id} className="h-7 w-7 shrink-0 text-lf-accent" />
                  <h3 className="font-display text-lg">{t(pillar.titleKey)}</h3>
                </div>
                <p className="mt-1 text-sm text-lf-gray-300">{t(pillar.summaryKey)}</p>
              </div>
            </Card>
          </li>
        ))}
      </ul>
    </section>
  );
}
