import Link from "next/link";
import { GeometricOrnament } from "@/components/brand/GeometricOrnament";
import { Logo } from "@/components/brand/Logo";
import { AssetImage } from "@/components/media/AssetImage";
import { buttonClasses } from "@/components/ui/Button";
import { t } from "@/i18n";

const delay = (ms: number) => ({ animationDelay: `${ms}ms` });

/**
 * Abertura da página inicial.
 * - Fundo: slot de ilustração "boas-vindas" (anime). Sem arquivo, aparece só o gradiente.
 * - Símbolo da marca: espaço reservado até o arquivo oficial ser adicionado.
 */
export function Hero() {
  return (
    <section className="relative isolate flex min-h-[88dvh] flex-col justify-between overflow-hidden px-5 pb-10 pt-6">
      <AssetImage
        slotId="anime.onboarding/welcome"
        fill
        priority
        quietFallback
        className="absolute inset-0 -z-20 rounded-none opacity-80"
      />
      <div aria-hidden className="absolute inset-0 -z-10 bg-gradient-to-b from-lf-ink/30 via-lf-ink/70 to-lf-ink" />
      <GeometricOrnament className="absolute -right-28 top-24 -z-10 h-[420px] w-[420px] animate-spin-slow text-lf-accent/30" />

      <header className="mx-auto w-full max-w-md animate-fade-up">
        <Logo reserveSpace size={48} />
      </header>

      <div className="mx-auto flex w-full max-w-md flex-col gap-5">
        <p
          className="animate-fade-up text-xs font-medium uppercase tracking-[0.25em] text-lf-accent"
          style={delay(150)}
        >
          {t("landing.eyebrow")}
        </p>
        <h1
          className="animate-fade-up font-display text-5xl font-semibold leading-[1.05]"
          style={delay(280)}
        >
          {t("app.tagline")}
        </h1>
        <p className="animate-fade-up text-lg text-lf-gray-300" style={delay(410)}>
          {t("landing.heroText")}
        </p>
        <div className="flex animate-fade-up flex-col gap-3 pt-2" style={delay(540)}>
          <Link href="/cadastro" className={buttonClasses({ size: "lg", fullWidth: true })}>
            {t("landing.ctaStart")}
          </Link>
          <Link href="/entrar" className={buttonClasses({ variant: "secondary", fullWidth: true })}>
            {t("landing.ctaLogin")}
          </Link>
        </div>
      </div>
    </section>
  );
}
