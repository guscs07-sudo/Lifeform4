import { t } from "@/i18n";

const STEPS = ["assessment", "program", "evolution"] as const;

export function HowItWorks() {
  return (
    <section aria-labelledby="how-title" className="mx-auto w-full max-w-md px-5 pb-14">
      <h2 id="how-title" className="font-display text-2xl font-semibold">
        {t("landing.how.title")}
      </h2>
      <ol className="mt-6 flex flex-col gap-6">
        {STEPS.map((step, index) => (
          <li key={step} className="flex gap-4">
            <span
              aria-hidden
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-lf-accent/60 font-display text-sm text-lf-accent"
            >
              {String(index + 1).padStart(2, "0")}
            </span>
            <div>
              <h3 className="font-display text-lg">{t(`landing.how.${step}.title`)}</h3>
              <p className="mt-1 text-sm text-lf-gray-300">{t(`landing.how.${step}.text`)}</p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
