"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Button, buttonClasses } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { FormAlert } from "@/components/ui/FormAlert";
import { LoadingState } from "@/components/ui/StateViews";
import { useAuthService } from "@/features/auth/useAuthService";
import { buildDiagnosis } from "@/lib/assessment/diagnosis";
import type { AssessmentAnswers } from "@/lib/assessment/questions";
import { JourneyWorkspace } from "@/features/journey/JourneyWorkspace";
import { generatePersonalizedJourney } from "@/lib/journey/generator";
import { getSupabaseBrowserClient } from "@/lib/supabase/browser";
import { isAssessmentAnswers } from "@/lib/assessment/cloudAssessment";

const STORAGE_PREFIX = "lifeform:assessment:v1:";
interface SavedAssessment { answers?: AssessmentAnswers; completedAt?: string }

const PILLARS = [
  { id: "body", label: "Corpo", icon: "✳", color: "#FF762E", description: "Movimento, força e autocuidado" },
  { id: "mind", label: "Mente", icon: "◈", color: "#B58BFF", description: "Foco, disciplina e consistência" },
  { id: "lifestyle", label: "Estilo de vida", icon: "⌁", color: "#54D6C5", description: "Rotina, descanso e equilíbrio" },
] as const;

export function DashboardGate() {
  const router = useRouter();
  const auth = useAuthService();
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("Sua jornada");
  const [userId, setUserId] = useState<string>("");
  const [answers, setAnswers] = useState<AssessmentAnswers | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [signingOut, setSigningOut] = useState(false);

  useEffect(() => {
    let active = true;
    async function load() {
      if (!auth.isConfigured) {
        if (active) { setNotice("O acesso ao painel será liberado quando a autenticação do LIFEFORM estiver conectada."); setLoading(false); }
        return;
      }
      const result = await auth.getUser();
      if (!active) return;
      if (!result.ok || !result.data) {
        router.replace("/entrar");
        return;
      }
      setUserId(result.data.id);
      setName(result.data.name?.trim() || result.data.email.split("@")[0] || "Sua jornada");
      let localCompleted: AssessmentAnswers | null = null;
      try {
        const raw = window.localStorage.getItem(`${STORAGE_PREFIX}${result.data.id}`);
        if (raw) {
          const saved = JSON.parse(raw) as SavedAssessment;
          if (saved.completedAt && isAssessmentAnswers(saved.answers)) localCompleted = saved.answers;
        }
      } catch {
        // Se o rascunho local estiver inválido, tentamos recuperar a avaliação concluída da conta.
      }
      if (localCompleted) {
        setAnswers(localCompleted);
      } else {
        const supabase = getSupabaseBrowserClient();
        if (!supabase) {
          router.replace("/avaliacao");
          return;
        }
        const { data: remote, error } = await supabase.from("assessments")
          .select("answers, status, completed_at")
          .eq("user_id", result.data.id)
          .eq("status", "completed")
          .not("completed_at", "is", null)
          .order("updated_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        if (!active) return;
        if (error) {
          setNotice("Não foi possível recuperar sua avaliação da nuvem agora. Seus dados não foram alterados; tente novamente em instantes.");
        } else if (remote && isAssessmentAnswers(remote.answers)) {
          setAnswers(remote.answers);
        } else {
          router.replace("/avaliacao");
          return;
        }
      }
      setLoading(false);
    }
    void load();
    return () => { active = false; };
  }, [auth, router]);

  const diagnosis = useMemo(() => answers ? buildDiagnosis(answers) : null, [answers]);
  const personalizedJourney = useMemo(() => answers && diagnosis ? generatePersonalizedJourney(answers, diagnosis.priority) : null, [answers, diagnosis]);

  async function signOut() {
    setSigningOut(true);
    const result = await auth.signOut();
    if (result.ok) router.replace("/entrar");
    else setSigningOut(false);
  }

  if (loading) return <main className="mx-auto flex min-h-dvh w-full max-w-5xl items-center px-5"><LoadingState /></main>;
  if (notice || !diagnosis) {
    return <main className="mx-auto flex min-h-dvh w-full max-w-xl flex-col justify-center gap-5 px-5 py-12"><div className="lf-brand-mark">LIFEFORM<span>.</span></div><FormAlert variant="info">{notice ?? "Seu diagnóstico ainda não está disponível."}</FormAlert><Link href="/avaliacao" className={buttonClasses({ size: "lg", fullWidth: true })}>Ir para minha avaliação</Link></main>;
  }

  const priority = diagnosis.pillars.find((pillar) => pillar.id === diagnosis.priority);
  const firstName = name.split(/[\s@]/)[0];
  const today = new Intl.DateTimeFormat("pt-BR", { weekday: "long", day: "numeric", month: "long" }).format(new Date());

  return (
    <main className="min-h-dvh bg-[#08090c] pb-28 text-white">
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-7 px-5 pb-10 pt-7 sm:px-8 sm:pt-10">
        <header className="flex items-center justify-between gap-4">
          <Link href="/painel" aria-label="LIFEFORM início" className="lf-brand-mark">LIFEFORM<span>.</span></Link>
          <div className="flex items-center gap-3">
            <span className="hidden text-right sm:block"><span className="block text-xs text-white/45">SEU ESPAÇO</span><span className="text-sm font-medium">{firstName}</span></span>
            <button type="button" onClick={() => void signOut()} disabled={signingOut} className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-white/5 text-sm text-white/70 transition hover:border-lf-accent/60 hover:text-white" aria-label="Sair da conta">↗</button>
          </div>
        </header>

        <section className="lf-dashboard-hero relative isolate overflow-hidden rounded-[1.75rem] border border-white/10 p-6 sm:p-9">
          <div className="lf-dashboard-orbit" aria-hidden="true"><span/><span/><span/></div>
          <div className="relative z-10 max-w-xl">
            <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-[#FF9A63]">{today}</p>
            <h1 className="mt-3 font-display text-3xl font-semibold leading-tight sm:text-5xl">Olá, {firstName}.<br/><span className="text-white/65">Vamos continuar sua evolução.</span></h1>
            <p className="mt-3 max-w-md text-sm leading-6 text-white/65">Seu painel começa com o que você compartilhou. O próximo passo é construir consistência, no seu ritmo.</p>
            <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-[#FF762E]/35 bg-[#FF762E]/10 px-4 py-2 text-xs font-semibold text-[#FFAD83]"><span className="h-2 w-2 rounded-full bg-[#FF762E] shadow-[0_0_12px_#ff762e]"/> FASE ATUAL · {diagnosis.phaseTitle.toUpperCase()}</div>
          </div>
        </section>

        <section className="grid gap-3 sm:grid-cols-[1.1fr_.9fr]">
          <Card className="border-white/10 bg-[#111318]">
            <p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#FF9A63]">Seu ponto de partida</p>
            <h2 className="mt-2 font-display text-2xl font-semibold">{diagnosis.phaseTitle}</h2>
            <p className="mt-2 text-sm leading-6 text-white/60">{diagnosis.phaseReason}</p>
            <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-4"><span className="text-xs text-white/45">Respostas consideradas</span><strong className="text-sm">{diagnosis.overallCoverage}%</strong></div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-[#FF762E]" style={{ width: `${diagnosis.overallCoverage}%` }}/></div>
          </Card>
          <Card className="border-[#FF762E]/25 bg-[linear-gradient(145deg,rgba(255,118,46,.12),rgba(17,19,24,.96)_65%)]">
            <p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#FF9A63]">Prioridade de atenção</p>
            <div className="mt-3 flex items-center gap-3"><span className="flex h-12 w-12 items-center justify-center rounded-2xl border border-[#FF762E]/30 bg-[#FF762E]/10 text-2xl">◎</span><h2 className="font-display text-2xl font-semibold">{priority?.title ?? "Seu próximo passo"}</h2></div>
            <p className="mt-3 text-sm leading-6 text-white/65">{diagnosis.priorityReason}</p>
            <Link href="/avaliacao" className="mt-4 inline-flex min-h-10 items-center text-sm font-semibold text-[#FF9A63]">Rever diagnóstico <span className="ml-2">→</span></Link>
          </Card>
        </section>

        {personalizedJourney && <section className="space-y-3" id="plano-inicial">
          <div><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#FF9A63]">Plano gerado pela sua avaliação</p><h2 className="mt-1 font-display text-2xl font-semibold">{personalizedJourney.title}</h2><p className="mt-1 text-sm text-white/50">{personalizedJourney.subtitle}</p></div>
          <Card className="border-[#FF762E]/25 bg-[linear-gradient(145deg,rgba(255,118,46,.09),rgba(17,19,24,.96)_65%)]">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <div><p className="text-[10px] uppercase tracking-wider text-white/40">Dias de referência</p><p className="mt-1 text-2xl font-semibold">{personalizedJourney.weeklyDays}</p></div>
              <div><p className="text-[10px] uppercase tracking-wider text-white/40">Tempo por sessão</p><p className="mt-1 text-2xl font-semibold">{personalizedJourney.sessionMinutes}<span className="ml-1 text-xs font-normal text-white/45">min</span></p></div>
              <div className="col-span-2 sm:col-span-1"><p className="text-[10px] uppercase tracking-wider text-white/40">Foco escolhido</p><p className="mt-1 text-lg font-semibold">{personalizedJourney.focus === "body" ? "Corpo" : personalizedJourney.focus === "mind" ? "Mente" : "Estilo de vida"}</p></div>
            </div>
            {personalizedJourney.safetyNote && <div className="mt-4 rounded-xl border border-amber-300/20 bg-amber-300/[.06] p-3 text-xs leading-5 text-amber-100/80">{personalizedJourney.safetyNote}</div>}
            <div className="mt-5"><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Sua semana sugerida</p><div className="mt-3 grid gap-2 sm:grid-cols-2">
              {personalizedJourney.actions.map((action) => <div key={action.id} className="rounded-xl border border-white/10 bg-black/20 p-3"><div className="flex items-center justify-between gap-2"><span className="text-[10px] font-semibold uppercase tracking-wider text-[#FFAD83]">{action.dayLabel}</span><span className="text-[10px] text-white/35">{action.durationMinutes ? `${action.durationMinutes} min` : "A combinar"}</span></div><p className="mt-1 text-sm font-semibold">{action.title}</p><p className="mt-1 text-xs leading-5 text-white/55">{action.description}</p></div>)}
            </div></div>
            <div className="mt-5 border-t border-white/10 pt-4"><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Hábitos para desenvolver</p><div className="mt-2 flex flex-wrap gap-2">{personalizedJourney.habits.map((habit) => <span key={habit.title} className="rounded-full border border-white/10 bg-white/[.04] px-3 py-2 text-xs text-white/70">{habit.title}</span>)}</div></div>
            <p className="mt-4 text-[10px] leading-5 text-white/35">Proposta organizacional gerada por regras a partir das suas respostas. Não é prescrição de exercícios, cargas ou orientação médica. Você pode ajustar o planejamento na sua jornada.</p>
          </Card>
        </section>}

        <section className="space-y-3" id="pilares" className="scroll-mt-24">
          <div className="flex items-end justify-between gap-3"><div><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#FF9A63]">Visão geral</p><h2 className="mt-1 font-display text-2xl font-semibold">Seus três pilares</h2></div><span className="text-[10px] text-white/35">BASEADO NA AVALIAÇÃO</span></div>
          <div className="grid gap-3 md:grid-cols-3">
            {PILLARS.map((item) => {
              const data = diagnosis.pillars.find((pillar) => pillar.id === item.id);
              const score = data?.score ?? null;
              return <Card key={item.id} className="border-white/10 bg-[#111318] p-4 sm:p-5">
                <div className="flex items-center justify-between"><span className="flex h-10 w-10 items-center justify-center rounded-xl text-xl" style={{ color: item.color, backgroundColor: `${item.color}18` }}>{item.icon}</span><span className="font-display text-2xl font-semibold" style={{ color: item.color }}>{score === null ? "—" : `${score}%`}</span></div>
                <h3 className="mt-4 font-semibold">{item.label}</h3><p className="mt-1 text-xs text-white/45">{item.description}</p>
                <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full transition-all" style={{ width: `${score ?? 0}%`, backgroundColor: item.color }}/></div>
                <p className="mt-3 text-xs leading-5 text-white/55">{data?.level === "insufficient_data" ? "Ainda precisamos de mais respostas para mostrar este indicador." : data?.summary}</p>
              </Card>;
            })}
          </div>
          <p className="text-[11px] leading-5 text-white/35">Os indicadores refletem respostas autorreferidas. Não são notas clínicas nem medem seu valor pessoal.</p>
        </section>

        <section className="grid gap-3 md:grid-cols-2">
          <Card className="border-white/10 bg-[#111318]">
            <div className="flex items-center gap-3"><span className="text-xl text-[#FF9A63]">✦</span><div><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#FF9A63]">Direção da jornada</p><h2 className="mt-1 font-display text-xl font-semibold">Seu objetivo</h2></div></div>
            <p className="mt-4 text-sm leading-6 text-white/65">{diagnosis.goalSummary}</p>
          </Card>
          <Card className="border-white/10 bg-[#111318]">
            <div className="flex items-center gap-3"><span className="text-xl text-[#FF9A63]">↗</span><div><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#FF9A63]">Comece com leveza</p><h2 className="mt-1 font-display text-xl font-semibold">Seu foco inicial</h2></div></div>
            <ul className="mt-4 space-y-3">{diagnosis.nextSteps.slice(0, 2).map((step, index) => <li key={step} className="flex gap-3 text-sm leading-6 text-white/65"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#FF762E]/15 text-xs font-semibold text-[#FF9A63]">{index + 1}</span>{step}</li>)}</ul>
          </Card>
        </section>

        {diagnosis.safety.needsProfessionalGuidance && <FormAlert variant="info">{diagnosis.safety.message}</FormAlert>}

        <section className="space-y-3" id="jornada" className="scroll-mt-24">
          <div><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#FF9A63]">Sua plataforma</p><h2 className="mt-1 font-display text-2xl font-semibold">Sua jornada, por inteiro.</h2><p className="mt-1 text-sm text-white/50">Registre suas atividades, construa hábitos e acompanhe metas no seu ritmo.</p></div>
          <JourneyWorkspace key={userId} userId={userId} initialPhase={diagnosis.phase} safetyHold={diagnosis.safety.needsProfessionalGuidance} />
        </section>

        <div className="flex flex-col gap-3 sm:flex-row"><Link href="/avaliacao" className={buttonClasses({ size: "lg", fullWidth: true })}>Ver meu diagnóstico completo <span>→</span></Link><Button variant="secondary" size="lg" fullWidth onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>Voltar ao início</Button></div>
        <p className="text-center text-[10px] leading-5 text-white/30">LIFEFORM · Transforme sua vida. · Seus dados desta versão estão salvos neste dispositivo.</p>
      </div>
      <nav aria-label="Navegação principal" className="fixed inset-x-0 bottom-0 z-30 border-t border-white/10 bg-[#090a0df2] px-3 pb-[max(env(safe-area-inset-bottom),10px)] pt-2 backdrop-blur-xl">
        <div className="mx-auto grid max-w-lg grid-cols-4 gap-1">{[{href:"/painel",icon:"⌂",label:"Início",active:true},{href:"#pilares",icon:"◫",label:"Evolução"},{href:"#jornada",icon:"✦",label:"Minha jornada"},{href:"/avaliacao",icon:"◎",label:"Diagnóstico"}].map((item) => <a key={item.label} href={item.href} className={`flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl text-[10px] ${item.active ? "text-[#FF9A63]" : "text-white/45 hover:text-white"}`}><span className="text-xl leading-none">{item.icon}</span>{item.label}</a>)}</div>
      </nav>
    </main>
  );
}
