"use client";

import { useMemo, useState } from "react";
import { AssetImage } from "@/components/media/AssetImage";
import { Card } from "@/components/ui/Card";
import { EXERCISES, searchExercises, type ExerciseCategory } from "@/content/training/exercises";

const FILTERS: Array<{ id: ExerciseCategory | "todos"; label: string }> = [
  { id: "todos", label: "Todos" },
  { id: "forca", label: "Força" },
  { id: "mobilidade", label: "Mobilidade" },
  { id: "core", label: "Core" },
  { id: "cardio", label: "Cardio" },
];

export function ExerciseLibrary({ selectedIds, onToggle }: { selectedIds: string[]; onToggle: (id: string) => void }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<ExerciseCategory | "todos">("todos");
  const [expanded, setExpanded] = useState<string | null>(null);
  const exercises = useMemo(() => searchExercises(query, category), [query, category]);

  return <section className="space-y-3" aria-label="Biblioteca de exercícios">
    <Card className="overflow-hidden border-[#FF762E]/25 bg-[#111318] p-0">
      <div className="grid sm:grid-cols-[.8fr_1.2fr]">
        <AssetImage slotId="photo.training/library" className="h-full min-h-40 rounded-none" fill quietFallback sizes="(max-width: 640px) 100vw, 40vw" />
        <div className="p-5">
          <p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Biblioteca de movimentos</p>
          <h3 className="mt-2 text-xl font-semibold">Aprenda cada movimento</h3>
          <p className="mt-2 text-xs leading-5 text-white/55">Consulte músculos envolvidos, execução, erros frequentes e alternativas por nível. As variações são referências educativas, não uma prescrição individual.</p>
          <p className="mt-3 text-[10px] text-white/40">{EXERCISES.length} movimentos catalogados nesta versão</p>
        </div>
      </div>
    </Card>

    <div className="space-y-3">
      <label className="block">
        <span className="sr-only">Buscar exercício</span>
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar exercício ou músculo..." className="min-h-11 w-full rounded-xl border border-white/10 bg-[#111318] px-4 text-sm text-white outline-none placeholder:text-white/35 focus:border-[#FF762E]/70" />
      </label>
      <div className="flex gap-2 overflow-x-auto pb-1" aria-label="Filtrar por categoria">
        {FILTERS.map((filter) => <button key={filter.id} type="button" onClick={() => setCategory(filter.id)} aria-pressed={category === filter.id} className={`shrink-0 rounded-full border px-3 py-2 text-xs font-semibold transition ${category === filter.id ? "border-[#FF762E] bg-[#FF762E] text-black" : "border-white/10 bg-white/5 text-white/65"}`}>{filter.label}</button>)}
      </div>
      {exercises.length ? <div className="grid gap-3 md:grid-cols-2">
        {exercises.map((exercise) => {
          const isExpanded = expanded === exercise.id;
          const isSelected = selectedIds.includes(exercise.id);
          return <Card key={exercise.id} className="border-white/10 bg-[#111318] p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0"><h4 className="font-semibold">{exercise.name}</h4><p className="mt-1 text-[11px] text-[#FF9A63]">{exercise.focus}</p></div>
              <span className="shrink-0 rounded-full bg-white/5 px-2 py-1 text-[10px] text-white/45">{exercise.level}</span>
            </div>
            <p className="mt-3 text-[11px] leading-5 text-white/55"><span className="text-white/80">Equipamento:</span> {exercise.equipment}</p>
            <div className="mt-2 flex flex-wrap gap-1.5">{exercise.muscles.map((muscle) => <span key={muscle} className="rounded-full border border-white/10 bg-white/[.035] px-2 py-1 text-[10px] text-white/60">{muscle}</span>)}</div>
            <button type="button" onClick={() => setExpanded(isExpanded ? null : exercise.id)} aria-expanded={isExpanded} className="mt-3 min-h-10 w-full rounded-xl border border-white/10 bg-white/[.035] px-3 text-xs font-semibold text-white/75">{isExpanded ? "Ocultar detalhes −" : "Ver execução, erros e alternativas +"}</button>
            {isExpanded && <div className="mt-3 space-y-3 border-t border-white/10 pt-3">
              <div><p className="text-[10px] font-semibold uppercase tracking-wider text-[#FF9A63]">Como executar</p><ol className="mt-2 space-y-1.5">{exercise.instructions.map((step, index) => <li key={step} className="flex gap-2 text-xs leading-5 text-white/65"><span className="text-[#FF9A63]">{index + 1}.</span>{step}</li>)}</ol></div>
              <div><p className="text-[10px] font-semibold uppercase tracking-wider text-[#FF9A63]">Erros comuns</p><ul className="mt-2 list-disc space-y-1 pl-4 text-xs leading-5 text-white/60">{exercise.commonMistakes.map((mistake) => <li key={mistake}>{mistake}</li>)}</ul></div>
              <div><p className="text-[10px] font-semibold uppercase tracking-wider text-[#FF9A63]">Alternativas por nível</p><div className="mt-2 space-y-1 text-xs text-white/65">{Object.entries(exercise.alternatives).map(([level, alternative]) => <p key={level}><span className="text-white/85">{level}:</span> {alternative}</p>)}</div></div>
              <p className="rounded-lg bg-amber-400/5 p-2 text-[10px] leading-4 text-amber-100/70">Atenção: {exercise.cautions}</p>
            </div>}
            <button type="button" onClick={() => onToggle(exercise.id)} className={`mt-3 min-h-10 w-full rounded-xl border px-3 text-xs font-semibold transition ${isSelected ? "border-[#FF762E] bg-[#FF762E] text-black" : "border-white/10 bg-white/5 text-white/75"}`}>{isSelected ? "Selecionado para registrar ✓" : "Adicionar ao registro"}</button>
          </Card>;
        })}
      </div> : <Card className="border-white/10 bg-[#111318] p-5 text-center"><p className="text-sm text-white/70">Nenhum exercício encontrado.</p><button type="button" onClick={() => { setQuery(""); setCategory("todos"); }} className="mt-2 text-xs font-semibold text-[#FF9A63]">Limpar filtros</button></Card>}
    </div>
  </section>;
}
