"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/Card";
import { AssetImage } from "@/components/media/AssetImage";

type PlanDay = { id: string; day: string; focus: string; minutes: number };
type Plan = { title: string; goal: string; days: PlanDay[]; updatedAt: string };
const DAYS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"];
const FOCI = ["Movimento leve", "Força geral", "Mobilidade", "Condicionamento", "Recuperação", "Livre / descanso"];
const ROUTINE_TEMPLATES = [
  { id: "two-days", label: "2 dias", description: "Começo leve", goal: "Criar consistência", days: [{ day: "Terça", focus: "Movimento leve", minutes: 20 }, { day: "Sexta", focus: "Mobilidade", minutes: 20 }] },
  { id: "three-days", label: "3 dias", description: "Rotina equilibrada", goal: "Equilibrar atividade e recuperação", days: [{ day: "Segunda", focus: "Movimento leve", minutes: 20 }, { day: "Quarta", focus: "Mobilidade", minutes: 20 }, { day: "Sábado", focus: "Recuperação", minutes: 15 }] },
  { id: "four-days", label: "4 dias", description: "Mais opções na semana", goal: "Criar consistência", days: [{ day: "Segunda", focus: "Movimento leve", minutes: 20 }, { day: "Terça", focus: "Mobilidade", minutes: 15 }, { day: "Quinta", focus: "Força geral", minutes: 20 }, { day: "Sábado", focus: "Recuperação", minutes: 15 }] },
];
const field = "min-h-11 w-full rounded-xl border border-white/10 bg-black/30 px-3 text-sm text-white outline-none focus:border-[#FF762E]/70";

/** Organizador de rotina: ajuda a pessoa a planejar dias e foco, sem prescrever exercícios ou cargas. */
export function TrainingPlanBuilder({ userId }: { userId: string }) {
  const key = `lifeform:training-plan:v1:${userId}`;
  const [plan, setPlan] = useState<Plan | null>(null);
  const [title, setTitle] = useState("Minha rotina de movimento");
  const [goal, setGoal] = useState("Criar consistência");
  const [days, setDays] = useState<PlanDay[]>([{ id: "1", day: "Segunda", focus: "Movimento leve", minutes: 20 }, { id: "2", day: "Quarta", focus: "Mobilidade", minutes: 20 }, { id: "3", day: "Sexta", focus: "Movimento leve", minutes: 20 }]);
  const [ready, setReady] = useState(false);
  const [loadedKey, setLoadedKey] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setReady(false);
    setLoadedKey(null);
    setPlan(null);
    setTitle("Minha rotina de movimento");
    setGoal("Criar consistência");
    setDays([{ id: "1", day: "Segunda", focus: "Movimento leve", minutes: 20 }, { id: "2", day: "Quarta", focus: "Mobilidade", minutes: 20 }, { id: "3", day: "Sexta", focus: "Movimento leve", minutes: 20 }]);
    setSaved(false);
    setStorageError(null);
    try {
      const raw = window.localStorage.getItem(key);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (isPlan(parsed)) {
          if (active) { setPlan(parsed); setTitle(parsed.title); setGoal(parsed.goal); setDays(parsed.days); }
        } else if (active) {
          setStorageError("A rotina salva tem um formato inválido. Você pode montar e salvar uma nova rotina para este perfil.");
        }
      }
    } catch {
      if (active) setStorageError("Não foi possível ler a rotina salva neste aparelho.");
    }
    if (active) { setLoadedKey(key); setReady(true); }
    return () => { active = false; };
  }, [key]);

  function applyTemplate(templateId: string) {
    const template = ROUTINE_TEMPLATES.find((item) => item.id === templateId);
    if (!template) return;
    setGoal(template.goal);
    setDays(template.days.map((item, index) => ({ ...item, id: `template-${template.id}-${index}` })));
    setSaved(false);
  }
  function updateDay(id: string, patch: Partial<PlanDay>) { setDays((current) => current.map((item) => item.id === id ? { ...item, ...patch } : item)); setSaved(false); }
  function addDay() { if (days.length >= 7) return; const available = DAYS.find((day) => !days.some((item) => item.day === day)); if (!available) return; setDays((current) => [...current, { id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, day: available, focus: "Movimento leve", minutes: 20 }]); setSaved(false); }
  function save() {
    if (!ready || loadedKey !== key || days.length === 0) return;
    const normalizedTitle = title.trim();
    if (!normalizedTitle || normalizedTitle.length > 70 || days.some((item) => !DAYS.includes(item.day) || !FOCI.includes(item.focus) || !Number.isInteger(item.minutes) || item.minutes < 5 || item.minutes > 240)) {
      setStorageError("Revise o nome e os dias da rotina antes de salvar.");
      return;
    }
    const next: Plan = { title: normalizedTitle, goal, days: [...days].sort((a, b) => DAYS.indexOf(a.day) - DAYS.indexOf(b.day)), updatedAt: new Date().toISOString() };
    try { window.localStorage.setItem(key, JSON.stringify(next)); setPlan(next); setSaved(true); setStorageError(null); }
    catch { setSaved(false); setStorageError("Não foi possível salvar. Verifique o espaço disponível no navegador."); }
  }
  function clear() {
    if (!ready || loadedKey !== key) return;
    try { window.localStorage.removeItem(key); setPlan(null); setSaved(false); setStorageError(null); }
    catch { setStorageError("Não foi possível apagar a rotina salva neste aparelho."); }
  }

  return <Card className="border-[#FF762E]/20 bg-[linear-gradient(145deg,rgba(255,118,46,.08),rgba(17,19,24,.98)_65%)] p-5">
    <div className="mb-4 h-40 overflow-hidden rounded-xl border border-white/10 sm:h-48">
      <AssetImage slotId="photo.training/library" fill sizes="(max-width: 640px) 100vw, 720px" />
    </div>
    <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-[10px] font-semibold uppercase tracking-[.18em] text-[#FF9A63]">Organizador semanal</p><h3 className="mt-2 text-lg font-semibold">Monte sua rotina possível</h3><p className="mt-1 max-w-xl text-xs leading-5 text-white/50">Escolha dias, foco e tempo disponível. O LIFEFORM organiza sua semana sem inventar uma prescrição individual de exercícios.</p></div><span className="rounded-full border border-white/10 px-3 py-1 text-[10px] text-white/45">{days.length} dia(s)</span></div>
    <div className="mt-4">
      <p className="text-[10px] font-semibold uppercase tracking-[.16em] text-white/40">Comece por um modelo editável</p>
      <div className="mt-2 grid gap-2 sm:grid-cols-3">{ROUTINE_TEMPLATES.map((template) => <button key={template.id} type="button" onClick={() => applyTemplate(template.id)} className="min-h-16 rounded-xl border border-white/10 bg-black/20 p-3 text-left transition hover:border-[#FF762E]/50"><span className="block text-sm font-semibold text-white">{template.label}</span><span className="mt-1 block text-[10px] text-white/45">{template.description}</span></button>)}</div>
      <p className="mt-2 text-[10px] leading-4 text-white/35">Os modelos são pontos de partida genéricos, não prescrições. Escolha apenas uma frequência compatível com sua rotina e condição atual.</p>
    </div>
    <div className="mt-4 grid gap-3 sm:grid-cols-2"><label className="block text-xs text-white/60">Nome da rotina<input className={`${field} mt-1`} value={title} onChange={(e) => { setTitle(e.target.value); setSaved(false); }} maxLength={70}/></label><label className="block text-xs text-white/60">Objetivo principal<select className={`${field} mt-1`} value={goal} onChange={(e) => { setGoal(e.target.value); setSaved(false); }}><option>Criar consistência</option><option>Melhorar mobilidade</option><option>Desenvolver força geral</option><option>Melhorar condicionamento</option><option>Equilibrar atividade e recuperação</option></select></label></div>
    <div className="mt-4 space-y-2">{days.map((item) => <div key={item.id} className="grid gap-2 rounded-xl border border-white/10 bg-black/20 p-3 sm:grid-cols-[.8fr_1.3fr_.6fr_auto] sm:items-end"><label className="block text-[10px] text-white/45">Dia<select className={`${field} mt-1`} value={item.day} onChange={(e) => updateDay(item.id, { day: e.target.value })}>{DAYS.map((day) => <option key={day} disabled={days.some((other) => other.id !== item.id && other.day === day)}>{day}</option>)}</select></label><label className="block text-[10px] text-white/45">Foco<select className={`${field} mt-1`} value={item.focus} onChange={(e) => updateDay(item.id, { focus: e.target.value })}>{FOCI.map((focus) => <option key={focus}>{focus}</option>)}</select></label><label className="block text-[10px] text-white/45">Minutos<input className={`${field} mt-1`} type="number" min="5" max="240" step="5" value={item.minutes} onChange={(e) => updateDay(item.id, { minutes: Math.max(5, Math.min(240, Number(e.target.value) || 5)) })}/></label><button type="button" onClick={() => { setDays((current) => current.filter((day) => day.id !== item.id)); setSaved(false); }} className="min-h-11 rounded-xl border border-white/10 px-3 text-xs text-white/50 hover:border-red-400/40 hover:text-red-200" aria-label={`Remover ${item.day}`}>Remover</button></div>)}</div>
    <div className="mt-3 rounded-xl border border-white/10 bg-black/20 p-3">
      <p className="text-[10px] font-semibold uppercase tracking-[.16em] text-[#FF9A63]">Resumo da semana</p>
      <p className="mt-1 text-sm text-white/75">{days.length} dia(s) planejado(s) · {days.reduce((sum, item) => sum + item.minutes, 0)} minutos previstos</p>
      <p className="mt-1 text-[10px] text-white/40">Distribua os dias com pausas adequadas. Você pode editar qualquer modelo antes de salvar.</p>
    </div>
    <div className="mt-3 flex flex-wrap gap-2"><button type="button" disabled={days.length >= 7} onClick={addDay} className="min-h-10 rounded-xl border border-white/15 px-4 text-xs font-semibold text-white/75 disabled:opacity-40">+ Adicionar dia</button><button type="button" onClick={save} disabled={!ready || loadedKey !== key || days.length === 0} className="min-h-10 rounded-xl bg-[#FF762E] px-4 text-xs font-bold text-black disabled:opacity-40">Salvar rotina</button>{plan && <button type="button" disabled={!ready || loadedKey !== key} onClick={clear} className="min-h-10 rounded-xl px-3 text-xs text-white/40 hover:text-red-200">Apagar rotina</button>}</div>
    {saved && <p role="status" className="mt-3 text-xs text-emerald-300">Rotina salva neste dispositivo para este perfil.</p>}
    {plan && !saved && <p className="mt-3 text-[10px] text-white/35">Última rotina salva: {new Date(plan.updatedAt).toLocaleDateString("pt-BR")} · Salve novamente para aplicar suas alterações.</p>}
    <p className="mt-3 border-t border-white/10 pt-3 text-[10px] leading-5 text-white/35">Este organizador não define intensidade, cargas ou exercícios obrigatórios. Ajuste o plano à sua condição e procure orientação profissional quando necessário. Os dados ainda ficam apenas neste navegador.</p>
  </Card>;
}


function isPlan(value: unknown): value is Plan {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const candidate = value as Record<string, unknown>;
  if (typeof candidate.title !== "string" || typeof candidate.goal !== "string" || typeof candidate.updatedAt !== "string" || !Array.isArray(candidate.days)) return false;
  return candidate.days.every((day) => {
    if (!day || typeof day !== "object" || Array.isArray(day)) return false;
    const item = day as Record<string, unknown>;
    return typeof item.id === "string" && DAYS.includes(String(item.day)) && FOCI.includes(String(item.focus)) && typeof item.minutes === "number" && Number.isInteger(item.minutes) && item.minutes >= 5 && item.minutes <= 240;
  });
}
