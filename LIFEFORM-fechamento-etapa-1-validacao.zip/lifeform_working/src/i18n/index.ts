import { ptBR } from "./locales/pt-BR";

/**
 * i18n mínimo e tipado. Para adicionar um idioma:
 *  1. crie src/i18n/locales/<locale>.ts com a mesma estrutura de pt-BR;
 *  2. registre-o em `catalogs` e em `Locale`;
 *  3. o teste de paridade (i18n.test.ts) aponta chaves faltantes.
 */
export type Locale = "pt-BR";
export const DEFAULT_LOCALE: Locale = "pt-BR";

type Dict = { readonly [key: string]: string | Dict };

const catalogs: Record<Locale, Dict> = {
  "pt-BR": ptBR,
};

export type TranslateVars = Record<string, string | number>;

export function getCatalog(locale: Locale): Dict {
  return catalogs[locale];
}

export function resolveKey(dict: Dict, key: string): string | undefined {
  let node: string | Dict | undefined = dict;
  for (const part of key.split(".")) {
    if (typeof node !== "object" || node === null) return undefined;
    node = node[part];
  }
  return typeof node === "string" ? node : undefined;
}

export function createTranslator(locale: Locale = DEFAULT_LOCALE) {
  const dict = catalogs[locale];
  return (key: string, vars?: TranslateVars): string => {
    const raw = resolveKey(dict, key);
    if (raw === undefined) return key; // chave ausente fica visível, nunca quebra a tela
    if (!vars) return raw;
    return raw.replace(/\{(\w+)\}/g, (match, name: string) => {
      const value = vars[name];
      return value === undefined ? match : String(value);
    });
  };
}

export const t = createTranslator();

/** Lista todas as chaves-folha de um catálogo (usado nos testes). */
export function flattenKeys(dict: Dict, prefix = ""): string[] {
  return Object.entries(dict).flatMap(([k, v]) =>
    typeof v === "string" ? [prefix + k] : flattenKeys(v, `${prefix}${k}.`),
  );
}
