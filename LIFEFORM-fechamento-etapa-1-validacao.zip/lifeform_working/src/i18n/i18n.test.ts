import { describe, expect, it } from "vitest";
import { createTranslator, flattenKeys, getCatalog, type Locale } from "@/i18n";

const base = getCatalog("pt-BR");
const locales: Locale[] = ["pt-BR"];

describe("i18n", () => {
  const t = createTranslator("pt-BR");

  it("resolve chaves aninhadas", () => {
    expect(t("app.name")).toBe("LIFEFORM");
  });

  it("interpola variáveis", () => {
    expect(t("assets.alt.anime", { subject: "Treino" })).toBe("Ilustração: Treino");
  });

  it("devolve a própria chave quando ela não existe", () => {
    expect(t("nao.existe")).toBe("nao.existe");
  });

  it("todos os idiomas têm as mesmas chaves de pt-BR", () => {
    const expected = flattenKeys(base).sort();
    for (const locale of locales) {
      expect(flattenKeys(getCatalog(locale)).sort()).toEqual(expected);
    }
  });
});
