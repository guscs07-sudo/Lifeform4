import { existsSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { getSlot, IMAGE_WIDTHS, slotSrc } from "./registry";

const root = process.cwd();

describe("ativos visuais dos pilares", () => {
  it.each([
    ["photo.pillars/body", "Corpo"],
    ["anime.pillars/mind", "Mente"],
    ["photo.pillars/lifestyle", "Estilo de Vida"],
  ])("mantém o slot %s registrado", (id) => {
    expect(getSlot(id)).toBeDefined();
  });

  it.each([
    "photo.pillars/body",
    "anime.pillars/mind",
    "photo.pillars/lifestyle",
  ])("possui variantes responsivas para %s", (id) => {
    const slot = getSlot(id);
    expect(slot).toBeDefined();
    for (const width of IMAGE_WIDTHS) {
      expect(existsSync(join(root, "public", slotSrc(slot!, width).replace(/^\//, "")))).toBe(true);
    }
  });
});
