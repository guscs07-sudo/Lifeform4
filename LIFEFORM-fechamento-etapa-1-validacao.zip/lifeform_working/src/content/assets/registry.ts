import { MODULES, type ModuleId, type Tone } from "@/config/modules";
import { PHASES, type PhaseId } from "@/config/phases";

/**
 * REGISTRO DE SLOTS DE IMAGEM
 * ---------------------------------------------------------------
 * Cada slot é um lugar da experiência que receberá uma imagem definitiva
 * (ilustração anime ou fotografia). Enquanto o arquivo não existir, o
 * componente <AssetImage> mostra um fallback honesto (gradiente + rótulo
 * "Imagem em preparação"), nunca uma imagem genérica de enfeite.
 *
 * Convenção de arquivos (ver docs/VISUAL_ASSETS.md):
 *   public/images/<style>/<slug>-<largura>.webp   (larguras: 480, 960, 1440)
 */

export type ImageStyle = "anime" | "photo";
export type Aspect = "16:9" | "4:5" | "1:1";

export const IMAGE_WIDTHS = [480, 960, 1440] as const;

export interface AssetSlot {
  id: string;
  style: ImageStyle;
  /** Nome-base do arquivo, sem largura nem extensão. */
  slug: string;
  aspect: Aspect;
  tone: Tone;
  /** Chave i18n do assunto, usada para compor o texto alternativo. */
  subjectKey: string;
  /** Função do slot na experiência (documentação e revisão de arte). */
  purpose: string;
}

function slot(
  style: ImageStyle,
  slug: string,
  aspect: Aspect,
  tone: Tone,
  subjectKey: string,
  purpose: string,
): AssetSlot {
  return { id: `${style}.${slug}`, style, slug, aspect, tone, subjectKey, purpose };
}

const moduleSlots: AssetSlot[] = MODULES.flatMap((m) => {
  const slug = `modules/${String(m.number).padStart(2, "0")}-${m.id}`;
  return [
    slot("anime", slug, "16:9", m.tone, m.titleKey, `Abertura do módulo ${m.number} no assessment (ilustração).`),
    slot("photo", slug, "4:5", m.tone, m.titleKey, `Apoio visual do módulo ${m.number} nas perguntas em cartões (fotografia).`),
  ];
});

const phaseSlots: AssetSlot[] = PHASES.map((p) =>
  slot("anime", `phases/${p.number}-${p.id}`, "16:9", "ember", p.titleKey, `Identidade da fase ${p.number} no dashboard e na transição de fase.`),
);

const pillarSlots: AssetSlot[] = [
  slot("anime", "pillars/body", "16:9", "ember", "pillars.body.title", "Imagem principal do pilar Corpo."),
  slot("photo", "pillars/body", "4:5", "steel", "pillars.body.title", "Fotografia de apoio do pilar Corpo."),
  slot("anime", "pillars/mind", "16:9", "dusk", "pillars.mind.title", "Imagem principal do pilar Mente."),
  slot("photo", "pillars/mind", "4:5", "night", "pillars.mind.title", "Fotografia de apoio do pilar Mente."),
  slot("anime", "pillars/lifestyle", "16:9", "steel", "pillars.lifestyle.title", "Imagem principal do pilar Estilo de vida."),
  slot("photo", "pillars/lifestyle", "4:5", "ember", "pillars.lifestyle.title", "Fotografia de apoio do pilar Estilo de vida."),
  slot("anime", "training/library", "16:9", "ember", "assets.training", "Cabeçalho da biblioteca de exercícios."),
  slot("photo", "training/library", "4:5", "steel", "assets.training", "Fotografia de apoio da biblioteca de exercícios."),
];

const extraSlots: AssetSlot[] = [
  slot("anime", "onboarding/welcome", "16:9", "ember", "assessmentExtras.onboarding", "Tela de apresentação e boas-vindas."),
  slot("photo", "onboarding/welcome", "4:5", "night", "assessmentExtras.onboarding", "Variação fotográfica da tela de boas-vindas."),
  slot("photo", "diagnostic/hero", "16:9", "steel", "assessmentExtras.diagnostic", "Cabeçalho do diagnóstico visual."),
  slot("anime", "achievements/hero", "16:9", "ember", "assessmentExtras.achievements", "Cabeçalho da tela de conquistas."),
];

export const ASSET_SLOTS: readonly AssetSlot[] = [...moduleSlots, ...phaseSlots, ...pillarSlots, ...extraSlots];

const byId = new Map(ASSET_SLOTS.map((s) => [s.id, s]));

export function getSlot(id: string): AssetSlot | undefined {
  return byId.get(id);
}

export function moduleSlotId(style: ImageStyle, id: ModuleId): string {
  const m = MODULES.find((x) => x.id === id);
  if (!m) throw new Error(`Módulo desconhecido: ${id}`);
  return `${style}.modules/${String(m.number).padStart(2, "0")}-${m.id}`;
}

export function phaseSlotId(id: PhaseId): string {
  const p = PHASES.find((x) => x.id === id);
  if (!p) throw new Error(`Fase desconhecida: ${id}`);
  return `anime.phases/${p.number}-${p.id}`;
}

export function slotSrc(s: AssetSlot, width: (typeof IMAGE_WIDTHS)[number]): string {
  return `/images/${s.style}/${s.slug}-${width}.webp`;
}

export function slotSrcSet(s: AssetSlot): string {
  return IMAGE_WIDTHS.map((w) => `${slotSrc(s, w)} ${w}w`).join(", ");
}

export function aspectRatio(a: Aspect): string {
  const [w, h] = a.split(":");
  return `${w} / ${h}`;
}
