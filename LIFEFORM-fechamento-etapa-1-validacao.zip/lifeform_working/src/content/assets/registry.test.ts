import { describe, expect, it } from "vitest";
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { MODULES } from "@/config/modules";
import { PHASES } from "@/config/phases";
import { t } from "@/i18n";
import {
  ASSET_SLOTS,
  IMAGE_WIDTHS,
  getSlot,
  moduleSlotId,
  phaseSlotId,
  slotSrc,
  slotSrcSet,
} from "./registry";

describe("registro de imagens", () => {
  it("ids são únicos", () => {
    const ids = ASSET_SLOTS.map((s) => s.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("todo módulo tem um slot de anime e um de fotografia", () => {
    for (const m of MODULES) {
      expect(getSlot(moduleSlotId("anime", m.id))).toBeDefined();
      expect(getSlot(moduleSlotId("photo", m.id))).toBeDefined();
    }
  });

  it("os três pilares têm ilustração e fotografia", () => {
    for (const pillar of ["body", "mind", "lifestyle"]) {
      expect(getSlot(`anime.pillars/${pillar}`)).toBeDefined();
      expect(getSlot(`photo.pillars/${pillar}`)).toBeDefined();
    }
  });

  it("a biblioteca de exercícios tem imagem de abertura e fotografia", () => {
    expect(getSlot("anime.training/library")).toBeDefined();
    expect(getSlot("photo.training/library")).toBeDefined();
  });

  it("toda fase tem um slot de ilustração", () => {
    for (const p of PHASES) expect(getSlot(phaseSlotId(p.id))).toBeDefined();
  });

  it("o assunto de cada slot existe no catálogo de idioma", () => {
    for (const s of ASSET_SLOTS) expect(t(s.subjectKey)).not.toBe(s.subjectKey);
  });

  it("os primeiros ativos visuais possuem as três larguras locais", () => {
    const files = [
      "public/images/anime/onboarding/welcome-480.webp",
      "public/images/anime/onboarding/welcome-960.webp",
      "public/images/anime/onboarding/welcome-1440.webp",
      "public/images/photo/training/library-480.webp",
      "public/images/photo/training/library-960.webp",
      "public/images/photo/training/library-1440.webp",
    ];
    for (const file of files) expect(existsSync(resolve(process.cwd(), file))).toBe(true);
  });

  it("monta caminhos e srcset seguindo a convenção", () => {
    const s = getSlot(moduleSlotId("anime", "identity"));
    expect(s).toBeDefined();
    if (!s) return;
    expect(slotSrc(s, 480)).toBe("/images/anime/modules/01-identity-480.webp");
    expect(slotSrcSet(s).split(", ")).toHaveLength(IMAGE_WIDTHS.length);
  });
});
