import { describe, expect, it } from "vitest";
import { EXERCISES, searchExercises } from "./exercises";

describe("biblioteca de exercícios", () => {
  it("mantém exercícios com instruções, músculos, erros e alternativas", () => {
    expect(EXERCISES.length).toBeGreaterThanOrEqual(8);
    for (const exercise of EXERCISES) {
      expect(exercise.instructions.length).toBeGreaterThanOrEqual(3);
      expect(exercise.muscles.length).toBeGreaterThan(0);
      expect(exercise.commonMistakes.length).toBeGreaterThan(0);
      expect(exercise.alternatives.Iniciante).toBeTruthy();
      expect(exercise.alternatives.Intermediário).toBeTruthy();
      expect(exercise.alternatives.Avançado).toBeTruthy();
    }
  });

  it("filtra por categoria e termo pesquisado", () => {
    expect(searchExercises("quadríceps").some((item) => item.id === "bodyweight-squat")).toBe(true);
    expect(searchExercises("", "core").every((item) => item.category === "core")).toBe(true);
    expect(searchExercises("termo inexistente")).toHaveLength(0);
  });
});
