export type ExerciseCategory = "forca" | "mobilidade" | "core" | "cardio";
export type ExerciseLevel = "Iniciante" | "Intermediário" | "Avançado";

export interface ExerciseDefinition {
  id: string;
  name: string;
  category: ExerciseCategory;
  focus: string;
  muscles: string[];
  equipment: string;
  level: ExerciseLevel;
  instructions: string[];
  commonMistakes: string[];
  alternatives: Record<ExerciseLevel, string>;
  cautions: string;
}

export const EXERCISES: readonly ExerciseDefinition[] = [
  {
    id: "bodyweight-squat", name: "Agachamento livre", category: "forca", focus: "Pernas e quadril",
    muscles: ["Quadríceps", "Glúteos", "Posterior da coxa", "Core"], equipment: "Peso corporal", level: "Iniciante",
    instructions: ["Afaste os pés aproximadamente na largura dos ombros.", "Leve o quadril para trás e flexione os joelhos em amplitude confortável.", "Mantenha os pés apoiados e retorne sem impulso."],
    commonMistakes: ["Deixar os calcanhares perderem contato com o chão.", "Deixar os joelhos colapsarem para dentro.", "Descer além da amplitude que consegue controlar."],
    alternatives: { Iniciante: "Agachamento até um banco", Intermediário: "Agachamento livre com pausa", Avançado: "Agachamento com carga supervisionada" },
    cautions: "Interrompa se houver dor aguda, tontura ou falta de ar fora do habitual."
  },
  {
    id: "wall-pushup", name: "Flexão na parede", category: "forca", focus: "Peito, ombros e braços",
    muscles: ["Peitoral", "Tríceps", "Deltoides", "Core"], equipment: "Parede firme", level: "Iniciante",
    instructions: ["Apoie as mãos na parede na altura do peito.", "Flexione os cotovelos aproximando o tronco da parede.", "Empurre a parede para voltar, sem travar os cotovelos."],
    commonMistakes: ["Arquear excessivamente a lombar.", "Abrir os cotovelos diretamente para os lados.", "Aproximar o rosto antes do tronco."],
    alternatives: { Iniciante: "Flexão na parede com menor inclinação", Intermediário: "Flexão inclinada em apoio firme", Avançado: "Flexão no chão" },
    cautions: "Mantenha a amplitude confortável para ombros e punhos."
  },
  {
    id: "glute-bridge", name: "Elevação de quadril", category: "forca", focus: "Glúteos e região posterior",
    muscles: ["Glúteo máximo", "Posterior da coxa", "Core"], equipment: "Colchonete", level: "Iniciante",
    instructions: ["Deite de barriga para cima com joelhos flexionados e pés apoiados.", "Eleve o quadril contraindo os glúteos, sem arquear excessivamente a lombar.", "Desça devagar até a posição inicial."],
    commonMistakes: ["Compensar o movimento arqueando a lombar.", "Empurrar o chão apenas com as pontas dos pés.", "Usar impulso em vez de controle."],
    alternatives: { Iniciante: "Elevação parcial de quadril", Intermediário: "Elevação de quadril com pausa", Avançado: "Elevação unilateral, se houver controle" },
    cautions: "Evite se o movimento provocar dor lombar ou no quadril."
  },
  {
    id: "bird-dog", name: "Bird-dog", category: "core", focus: "Estabilidade do tronco",
    muscles: ["Multífidos", "Abdominais", "Glúteos", "Deltoides"], equipment: "Colchonete", level: "Iniciante",
    instructions: ["Comece em quatro apoios, com mãos sob os ombros e joelhos sob o quadril.", "Estenda braço e perna opostos sem girar o tronco.", "Retorne devagar e alterne os lados."],
    commonMistakes: ["Girar o quadril para abrir a perna.", "Elevar a perna acima da linha do tronco.", "Prender a respiração."],
    alternatives: { Iniciante: "Estender apenas uma perna por vez", Intermediário: "Bird-dog com pausa", Avançado: "Bird-dog com resistência elástica leve" },
    cautions: "Priorize controle; reduza a amplitude se perder estabilidade."
  },
  {
    id: "calf-raise", name: "Elevação de panturrilha", category: "forca", focus: "Panturrilhas",
    muscles: ["Gastrocnêmio", "Sóleo"], equipment: "Apoio estável opcional", level: "Iniciante",
    instructions: ["Fique em pé com apoio próximo, se necessário.", "Eleve os calcanhares de forma controlada.", "Desça lentamente até uma posição confortável."],
    commonMistakes: ["Quicar no final do movimento.", "Deixar os tornozelos inclinarem para fora.", "Usar apoio instável."],
    alternatives: { Iniciante: "Elevação sentado", Intermediário: "Elevação em pé com pausa", Avançado: "Elevação unilateral com apoio" },
    cautions: "Use apoio para equilíbrio e não force se houver dor."
  },
  {
    id: "march-in-place", name: "Marcha estacionária", category: "cardio", focus: "Aquecimento e movimento leve",
    muscles: ["Flexores do quadril", "Panturrilhas", "Core"], equipment: "Nenhum", level: "Iniciante",
    instructions: ["Fique em pé em espaço livre e estável.", "Alterne a elevação dos pés em ritmo confortável.", "Mantenha respiração natural e postura estável."],
    commonMistakes: ["Acelerar além do confortável.", "Balançar excessivamente o tronco.", "Fazer o movimento em piso escorregadio."],
    alternatives: { Iniciante: "Marcha sentada", Intermediário: "Marcha com braços ativos", Avançado: "Marcha dinâmica sem impacto, se tolerada" },
    cautions: "Não é um teste de esforço; pare se sentir desconforto."
  },
  {
    id: "hip-hinge", name: "Dobradiça de quadril", category: "mobilidade", focus: "Padrão de movimento do quadril",
    muscles: ["Glúteos", "Posterior da coxa", "Eretores da coluna"], equipment: "Nenhum ou cabo de vassoura", level: "Iniciante",
    instructions: ["Fique em pé com joelhos levemente flexionados.", "Leve o quadril para trás mantendo a coluna neutra.", "Retorne à posição inicial contraindo suavemente os glúteos."],
    commonMistakes: ["Transformar o movimento em agachamento.", "Arredondar a coluna para alcançar mais longe.", "Levar o peso para a ponta dos pés."],
    alternatives: { Iniciante: "Dobradiça com mãos apoiadas na coxa", Intermediário: "Dobradiça com cabo de vassoura", Avançado: "Dobradiça com carga leve e técnica orientada" },
    cautions: "Use amplitude confortável e procure orientação se houver dor lombar."
  },
  {
    id: "dead-bug", name: "Dead bug", category: "core", focus: "Controle abdominal",
    muscles: ["Transverso do abdômen", "Oblíquos", "Flexores do quadril"], equipment: "Colchonete", level: "Iniciante",
    instructions: ["Deite de barriga para cima com braços elevados e joelhos flexionados.", "Estenda lentamente braço e perna opostos sem perder o controle do tronco.", "Retorne e alterne os lados."],
    commonMistakes: ["Acelerar a extensão dos membros.", "Deixar a lombar perder a posição confortável.", "Prender a respiração."],
    alternatives: { Iniciante: "Deslizar um calcanhar por vez", Intermediário: "Dead bug alternado", Avançado: "Dead bug com pausa e maior alavanca" },
    cautions: "Reduza a amplitude se não conseguir manter o tronco estável."
  }
];

export function searchExercises(query: string, category: ExerciseCategory | "todos" = "todos"): ExerciseDefinition[] {
  const normalized = query.trim().toLocaleLowerCase("pt-BR");
  return EXERCISES.filter((exercise) => {
    const matchesCategory = category === "todos" || exercise.category === category;
    const searchable = [exercise.name, exercise.focus, exercise.equipment, ...exercise.muscles].join(" ").toLocaleLowerCase("pt-BR");
    return matchesCategory && (!normalized || searchable.includes(normalized));
  });
}
