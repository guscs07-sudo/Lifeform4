import type { PillarId } from "@/config/pillars";

/**
 * Glifos geométricos abstratos dos três pilares (não são a logo da marca).
 * Usam currentColor, então herdam a cor do contêiner.
 */
export function PillarGlyph({ id, className }: { id: PillarId; className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinejoin="round"
      aria-hidden
      className={className}
    >
      {id === "body" && (
        <>
          <path d="M24 5 41 15v18L24 43 7 33V15z" />
          <path d="M24 5v38M7 15l34 18M41 15 7 33" opacity="0.45" />
        </>
      )}
      {id === "mind" && (
        <>
          <circle cx="24" cy="24" r="18" />
          <circle cx="24" cy="24" r="10" opacity="0.6" />
          <circle cx="24" cy="24" r="3" fill="currentColor" />
        </>
      )}
      {id === "lifestyle" && (
        <>
          <path d="M6 38 24 8l18 30z" />
          <path d="M14 38 24 21l10 17" opacity="0.55" />
          <path d="M6 38h36" />
        </>
      )}
    </svg>
  );
}
