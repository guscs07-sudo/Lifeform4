/** Ornamento geométrico decorativo (anéis e linhas). Não é a logo; apenas ambientação. */
export function GeometricOrnament({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 400 400" fill="none" stroke="currentColor" strokeWidth="1" aria-hidden className={className}>
      <circle cx="200" cy="200" r="190" />
      <circle cx="200" cy="200" r="140" opacity="0.7" />
      <circle cx="200" cy="200" r="90" opacity="0.5" />
      <path d="M200 10v380M10 200h380" opacity="0.35" />
      <path d="M66 66l268 268M334 66 66 334" opacity="0.25" />
      <path d="M200 60 340 200 200 340 60 200z" opacity="0.6" />
    </svg>
  );
}
