"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

/**
 * Logo oficial do LIFEFORM.
 * O símbolo geométrico aprovado NÃO foi recriado: este componente carrega o
 * arquivo oficial em /public/brand/lifeform-symbol.svg assim que ele for
 * adicionado. Enquanto o arquivo não existir, exibe apenas o logotipo em
 * texto — sem inventar um símbolo substituto.
 */

const SYMBOL_SRC = "/brand/lifeform-symbol.svg";

interface LogoProps {
  /** "symbol" = só símbolo; "full" = símbolo + nome. */
  variant?: "symbol" | "full";
  className?: string;
  size?: number;
  /**
   * Mantém um espaço vazio (moldura tracejada) no lugar do símbolo enquanto o
   * arquivo oficial não existe. Serve apenas para reservar o lugar no layout.
   */
  reserveSpace?: boolean;
}

export function Logo({ variant = "full", className, size = 40, reserveSpace = false }: LogoProps) {
  const imgRef = useRef<HTMLImageElement>(null);
  const [symbolMissing, setSymbolMissing] = useState(false);

  // A imagem pode falhar antes da hidratação; nesse caso onError nunca chega ao React.
  useEffect(() => {
    const el = imgRef.current;
    if (el?.complete && el.naturalWidth === 0) setSymbolMissing(true);
  }, []);

  const showSymbol = !symbolMissing;
  const showName = variant === "full" || symbolMissing;

  return (
    <div className={cn("inline-flex items-center gap-3", className)}>
      {showSymbol && (
        // eslint-disable-next-line @next/next/no-img-element -- ativo de marca estático
        <img
          ref={imgRef}
          src={SYMBOL_SRC}
          alt={variant === "symbol" ? "LIFEFORM" : ""}
          width={size}
          height={size}
          onError={() => setSymbolMissing(true)}
          className="shrink-0"
        />
      )}
      {symbolMissing && reserveSpace && (
        <div
          aria-hidden
          style={{ width: size, height: size }}
          className="shrink-0 rounded-xl border border-dashed border-lf-graphite-600"
        />
      )}
      {showName && (
        <span
          className="font-display text-lg font-semibold uppercase tracking-[0.28em] text-lf-white"
          aria-label="LIFEFORM"
        >
          Lifeform
        </span>
      )}
    </div>
  );
}
