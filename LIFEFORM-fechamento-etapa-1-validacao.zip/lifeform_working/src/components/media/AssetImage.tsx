"use client";

import { useEffect, useRef, useState } from "react";
import type { Tone } from "@/config/modules";
import {
  aspectRatio,
  getSlot,
  slotSrc,
  slotSrcSet,
} from "@/content/assets/registry";
import { t } from "@/i18n";
import { cn } from "@/lib/utils";

const TONE_GRADIENT: Record<Tone, string> = {
  ember: "linear-gradient(135deg, #1a0d06 0%, #3a1a0a 45%, #FF6A1A 140%)",
  steel: "linear-gradient(135deg, #0c0d10 0%, #1d2128 55%, #3a4150 140%)",
  dusk: "linear-gradient(135deg, #0c0d10 0%, #20161c 55%, #6a3a2a 140%)",
  night: "linear-gradient(135deg, #07070a 0%, #0e1118 60%, #1d2a3d 140%)",
};

interface AssetImageProps {
  /** Id de um slot do registro (src/content/assets/registry.ts). */
  slotId: string;
  className?: string;
  /** true para imagens acima da dobra (carrega imediatamente). */
  priority?: boolean;
  sizes?: string;
  /** Preenche o contêiner pai (ignora a proporção do slot). */
  fill?: boolean;
  /**
   * Se o arquivo faltar, mostra só o gradiente, sem o rótulo "Imagem em preparação".
   * Para fundos decorativos em telas de produção. Nunca substitui por outra imagem.
   */
  quietFallback?: boolean;
}

/**
 * Imagem com carregamento progressivo e fallback.
 * - Enquanto carrega: gradiente do tom do módulo (sem salto de layout).
 * - Se falhar ou o arquivo ainda não existir: fallback com rótulo honesto.
 * - Proporção reservada pelo slot, então a página não se mexe ao carregar.
 */
export function AssetImage({
  slotId,
  className,
  priority = false,
  sizes = "100vw",
  fill = false,
  quietFallback = false,
}: AssetImageProps) {
  const slot = getSlot(slotId);
  const imgRef = useRef<HTMLImageElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  // Imagem já em cache antes da hidratação não dispara onLoad.
  useEffect(() => {
    const el = imgRef.current;
    if (el?.complete) {
      if (el.naturalWidth > 0) setLoaded(true);
      else setFailed(true);
    }
  }, []);

  if (!slot) {
    return (
      <div role="img" aria-label={t("assets.pendingLabel")} className={cn("rounded-card bg-lf-graphite-800", className)} />
    );
  }

  const subject = t(slot.subjectKey);
  const alt = t(`assets.alt.${slot.style}`, { subject });
  const decorativeOnly = failed && quietFallback;

  return (
    <div
      aria-hidden={decorativeOnly || undefined}
      className={cn("relative overflow-hidden rounded-card bg-lf-graphite-900", fill && "h-full w-full", className)}
      style={{
        ...(fill ? {} : { aspectRatio: aspectRatio(slot.aspect) }),
        backgroundImage: TONE_GRADIENT[slot.tone],
      }}
    >
      {!failed && (
        // eslint-disable-next-line @next/next/no-img-element -- srcset por convenção própria (webp 480/960/1440)
        <img
          ref={imgRef}
          src={slotSrc(slot, 960)}
          srcSet={slotSrcSet(slot)}
          sizes={sizes}
          alt={alt}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          fetchPriority={priority ? "high" : "auto"}
          onLoad={() => setLoaded(true)}
          onError={() => setFailed(true)}
          className={cn(
            "absolute inset-0 h-full w-full object-cover transition-opacity duration-700",
            loaded ? "opacity-100" : "opacity-0",
          )}
        />
      )}
      {failed && !quietFallback && (
        <div
          role="img"
          aria-label={alt}
          className="absolute inset-0 flex items-end p-4"
        >
          <span className="rounded-full border border-white/10 bg-black/40 px-3 py-1 text-xs text-lf-gray-300 backdrop-blur">
            {t("assets.pendingLabel")} · {subject}
          </span>
        </div>
      )}
    </div>
  );
}
