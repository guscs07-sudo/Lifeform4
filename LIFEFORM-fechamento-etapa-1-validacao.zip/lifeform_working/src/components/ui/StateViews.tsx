import type { ReactNode } from "react";
import { t } from "@/i18n";
import { cn } from "@/lib/utils";
import { Skeleton } from "./Skeleton";

/**
 * Quatro estados padronizados exigidos pelo briefing:
 * carregamento, vazio, sucesso e erro. Toda tela de dados deve usá-los.
 */

interface BaseProps {
  title?: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}

function Shell({
  icon,
  title,
  description,
  action,
  className,
  role,
}: BaseProps & { icon: string; role: "status" | "alert" }) {
  return (
    <div
      role={role}
      className={cn("flex flex-col items-center gap-3 px-6 py-10 text-center", className)}
    >
      <span aria-hidden className="text-3xl">{icon}</span>
      <h2 className="font-display text-xl text-lf-white">{title}</h2>
      {description && <p className="max-w-sm text-sm text-lf-gray-300">{description}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

export function LoadingState({ className }: { className?: string }) {
  return (
    <div role="status" aria-live="polite" className={cn("flex flex-col gap-3", className)}>
      <span className="sr-only">{t("common.loading")}</span>
      <Skeleton className="h-6 w-2/3" />
      <Skeleton className="h-24 w-full" />
      <Skeleton className="h-24 w-full" />
    </div>
  );
}

export function EmptyState({ title = t("states.emptyTitle"), ...rest }: BaseProps) {
  return <Shell icon="◌" role="status" title={title} {...rest} />;
}

export function SuccessState({ title = t("states.successTitle"), ...rest }: BaseProps) {
  return <Shell icon="✓" role="status" title={title} {...rest} />;
}

export function ErrorState({
  title = t("states.errorTitle"),
  description = t("states.errorHint"),
  ...rest
}: BaseProps) {
  return <Shell icon="!" role="alert" title={title} description={description} {...rest} />;
}
