import type { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  /** "interactive" adiciona realce de toque/hover; "selected" marca escolha ativa. */
  tone?: "default" | "interactive" | "selected";
}

export function Card({ tone = "default", className, ...rest }: CardProps) {
  return (
    <div
      className={cn(
        "rounded-card border bg-lf-graphite-900 p-5 shadow-card",
        tone === "default" && "border-lf-graphite-700",
        tone === "interactive" &&
          "border-lf-graphite-700 transition-colors duration-200 hover:border-lf-gray-500 active:border-lf-accent",
        tone === "selected" && "border-lf-accent shadow-glow",
        className,
      )}
      {...rest}
    />
  );
}
