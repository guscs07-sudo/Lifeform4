"use client";

import { useId, useState, type InputHTMLAttributes } from "react";
import { t } from "@/i18n";
import { cn } from "@/lib/utils";

interface TextFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "id" | "className"> {
  label: string;
  /** Mensagem de erro já traduzida. */
  error?: string;
  hint?: string;
  /** Adiciona o botão Mostrar/Ocultar (para campos de senha). */
  revealable?: boolean;
}

/**
 * Campo de texto acessível e pensado para iPhone:
 * fonte de 16 px (evita o zoom automático do Safari), alvo de toque ≥ 44 px,
 * rótulo associado, erro ligado ao campo por aria-describedby.
 */
export function TextField({ label, error, hint, revealable = false, type = "text", ...rest }: TextFieldProps) {
  const id = useId();
  const hintId = `${id}-hint`;
  const errorId = `${id}-error`;
  const [revealed, setRevealed] = useState(false);

  const showHint = Boolean(hint) && !error;
  const describedBy = [showHint ? hintId : null, error ? errorId : null].filter(Boolean).join(" ") || undefined;

  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={id} className="text-sm font-medium text-lf-gray-200">
        {label}
      </label>
      <div className="relative">
        <input
          id={id}
          type={revealable ? (revealed ? "text" : "password") : type}
          aria-invalid={error ? true : undefined}
          aria-describedby={describedBy}
          className={cn(
            "min-h-12 w-full rounded-xl border bg-lf-graphite-800 px-4 text-base text-lf-white",
            "placeholder:text-lf-gray-500 transition-colors duration-200",
            "focus:border-lf-accent focus:outline-none",
            error ? "border-lf-danger" : "border-lf-graphite-600",
            revealable && "pr-24",
          )}
          {...rest}
        />
        {revealable && (
          <button
            type="button"
            onClick={() => setRevealed((value) => !value)}
            aria-pressed={revealed}
            className="absolute right-1 top-1/2 min-h-11 min-w-11 -translate-y-1/2 rounded-lg px-3 text-sm text-lf-gray-300 hover:text-lf-white"
          >
            {revealed ? t("auth.hide") : t("auth.show")}
          </button>
        )}
      </div>
      {showHint && (
        <p id={hintId} className="text-xs text-lf-gray-400">
          {hint}
        </p>
      )}
      {error && (
        <p id={errorId} className="text-sm text-lf-danger">
          {error}
        </p>
      )}
    </div>
  );
}
