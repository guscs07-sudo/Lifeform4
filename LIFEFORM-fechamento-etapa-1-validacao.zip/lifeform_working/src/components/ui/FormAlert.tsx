import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

type AlertVariant = "error" | "success" | "info" | "warning";

const STYLES: Record<AlertVariant, string> = {
  error: "border-lf-danger/40 bg-lf-danger/10 text-lf-danger",
  success: "border-lf-success/40 bg-lf-success/10 text-lf-success",
  warning: "border-lf-warning/40 bg-lf-warning/10 text-lf-warning",
  info: "border-lf-graphite-600 bg-lf-graphite-800 text-lf-gray-200",
};

interface FormAlertProps {
  variant?: AlertVariant;
  children: ReactNode;
  className?: string;
}

/** Aviso em nível de formulário. Erros usam role="alert" (leitores de tela anunciam na hora). */
export function FormAlert({ variant = "info", children, className }: FormAlertProps) {
  return (
    <div
      role={variant === "error" ? "alert" : "status"}
      className={cn("rounded-xl border px-4 py-3 text-sm", STYLES[variant], className)}
    >
      {children}
    </div>
  );
}
