import { clamp, cn } from "@/lib/utils";

interface ProgressBarProps {
  value: number;
  max?: number;
  /** Texto acessível; obrigatório porque a barra sozinha não diz o que mede. */
  label: string;
  className?: string;
}

export function ProgressBar({ value, max = 100, label, className }: ProgressBarProps) {
  const safeMax = max > 0 ? max : 100;
  const current = clamp(value, 0, safeMax);
  const pct = (current / safeMax) * 100;

  return (
    <div
      role="progressbar"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={safeMax}
      aria-valuenow={Math.round(current)}
      className={cn("h-2 w-full overflow-hidden rounded-full bg-lf-graphite-700", className)}
    >
      <div
        className="h-full rounded-full bg-lf-accent transition-[width] duration-700 ease-out motion-reduce:transition-none"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}
