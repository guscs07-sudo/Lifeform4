import { useId, type InputHTMLAttributes, type ReactNode } from "react";

interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "id" | "className" | "type"> {
  label: ReactNode;
  /** Mensagem de erro já traduzida. */
  error?: string;
}

/** Caixa de seleção com área de toque grande (a linha inteira é clicável). */
export function Checkbox({ label, error, ...rest }: CheckboxProps) {
  const id = useId();
  const errorId = `${id}-error`;

  return (
    <div className="flex flex-col gap-1">
      <label htmlFor={id} className="flex min-h-12 cursor-pointer items-start gap-3 py-2 text-sm text-lf-gray-200">
        <input
          id={id}
          type="checkbox"
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? errorId : undefined}
          className="mt-0.5 h-6 w-6 shrink-0 accent-lf-accent"
          {...rest}
        />
        <span>{label}</span>
      </label>
      {error && (
        <p id={errorId} className="text-sm text-lf-danger">
          {error}
        </p>
      )}
    </div>
  );
}
