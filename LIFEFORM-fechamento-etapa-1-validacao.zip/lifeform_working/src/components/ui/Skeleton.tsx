import { cn } from "@/lib/utils";

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      aria-hidden
      className={cn(
        "animate-shimmer rounded-card bg-[length:200%_100%]",
        "bg-[linear-gradient(90deg,#181A1F_25%,#22252B_50%,#181A1F_75%)]",
        className,
      )}
    />
  );
}
