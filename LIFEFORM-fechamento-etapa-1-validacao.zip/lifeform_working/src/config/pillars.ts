export const PILLAR_IDS = ["body", "mind", "lifestyle"] as const;
export type PillarId = (typeof PILLAR_IDS)[number];

export interface PillarDef {
  id: PillarId;
  titleKey: string;
  summaryKey: string;
}

export const PILLARS: readonly PillarDef[] = PILLAR_IDS.map((id) => ({
  id,
  titleKey: `pillars.${id}.title`,
  summaryKey: `pillars.${id}.summary`,
}));
