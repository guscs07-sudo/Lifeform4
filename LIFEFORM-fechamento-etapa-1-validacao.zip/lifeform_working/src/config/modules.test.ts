import { describe, expect, it } from "vitest";
import { MODULES } from "@/config/modules";
import { PILLAR_IDS } from "@/config/pillars";
import { t } from "@/i18n";

describe("módulos do assessment", () => {
  it("são dez, numerados de 1 a 10 sem lacunas", () => {
    expect(MODULES).toHaveLength(10);
    expect(MODULES.map((m) => m.number)).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
  });

  it("cada módulo alimenta ao menos um pilar", () => {
    for (const m of MODULES) expect(m.pillars.length).toBeGreaterThan(0);
  });

  it("os três pilares são cobertos", () => {
    const covered = new Set(MODULES.flatMap((m) => m.pillars));
    for (const p of PILLAR_IDS) expect(covered.has(p)).toBe(true);
  });

  it("títulos e resumos existem no catálogo de idioma", () => {
    for (const m of MODULES) {
      expect(t(m.titleKey)).not.toBe(m.titleKey);
      expect(t(m.summaryKey)).not.toBe(m.summaryKey);
    }
  });
});
