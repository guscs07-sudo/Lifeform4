export const PHASE_IDS = ["reconstruction", "development", "evolution", "consolidation"] as const;
export type PhaseId = (typeof PHASE_IDS)[number];

export interface PhaseDef {
  id: PhaseId;
  number: 1 | 2 | 3 | 4;
  titleKey: string;
  summaryKey: string;
}

/**
 * A progressão entre fases depende de critérios reais (definidos no motor,
 * Etapa 5), nunca apenas da passagem de dias. Aqui ficam só os metadados.
 */
export const PHASES: readonly PhaseDef[] = [
  { id: "reconstruction", number: 1, titleKey: "phases.reconstruction.title", summaryKey: "phases.reconstruction.summary" },
  { id: "development", number: 2, titleKey: "phases.development.title", summaryKey: "phases.development.summary" },
  { id: "evolution", number: 3, titleKey: "phases.evolution.title", summaryKey: "phases.evolution.summary" },
  { id: "consolidation", number: 4, titleKey: "phases.consolidation.title", summaryKey: "phases.consolidation.summary" },
];
