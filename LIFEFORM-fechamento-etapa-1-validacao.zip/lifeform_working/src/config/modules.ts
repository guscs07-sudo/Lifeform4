import type { PillarId } from "./pillars";

/** Tom visual do módulo: define gradiente de fallback e direção de arte. */
export type Tone = "ember" | "steel" | "dusk" | "night";

export const MODULE_IDS = [
  "identity",
  "body",
  "training",
  "nutrition",
  "sleep",
  "mind",
  "routine",
  "habits",
  "health",
  "goals",
] as const;
export type ModuleId = (typeof MODULE_IDS)[number];

export interface ModuleDef {
  id: ModuleId;
  /** Número do módulo (01–10), conforme o briefing. */
  number: number;
  /** Pilares que o módulo alimenta (mapeamento inicial; refinado na Etapa 4/5). */
  pillars: readonly PillarId[];
  tone: Tone;
  titleKey: string;
  summaryKey: string;
}

const def = (
  number: number,
  id: ModuleId,
  pillars: readonly PillarId[],
  tone: Tone,
): ModuleDef => ({
  id,
  number,
  pillars,
  tone,
  titleKey: `modules.${id}.title`,
  summaryKey: `modules.${id}.summary`,
});

export const MODULES: readonly ModuleDef[] = [
  def(1, "identity", ["body", "mind", "lifestyle"], "ember"),
  def(2, "body", ["body"], "ember"),
  def(3, "training", ["body"], "steel"),
  def(4, "nutrition", ["body"], "dusk"),
  def(5, "sleep", ["lifestyle"], "night"),
  def(6, "mind", ["mind"], "steel"),
  def(7, "routine", ["lifestyle"], "dusk"),
  def(8, "habits", ["lifestyle", "mind"], "night"),
  def(9, "health", ["body"], "steel"),
  def(10, "goals", ["mind"], "ember"),
];

export function getModule(id: ModuleId): ModuleDef {
  const found = MODULES.find((m) => m.id === id);
  if (!found) throw new Error(`Módulo desconhecido: ${id}`);
  return found;
}
