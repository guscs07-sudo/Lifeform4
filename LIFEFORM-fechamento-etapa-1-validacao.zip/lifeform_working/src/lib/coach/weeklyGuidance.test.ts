import { describe, expect, it } from "vitest";
import { buildWeeklyGuidance } from "./weeklyGuidance";

describe("buildWeeklyGuidance", () => {
  it("prioriza recuperação quando energia e recuperação estão baixas", () => {
    const result = buildWeeklyGuidance({ energy: "low", recovery: "poor", difficulty: "right", routine: "stable" });
    expect(result[0]?.title).toBe("Priorize recuperação");
    expect(result[0]?.tone).toBe("care");
  });

  it("sugere adaptar o plano quando a semana ficou corrida", () => {
    const result = buildWeeklyGuidance({ energy: "medium", recovery: "okay", difficulty: "right", routine: "busy" });
    expect(result.some((item) => item.title === "Adapte o plano à semana real")).toBe(true);
  });

  it("não recomenda progressão automática em uma semana confortável", () => {
    const result = buildWeeklyGuidance({ energy: "high", recovery: "good", difficulty: "easy", routine: "stable" });
    expect(result[0]?.action).toContain("Mantenha");
    expect(result[0]?.action).not.toContain("aumente a carga");
  });

  it("pode combinar recuperação e ajuste de exigência", () => {
    const result = buildWeeklyGuidance({ energy: "low", recovery: "poor", difficulty: "hard", routine: "stable" });
    expect(result).toHaveLength(2);
    expect(result.map((item) => item.tone)).toEqual(["care", "adapt"]);
  });
});
