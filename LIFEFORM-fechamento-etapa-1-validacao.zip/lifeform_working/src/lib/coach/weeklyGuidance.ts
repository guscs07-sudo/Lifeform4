export type WeeklyCheckIn = {
  energy: "low" | "medium" | "high";
  recovery: "poor" | "okay" | "good";
  difficulty: "easy" | "right" | "hard";
  routine: "stable" | "changed" | "busy";
};

export type GuidanceTone = "care" | "adapt" | "steady";
export type WeeklyGuidance = {
  title: string;
  message: string;
  action: string;
  tone: GuidanceTone;
};

/**
 * Regras transparentes para transformar o check-in em orientação de rotina.
 * Não prescreve exercícios, cargas, tratamento ou progressão automática.
 */
export function buildWeeklyGuidance(review: WeeklyCheckIn): WeeklyGuidance[] {
  const guidance: WeeklyGuidance[] = [];

  if (review.energy === "low" || review.recovery === "poor") {
    guidance.push({
      title: "Priorize recuperação",
      message: review.energy === "low" && review.recovery === "poor"
        ? "Você relatou energia baixa e recuperação insuficiente. Evite tratar esta semana como momento de aumentar exigências."
        : review.energy === "low"
          ? "Sua energia esteve baixa. Vale observar sono, pausas e o quanto cabe na sua rotina antes de assumir mais compromissos."
          : "Sua recuperação foi percebida como insuficiente. Respeite os intervalos de descanso e não aumente a exigência só para cumprir um plano.",
      action: "Se necessário, reduza temporariamente o volume planejado e retome de forma gradual quando estiver melhor.",
      tone: "care",
    });
  }

  if (review.difficulty === "hard") {
    guidance.push({
      title: "Ajuste o nível de exigência",
      message: "As atividades foram percebidas como pesadas. Isso é um sinal para revisar o plano, não para se cobrar mais.",
      action: "Na próxima semana, considere uma versão mais simples ou curta das atividades e registre como se sente.",
      tone: "adapt",
    });
  } else if (review.difficulty === "easy" && review.energy === "high" && review.recovery === "good") {
    guidance.push({
      title: "Mantenha a consistência",
      message: "A semana pareceu confortável e sua energia e recuperação foram positivas.",
      action: "Mantenha o que está funcionando. Qualquer progressão deve ser gradual e baseada também na sua experiência ao longo do tempo.",
      tone: "steady",
    });
  }

  if (review.routine === "busy" || review.routine === "changed") {
    guidance.push({
      title: "Adapte o plano à semana real",
      message: review.routine === "busy"
        ? "Sua semana teve pouco tempo disponível. Um plano menor e possível é melhor do que uma programação que não cabe na rotina."
        : "Sua rotina mudou. O planejamento pode acompanhar essa mudança sem transformar imprevistos em falhas.",
      action: "Escolha uma ou duas prioridades realistas e reorganize os horários antes de adicionar novas tarefas.",
      tone: "adapt",
    });
  }

  if (guidance.length === 0) {
    guidance.push({
      title: "Continue construindo sua base",
      message: "Seu check-in não aponta um ajuste específico nesta semana. Isso não significa que você precise aumentar a intensidade.",
      action: "Repita uma rotina sustentável, registre suas atividades e reavalie na próxima semana.",
      tone: "steady",
    });
  }

  return guidance;
}
