import { describe, expect, it } from "vitest";
import { looksLikeSecretKey } from "@/lib/env";

/** Monta um JWT de teste (não é uma chave real). */
function fakeJwt(payload: Record<string, unknown>): string {
  const enc = (o: unknown) => Buffer.from(JSON.stringify(o)).toString("base64url");
  return `${enc({ alg: "HS256", typ: "JWT" })}.${enc(payload)}.assinatura`;
}

describe("looksLikeSecretKey", () => {
  it("reconhece chave service_role", () => {
    expect(looksLikeSecretKey(fakeJwt({ role: "service_role" }))).toBe(true);
  });
  it("reconhece o prefixo sb_secret_", () => {
    expect(looksLikeSecretKey("sb_secret_abc123")).toBe(true);
  });
  it("aceita chave anon e chave publishable", () => {
    expect(looksLikeSecretKey(fakeJwt({ role: "anon" }))).toBe(false);
    expect(looksLikeSecretKey("sb_publishable_abc123")).toBe(false);
  });
  it("não quebra com valores inválidos", () => {
    expect(looksLikeSecretKey("")).toBe(false);
    expect(looksLikeSecretKey("a.b.c")).toBe(false);
  });
});
