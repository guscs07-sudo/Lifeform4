export type GamificationSummary = {
  xp: number;
  level: number;
  currentLevelXp: number;
  nextLevelXp: number;
  progressPercent: number;
  title: string;
};

/** Calcula nível de forma determinística a partir de eventos registrados. */
export function summarizeGamification(input: {
  activities: number;
  trainingSessions: number;
  completedHabitChecks: number;
  completedGoals: number;
}): GamificationSummary {
  const safe = {
    activities: Math.max(0, Math.floor(Number.isFinite(input.activities) ? input.activities : 0)),
    trainingSessions: Math.max(0, Math.floor(Number.isFinite(input.trainingSessions) ? input.trainingSessions : 0)),
    completedHabitChecks: Math.max(0, Math.floor(Number.isFinite(input.completedHabitChecks) ? input.completedHabitChecks : 0)),
    completedGoals: Math.max(0, Math.floor(Number.isFinite(input.completedGoals) ? input.completedGoals : 0)),
  };
  const xp = safe.activities * 15 + safe.trainingSessions * 20 + safe.completedHabitChecks * 5 + safe.completedGoals * 30;
  const level = Math.floor(xp / 100) + 1;
  const currentLevelXp = xp % 100;
  const nextLevelXp = 100;
  const titles = ["Começo", "Em construção", "Consistência", "Evolução", "Consolidação"];
  const title = titles[Math.min(titles.length - 1, Math.floor((level - 1) / 2))] ?? titles[0] ?? "Começo";
  return { xp, level, currentLevelXp, nextLevelXp, progressPercent: currentLevelXp, title };
}
