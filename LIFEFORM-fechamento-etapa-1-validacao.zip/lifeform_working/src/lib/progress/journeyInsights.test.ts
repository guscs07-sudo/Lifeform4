import { describe, expect, it } from "vitest";
import { buildJourneyInsights } from "./journeyInsights";

const referenceDate = new Date("2026-11-12T12:00:00");
const currentWeek = "2026-11-09";

describe("buildJourneyInsights", () => {
  it("conta somente atividades e hábitos da semana atual", () => {
    const result = buildJourneyInsights({
      activities: [{ date: "2026-11-09" }, { date: "2026-11-12" }, { date: "2026-11-08" }],
      habits: [{ frequency: "daily", doneDates: ["2026-11-10", "2026-11-02"] }],
      goals: [], referenceDate,
    });
    expect(result.activitiesThisWeek).toBe(2);
    expect(result.habitChecksThisWeek).toBe(1);
    expect(result.habitsWithProgress).toBe(1);
    expect(result.focus).toBe("maintain");
  });

  it("prioriza recuperação quando energia está baixa ou recuperação ruim", () => {
    const result = buildJourneyInsights({ activities: [], habits: [], goals: [], referenceDate, review: { weekOf: currentWeek, energy: "low", recovery: "okay", difficulty: "right", routine: "stable" } });
    expect(result.focus).toBe("recovery");
  });

  it("simplifica quando a rotina está corrida ou a dificuldade foi alta", () => {
    const result = buildJourneyInsights({ activities: [], habits: [], goals: [], referenceDate, review: { weekOf: currentWeek, energy: "medium", recovery: "okay", difficulty: "hard", routine: "stable" } });
    expect(result.focus).toBe("simplify");
  });

  it("ignora revisão de outra semana", () => {
    const result = buildJourneyInsights({ activities: [], habits: [], goals: [], referenceDate, review: { weekOf: "2026-11-02", energy: "low", recovery: "poor", difficulty: "hard", routine: "busy" } });
    expect(result.focus).toBe("build");
  });

  it("resume metas concluídas e em aberto", () => {
    const result = buildJourneyInsights({ activities: [], habits: [], goals: [{ completed: true }, { completed: false }, { completed: false }], referenceDate });
    expect(result.completedGoals).toBe(1);
    expect(result.openGoals).toBe(2);
  });
});
