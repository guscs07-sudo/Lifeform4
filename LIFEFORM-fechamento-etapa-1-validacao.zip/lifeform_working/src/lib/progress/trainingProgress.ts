export type TrainingRecord = { date: string; durationMinutes: number };

export type TrainingProgress = {
  currentSessions: number;
  previousSessions: number;
  currentMinutes: number;
  previousMinutes: number;
  change: "more" | "same" | "less" | "new";
  message: string;
  nextStep: string;
};

/** Compara duas janelas completas de sete dias sem transformar ausência de registro em fracasso. */
export function summarizeTrainingProgress(
  records: TrainingRecord[],
  referenceDate = new Date(),
): TrainingProgress {
  const end = new Date(referenceDate);
  end.setHours(23, 59, 59, 999);
  const startCurrent = new Date(end);
  startCurrent.setDate(startCurrent.getDate() - 6);
  startCurrent.setHours(0, 0, 0, 0);
  const startPrevious = new Date(startCurrent);
  startPrevious.setDate(startPrevious.getDate() - 7);
  const endPrevious = new Date(startCurrent.getTime() - 1);

  const inRange = (record: TrainingRecord, start: Date, finish: Date) => {
    const date = new Date(`${record.date}T12:00:00`);
    return Number.isFinite(date.getTime()) && date >= start && date <= finish;
  };
  const current = records.filter((item) => inRange(item, startCurrent, end));
  const previous = records.filter((item) => inRange(item, startPrevious, endPrevious));
  const currentMinutes = current.reduce((sum, item) => sum + Math.max(0, item.durationMinutes), 0);
  const previousMinutes = previous.reduce((sum, item) => sum + Math.max(0, item.durationMinutes), 0);
  const change = previous.length === 0 ? (current.length ? "new" : "same") : current.length > previous.length ? "more" : current.length < previous.length ? "less" : "same";

  let message = "Ainda não há registros suficientes para comparar semanas. Seu histórico começa quando você quiser.";
  let nextStep = "Se fizer sentido para sua rotina, registre uma atividade possível. Descanso também faz parte do processo.";
  if (change === "new") {
    message = `Você registrou ${current.length} atividade(s) nesta janela. Este é seu ponto de partida — sem comparação ou cobrança.`;
    nextStep = "Continue observando o que cabe na sua semana antes de aumentar qualquer compromisso.";
  } else if (change === "more") {
    message = `Você registrou mais atividades nesta semana (${current.length}) do que na anterior (${previous.length}).`;
    nextStep = "Mantenha um ritmo sustentável; não é necessário aumentar a frequência só porque a semana foi mais ativa.";
  } else if (change === "less") {
    message = `Foram ${current.length} atividade(s) nesta semana e ${previous.length} na anterior. Isso é apenas contexto, não uma nota.`;
    nextStep = "Se a rotina apertou, reveja sua disponibilidade e escolha um passo menor. Não tente compensar tudo de uma vez.";
  } else if (current.length || previous.length) {
    message = `Você registrou ${current.length} atividade(s) nesta semana e ${previous.length} na anterior.`;
    nextStep = "Observe como você está se sentindo e mantenha o plano compatível com sua rotina e recuperação.";
  }

  return { currentSessions: current.length, previousSessions: previous.length, currentMinutes, previousMinutes, change, message, nextStep };
}
