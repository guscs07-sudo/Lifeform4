import { describe, expect, it } from "vitest";
import { summarizeGamification } from "./gamification";

describe("summarizeGamification", () => {
  it("starts at level one without inventing XP", () => {
    expect(summarizeGamification({ activities: 0, trainingSessions: 0, completedHabitChecks: 0, completedGoals: 0 })).toMatchObject({ xp: 0, level: 1, progressPercent: 0 });
  });
  it("combines only recorded events", () => {
    expect(summarizeGamification({ activities: 2, trainingSessions: 1, completedHabitChecks: 3, completedGoals: 1 })).toMatchObject({ xp: 100, level: 2, progressPercent: 0 });
  });
  it("normalizes negative and invalid counters", () => {
    expect(summarizeGamification({ activities: -5, trainingSessions: Number.NaN, completedHabitChecks: 2.8, completedGoals: 0 })).toMatchObject({ xp: 10, level: 1, progressPercent: 10 });
  });
});
