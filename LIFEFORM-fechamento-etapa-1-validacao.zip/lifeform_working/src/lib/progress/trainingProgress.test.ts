import { describe, expect, it } from "vitest";
import { summarizeTrainingProgress } from "./trainingProgress";

describe("summarizeTrainingProgress", () => {
  const reference = new Date("2026-11-12T12:00:00");
  it("does not invent a comparison without history", () => {
    const result = summarizeTrainingProgress([], reference);
    expect(result.change).toBe("same");
    expect(result.currentSessions).toBe(0);
    expect(result.message).toContain("não há registros suficientes");
  });
  it("recognizes a first recorded week without pressure", () => {
    const result = summarizeTrainingProgress([{ date: "2026-11-10", durationMinutes: 25 }], reference);
    expect(result.change).toBe("new");
    expect(result.currentMinutes).toBe(25);
    expect(result.nextStep).toContain("sustentável");
  });
  it("compares current and previous seven-day windows", () => {
    const result = summarizeTrainingProgress([
      { date: "2026-11-03", durationMinutes: 20 },
      { date: "2026-11-05", durationMinutes: 30 },
      { date: "2026-11-10", durationMinutes: 25 },
    ], reference);
    expect(result.previousSessions).toBe(2);
    expect(result.currentSessions).toBe(1);
    expect(result.change).toBe("less");
  });
});
