import { describe, expect, it } from "vitest";
import { summarizeJourneyRewards } from "./journeyRewards";

const today = "2026-11-12";
const session = { id: "s1", title: "Treino A", date: today, durationMinutes: 30, entries: [{}, {}] };

describe("summarizeJourneyRewards", () => {
  it("does not award activity XP twice for a linked training mirror", () => {
    const result = summarizeJourneyRewards({
      today,
      trainingSessions: [session],
      activities: [{ id: "a1", title: session.title, date: today, minutes: 30, trainingSessionId: "s1" }],
      habits: [], goals: [],
    });
    expect(result.totalMovements).toBe(1);
    expect(result.movementsThisWeek).toBe(1);
    expect(result.movementsToday).toBe(1);
    expect(result.gamification.xp).toBe(20);
  });

  it("recognizes one legacy mirror and keeps independent activities", () => {
    const result = summarizeJourneyRewards({
      today,
      trainingSessions: [session],
      activities: [
        { title: session.title, date: today, minutes: 30, note: "2 exercício(s) registrado(s)" },
        { title: "Caminhada", date: today, minutes: 20 },
      ],
      habits: [], goals: [],
    });
    expect(result.independentActivities).toBe(1);
    expect(result.totalMovements).toBe(2);
    expect(result.gamification.xp).toBe(35);
  });

  it("deduplicates habit dates and ignores future, impossible and invalid records", () => {
    const result = summarizeJourneyRewards({
      today,
      trainingSessions: [session, { ...session, id: "future", date: "2026-11-13" }],
      activities: [
        { title: "Inválida", date: "2026-02-31", minutes: 10 },
        { title: "Futura", date: "2026-11-13", minutes: 10 },
        { title: "Negativa", date: today, minutes: -5 },
      ],
      habits: [{ doneDates: [today, today, "2026-11-13", "2026-02-31"] }],
      goals: [{ completed: true }, { completed: false }],
    });
    expect(result.trainingSessions).toBe(1);
    expect(result.independentActivities).toBe(0);
    expect(result.completedHabitChecks).toBe(1);
    expect(result.completedGoals).toBe(1);
    expect(result.gamification.xp).toBe(55);
  });

  it("does not hide an orphaned session link", () => {
    const result = summarizeJourneyRewards({
      today,
      trainingSessions: [],
      activities: [{ title: "Registro avulso", date: today, minutes: 15, trainingSessionId: "missing" }],
      habits: [], goals: [],
    });
    expect(result.independentActivities).toBe(1);
    expect(result.gamification.xp).toBe(15);
  });
});
