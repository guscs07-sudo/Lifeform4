export type JourneyActivity = { date: string };
export type JourneyHabit = { frequency: "daily" | "weekly"; doneDates: string[] };
export type JourneyGoal = { completed: boolean };
export type JourneyReview = {
  weekOf: string;
  energy: "low" | "medium" | "high";
  recovery: "poor" | "okay" | "good";
  difficulty: "easy" | "right" | "hard";
  routine: "stable" | "changed" | "busy";
};

export type JourneyInsights = {
  activitiesThisWeek: number;
  habitChecksThisWeek: number;
  habitsWithProgress: number;
  completedGoals: number;
  openGoals: number;
  focus: "recovery" | "simplify" | "maintain" | "build";
  headline: string;
  recommendation: string;
};

function weekStart(date: Date): string {
  const start = new Date(date);
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  return `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, "0")}-${String(start.getDate()).padStart(2, "0")}`;
}

/** Produz um resumo descritivo da jornada sem pontuar o usuário nem prescrever carga. */
export function buildJourneyInsights(input: {
  activities: JourneyActivity[];
  habits: JourneyHabit[];
  goals: JourneyGoal[];
  review?: JourneyReview;
  referenceDate?: Date;
}): JourneyInsights {
  const now = input.referenceDate ? new Date(input.referenceDate) : new Date();
  const currentWeek = weekStart(now);
  const start = new Date(`${currentWeek}T00:00:00`);
  const end = new Date(start);
  end.setDate(end.getDate() + 7);
  const activitiesThisWeek = input.activities.filter((item) => {
    const date = new Date(`${item.date}T12:00:00`);
    return Number.isFinite(date.getTime()) && date >= start && date < end;
  }).length;
  const habitChecksThisWeek = input.habits.reduce((total, habit) => total + habit.doneDates.filter((date) => {
    const parsed = new Date(`${date}T12:00:00`);
    return Number.isFinite(parsed.getTime()) && parsed >= start && parsed < end;
  }).length, 0);
  const habitsWithProgress = input.habits.filter((habit) => habit.doneDates.some((date) => {
    const parsed = new Date(`${date}T12:00:00`);
    return Number.isFinite(parsed.getTime()) && parsed >= start && parsed < end;
  })).length;
  const completedGoals = input.goals.filter((goal) => goal.completed).length;
  const openGoals = input.goals.length - completedGoals;

  let focus: JourneyInsights["focus"] = "build";
  let headline = "Comece com um passo possível";
  let recommendation = "Escolha uma atividade ou hábito pequeno que combine com sua disponibilidade atual.";
  const reviewIsCurrent = input.review?.weekOf === currentWeek;
  if (reviewIsCurrent && (input.review?.recovery === "poor" || input.review?.energy === "low")) {
    focus = "recovery";
    headline = "Recuperação em primeiro lugar";
    recommendation = "Priorize descanso e atividades leves apenas se forem confortáveis. Se houver sintomas preocupantes, procure orientação de um profissional de saúde.";
  } else if (reviewIsCurrent && (input.review?.routine === "busy" || input.review?.difficulty === "hard")) {
    focus = "simplify";
    headline = "Simplifique a semana";
    recommendation = "Reduza o tamanho dos compromissos e mantenha somente o que cabe na rotina. Não tente compensar atividades perdidas.";
  } else if (activitiesThisWeek > 0 || habitChecksThisWeek > 0) {
    focus = "maintain";
    headline = "Você já colocou a jornada em movimento";
    recommendation = "Observe o que foi sustentável e repita esse ritmo. Não é necessário aumentar a frequência ou a intensidade automaticamente.";
  }

  return { activitiesThisWeek, habitChecksThisWeek, habitsWithProgress, completedGoals, openGoals, focus, headline, recommendation };
}
