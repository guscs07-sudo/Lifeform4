import { summarizeGamification, type GamificationSummary } from "./gamification";

export type RewardActivity = {
  id?: string;
  title: string;
  date: string;
  minutes: number;
  note?: string;
  trainingSessionId?: string;
};
export type RewardTrainingSession = {
  id: string;
  title: string;
  date: string;
  durationMinutes: number;
  entries?: unknown[];
};
export type RewardHabit = { doneDates: string[] };
export type RewardGoal = { completed: boolean };

export type JourneyRewardSummary = {
  independentActivities: number;
  trainingSessions: number;
  completedHabitChecks: number;
  completedGoals: number;
  totalMovements: number;
  movementsThisWeek: number;
  movementsToday: number;
  gamification: GamificationSummary;
  validTrainingSessions: RewardTrainingSession[];
  independentActivityRecords: RewardActivity[];
  trainingMinutesTotal: number;
};

function isCalendarDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(year, month - 1, day);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
}

function isValidMovementDate(value: string, today: string): boolean {
  return isCalendarDate(value) && value <= today;
}

/** Consolidates movement and reward counters, avoiding XP and mission duplication
 * when a training session also has its legacy activity mirror. */
export function summarizeJourneyRewards(input: {
  activities: RewardActivity[];
  trainingSessions: RewardTrainingSession[];
  habits: RewardHabit[];
  goals: RewardGoal[];
  today: string;
}): JourneyRewardSummary {
  const today = isCalendarDate(input.today) ? input.today : new Date().toISOString().slice(0, 10);
  const validSessions = input.trainingSessions.filter((session) =>
    Boolean(session.id) && isValidMovementDate(session.date, today) &&
    Number.isFinite(session.durationMinutes) && session.durationMinutes > 0,
  );
  const sessionIds = new Set(validSessions.map((session) => session.id));
  const usedLegacyMirrors = new Set<string>();
  const independent = input.activities.filter((activity) => {
    if (!isValidMovementDate(activity.date, today) || !Number.isFinite(activity.minutes) || activity.minutes <= 0) return false;
    if (activity.trainingSessionId) return !sessionIds.has(activity.trainingSessionId);
    // Older saved records predate trainingSessionId. Recognize the exact mirror
    // format produced by the previous session writer and consume it only once.
    if (/^\d+ exercício\(s\) registrado\(s\)$/.test(activity.note ?? "")) {
      const match = validSessions.find((session) =>
        !usedLegacyMirrors.has(session.id) && session.title === activity.title &&
        session.date === activity.date && session.durationMinutes === activity.minutes &&
        activity.note === `${session.entries?.length ?? 0} exercício(s) registrado(s)`,
      );
      if (match) {
        usedLegacyMirrors.add(match.id);
        return false;
      }
    }
    return true;
  });

  const sevenDaysAgo = new Date(`${today}T12:00:00`);
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
  const weekStart = `${sevenDaysAgo.getFullYear()}-${String(sevenDaysAgo.getMonth() + 1).padStart(2, "0")}-${String(sevenDaysAgo.getDate()).padStart(2, "0")}`;
  const independentThisWeek = independent.filter((item) => item.date >= weekStart && item.date <= today);
  const sessionsThisWeek = validSessions.filter((item) => item.date >= weekStart && item.date <= today);
  const habitChecks = input.habits.reduce((sum, habit) => sum + new Set(habit.doneDates.filter((date) => isValidMovementDate(date, today))).size, 0);
  const completedGoals = input.goals.filter((goal) => goal.completed === true).length;
  const independentToday = independent.filter((item) => item.date === today).length;
  const sessionsToday = validSessions.filter((item) => item.date === today).length;

  return {
    independentActivities: independent.length,
    trainingSessions: validSessions.length,
    completedHabitChecks: habitChecks,
    completedGoals,
    totalMovements: independent.length + validSessions.length,
    movementsThisWeek: independentThisWeek.length + sessionsThisWeek.length,
    movementsToday: independentToday + sessionsToday,
    validTrainingSessions: validSessions,
    independentActivityRecords: independent,
    trainingMinutesTotal: validSessions.reduce((sum, session) => sum + session.durationMinutes, 0),
    gamification: summarizeGamification({
      activities: independent.length,
      trainingSessions: validSessions.length,
      completedHabitChecks: habitChecks,
      completedGoals,
    }),
  };
}
