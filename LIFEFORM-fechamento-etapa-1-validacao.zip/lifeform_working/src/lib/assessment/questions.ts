export type AssessmentModule =
  | "identity" | "body" | "training" | "nutrition" | "sleep"
  | "mind" | "routine" | "habits" | "health" | "goals";
export type QuestionType = "single" | "multi" | "scale" | "number" | "text";
export interface QuestionOption { value: string; label: string; description?: string }
export interface AssessmentQuestion {
  id: string;
  module: AssessmentModule;
  type: QuestionType;
  title: string;
  description?: string;
  required?: boolean;
  options?: readonly QuestionOption[];
  min?: number;
  max?: number;
  unit?: string;
  integer?: boolean;
  placeholder?: string;
  condition?: (answers: AssessmentAnswers) => boolean;
}
export type AssessmentAnswers = Record<string, string | number | string[]>;
const opts = (items: string[]): QuestionOption[] => items.map((label) => ({ value: label, label }));

/** 22 perguntas essenciais + aprofundamentos condicionais. As respostas não geram diagnóstico médico. */
export const ASSESSMENT_QUESTIONS: readonly AssessmentQuestion[] = [
  { id: "main_goal", module: "identity", type: "single", title: "O que você mais quer transformar neste momento?", description: "Escolha o ponto de partida mais importante para você.", required: true, options: opts(["Melhorar meu condicionamento físico", "Ganhar força e desenvolver músculos", "Emagrecer e melhorar minha composição corporal", "Ter mais disciplina e consistência", "Cuidar melhor da minha saúde e bem-estar", "Organizar minha rotina e qualidade de vida"]) },
  { id: "priority_pillar", module: "identity", type: "single", title: "Qual pilar merece mais atenção agora?", required: true, options: [{ value: "body", label: "Corpo", description: "Movimento, força e alimentação" }, { value: "mind", label: "Mente", description: "Foco, disciplina e motivação" }, { value: "lifestyle", label: "Estilo de vida", description: "Sono, rotina e equilíbrio" }] },
  { id: "age", module: "identity", type: "number", title: "Qual é a sua idade?", description: "O LIFEFORM é destinado inicialmente a pessoas com 18 anos ou mais.", required: true, min: 18, max: 100, integer: true, unit: "anos" },
  { id: "height_cm", module: "identity", type: "number", title: "Qual é a sua altura?", required: true, min: 120, max: 230, unit: "cm" },
  { id: "weight_kg", module: "identity", type: "number", title: "Qual é seu peso atual aproximado?", required: true, min: 35, max: 300, unit: "kg" },
  { id: "activity_level", module: "body", type: "single", title: "Como você descreveria seu nível de atividade hoje?", required: true, options: opts(["Quase não faço atividade física", "Faço atividades leves algumas vezes", "Treino ou me movimento regularmente", "Tenho uma rotina física intensa"]) },
  { id: "fitness_confidence", module: "body", type: "scale", title: "Como você avalia seu condicionamento atual?", description: "0 significa muito baixo; 10 significa excelente para sua realidade.", required: true, min: 0, max: 10 },
  { id: "training_experience", module: "training", type: "single", title: "Qual sua experiência com exercícios?", required: true, options: opts(["Estou começando", "Já pratiquei, mas estou parado(a)", "Tenho alguma experiência", "Treino há bastante tempo"]) },
  { id: "training_preferences", module: "training", type: "multi", title: "Quais atividades você gostaria de fazer?", description: "Pode escolher mais de uma.", required: true, options: opts(["Musculação", "Treino em casa", "Caminhada", "Corrida", "Bicicleta", "Mobilidade e alongamento", "Esportes", "Ainda não sei"]) },
  { id: "equipment", module: "training", type: "multi", title: "Quais recursos você tem disponíveis?", required: true, options: opts(["Academia completa", "Halteres ou pesos", "Elásticos", "Barra fixa", "Bicicleta", "Apenas espaço livre", "Nenhum equipamento"]) },
  { id: "nutrition_pattern", module: "nutrition", type: "single", title: "Como está sua alimentação na maior parte dos dias?", required: true, options: opts(["Tenho horários e refeições organizados", "É razoavelmente equilibrada, mas irregular", "Como conforme a correria do dia", "Tenho dificuldade para manter uma alimentação adequada", "Prefiro não responder agora"]) },
  { id: "water_habit", module: "nutrition", type: "single", title: "Como você avalia seu hábito de beber água?", required: true, options: opts(["Bebo água regularmente", "Às vezes esqueço", "Bebo pouca água", "Não sei avaliar"]) },
  { id: "sleep_hours", module: "sleep", type: "single", title: "Quantas horas você costuma dormir por noite?", required: true, options: opts(["Menos de 5 horas", "Entre 5 e 6 horas", "Entre 6 e 7 horas", "Entre 7 e 9 horas", "Mais de 9 horas", "Varia muito"]) },
  { id: "sleep_quality", module: "sleep", type: "scale", title: "Como você avalia a qualidade do seu sono?", required: true, min: 0, max: 10 },
  { id: "stress_level", module: "mind", type: "scale", title: "Como está seu nível de estresse atualmente?", description: "0 = muito baixo; 10 = muito alto.", required: true, min: 0, max: 10 },
  { id: "consistency_barrier", module: "mind", type: "multi", title: "O que mais dificulta sua consistência?", description: "Selecione tudo que se aplica.", required: true, options: opts(["Falta de tempo", "Cansaço", "Falta de motivação", "Não sei por onde começar", "Dificuldade de manter o foco", "Falta de estrutura ou equipamento", "Não tenho uma dificuldade específica"]) },
  { id: "available_days", module: "routine", type: "single", title: "Quantos dias por semana você consegue reservar para cuidar de si?", required: true, options: opts(["1 dia", "2 dias", "3 dias", "4 dias", "5 dias", "6 ou 7 dias", "Minha rotina varia muito"]) },
  { id: "session_minutes", module: "routine", type: "single", title: "Quanto tempo costuma ter por sessão?", required: true, options: opts(["Até 15 minutos", "15 a 30 minutos", "30 a 45 minutos", "45 a 60 minutos", "Mais de 60 minutos", "Depende do dia"]) },
  { id: "routine_predictability", module: "routine", type: "single", title: "Sua rotina semanal é previsível?", required: true, options: opts(["Sim, tenho horários bem definidos", "Em parte, alguns dias mudam", "Não, meus horários variam bastante"]) },
  { id: "habit_focus", module: "habits", type: "multi", title: "Quais hábitos você gostaria de desenvolver?", required: true, options: opts(["Dormir melhor", "Beber mais água", "Me movimentar diariamente", "Planejar meu dia", "Ler ou estudar", "Reduzir tempo de tela", "Ter momentos de descanso", "Manter alimentação organizada"]) },
  { id: "health_limitations", module: "health", type: "single", title: "Existe alguma limitação ou orientação profissional que precisamos respeitar?", description: "Você pode escolher não informar detalhes. Isso serve apenas para evitar sugestões inadequadas.", required: true, options: opts(["Não tenho nenhuma que eu saiba", "Tenho uma lesão ou limitação física", "Tenho orientação profissional para adaptar atividades", "Prefiro conversar sobre isso depois"]) },
  { id: "commitment", module: "goals", type: "scale", title: "Quanto você se sente preparado(a) para começar uma mudança gradual?", required: true, min: 0, max: 10 },
  // Aprofundamentos condicionais: só aparecem quando a resposta torna a pergunta relevante.
  { id: "training_limit_detail", module: "health", type: "text", title: "Que tipo de movimento ou atividade precisa ser adaptado?", description: "Não precisa informar diagnóstico. Descreva apenas a limitação prática.", placeholder: "Ex.: evitar impacto ou movimentos acima da cabeça…", condition: (a) => a.health_limitations === "Tenho uma lesão ou limitação física" || a.health_limitations === "Tenho orientação profissional para adaptar atividades" },
  { id: "training_pause_reason", module: "training", type: "single", title: "O que mais contribuiu para você parar de treinar?", options: opts(["Falta de tempo", "Lesão ou desconforto", "Mudança de rotina", "Desmotivação", "Outro motivo"]), condition: (a) => a.training_experience === "Já pratiquei, mas estou parado(a)" },
  { id: "nutrition_support", module: "nutrition", type: "single", title: "Você gostaria de apoio para organizar sua alimentação?", options: opts(["Sim, com hábitos gerais", "Sim, com planejamento de refeições", "Por enquanto, não é minha prioridade"]), condition: (a) => a.nutrition_pattern !== "Prefiro não responder agora" },
  { id: "sleep_difficulty", module: "sleep", type: "multi", title: "O que costuma atrapalhar seu sono?", options: opts(["Demoro para dormir", "Acordo durante a noite", "Acordo sem disposição", "Horários irregulares", "Preocupações ou pensamentos", "Nada disso"]) , condition: (a) => a.sleep_quality !== undefined && Number(a.sleep_quality) <= 5 },
  { id: "stress_support", module: "mind", type: "single", title: "Que tipo de apoio seria mais útil neste momento?", options: opts(["Organização e planejamento", "Pequenas metas diárias", "Exercícios de foco e reflexão", "Reduzir sobrecarga e respeitar pausas"]), condition: (a) => a.stress_level !== undefined && Number(a.stress_level) >= 7 },
  { id: "schedule_detail", module: "routine", type: "text", title: "Existe algum horário ou compromisso fixo que devemos considerar?", placeholder: "Ex.: trabalho das 9h às 18h…", condition: (a) => a.routine_predictability === "Não, meus horários variam bastante" },
  { id: "goal_detail", module: "goals", type: "text", title: "Se quiser, descreva uma meta pessoal que gostaria de alcançar.", placeholder: "Escreva com suas palavras…", condition: (a) => ["Ter mais disciplina e consistência", "Organizar minha rotina e qualidade de vida"].includes(String(a.main_goal)) },
];

export function getVisibleQuestions(answers: AssessmentAnswers): AssessmentQuestion[] {
  return ASSESSMENT_QUESTIONS.filter((question) => !question.condition || question.condition(answers));
}
export function isAnswered(question: AssessmentQuestion, answers: AssessmentAnswers): boolean {
  const value = answers[question.id];
  if (value === undefined || value === "" || (Array.isArray(value) && value.length === 0)) return false;
  if (question.type === "number") {
    const numeric = Number(value);
    return Number.isFinite(numeric) && numeric >= (question.min ?? 0) && numeric <= (question.max ?? 999) && (!question.integer || Number.isInteger(numeric));
  }
  return true;
}
export function getMissingRequired(answers: AssessmentAnswers): string[] {
  return getVisibleQuestions(answers).filter((q) => q.required && !isAnswered(q, answers)).map((q) => q.id);
}
