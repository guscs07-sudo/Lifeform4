import { describe, expect, it } from "vitest";
import { buildDiagnosis } from "./diagnosis";
import type { AssessmentAnswers } from "./questions";

const base: AssessmentAnswers = {
  activity_level: "Faço atividades leves algumas vezes",
  fitness_confidence: 5,
  training_experience: "Estou começando",
  nutrition_pattern: "É razoavelmente equilibrada, mas irregular",
  water_habit: "Às vezes esqueço",
  stress_level: 6,
  commitment: 5,
  consistency_barrier: ["Falta de tempo", "Cansaço"],
  sleep_quality: 5,
  sleep_hours: "Entre 5 e 6 horas",
  available_days: "2 dias",
  routine_predictability: "Em parte, alguns dias mudam",
  priority_pillar: "body",
  health_limitations: "Não tenho nenhuma que eu saiba",
};

describe("buildDiagnosis", () => {
  it("gera três pilares e uma fase inicial reproduzível", () => {
    const first = buildDiagnosis(base, new Date("2026-11-12T12:00:00.000Z"));
    const second = buildDiagnosis(base, new Date("2026-11-12T12:00:00.000Z"));
    expect(first.pillars.map((pillar) => pillar.id)).toEqual(["body", "mind", "lifestyle"]);
    expect(first.phase).toBe("reconstruction");
    expect(first.priority).toBe(second.priority);
    expect(first.overallCoverage).toBe(100);
  });

  it("não apresenta pontuação quando faltam respostas de um pilar", () => {
    const result = buildDiagnosis({ main_goal: "Ter mais disciplina e consistência" });
    expect(result.pillars.every((pillar) => pillar.score === null)).toBe(true);
    expect(result.overallCoverage).toBe(0);
  });

  it("sinaliza necessidade de orientação e não recomenda exercício específico", () => {
    const result = buildDiagnosis({ ...base, health_limitations: "Tenho uma lesão ou limitação física" });
    expect(result.safety.needsProfessionalGuidance).toBe(true);
    expect(result.safety.message).toContain("não sugere exercícios específicos");
    expect(result.phase).toBe("reconstruction");
  });

  it("personaliza o resumo pelo objetivo declarado", () => {
    const result = buildDiagnosis({ ...base, main_goal: "Ter mais disciplina e consistência" });
    expect(result.goalSummary).toContain("constância");
    expect(result.priorityReason.length).toBeGreaterThan(20);
  });

  it("não conta a opção 'sem dificuldade' como obstáculo adicional", () => {
    const result = buildDiagnosis({ ...base, consistency_barrier: ["Não tenho uma dificuldade específica"] });
    expect(result.pillars.find((pillar) => pillar.id === "mind")?.score).toBe(63);
  });

  it("não usa fase avançada baseada apenas no questionário", () => {
    const result = buildDiagnosis({ ...base, activity_level: "Tenho uma rotina física intensa", commitment: 10, consistency_barrier: ["Não tenho uma dificuldade específica"] });
    expect(["reconstruction", "development"]).toContain(result.phase);
  });
});
