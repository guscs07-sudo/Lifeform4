import { describe, expect, it } from "vitest";
import { assessmentDraftsMatch, hasAssessmentData, isAssessmentAnswers, type AssessmentDraft, type CloudAssessment } from "@/lib/assessment/cloudAssessment";

const local: AssessmentDraft = { answers: { age: 25, goal: "condicionamento" }, updatedAt: "2026-11-12T10:00:00.000Z", completedAt: "2026-11-12T10:00:00.000Z" };
const cloud: CloudAssessment = { id: "assessment-1", answers: local.answers, status: "completed", completedAt: local.completedAt!, updatedAt: local.updatedAt };

describe("assessment cloud helpers", () => {
  it("validates only supported answer structures", () => {
    expect(isAssessmentAnswers({ age: 25, goals: ["força"] })).toBe(true);
    expect(isAssessmentAnswers({ age: { value: 25 } })).toBe(false);
    expect(isAssessmentAnswers(null)).toBe(false);
  });
  it("detects local assessment data", () => {
    expect(hasAssessmentData(null)).toBe(false);
    expect(hasAssessmentData({ answers: {}, updatedAt: "now" })).toBe(false);
    expect(hasAssessmentData(local)).toBe(true);
  });
  it("compares answer content and completion state", () => {
    expect(assessmentDraftsMatch(local, cloud)).toBe(true);
    expect(assessmentDraftsMatch({ ...local, answers: { age: 26 } }, cloud)).toBe(false);
    expect(assessmentDraftsMatch(null, null)).toBe(true);
  });
});
