import type { AssessmentAnswers } from "@/lib/assessment/questions";

export interface AssessmentDraft {
  answers: AssessmentAnswers;
  updatedAt: string;
  completedAt?: string;
}

export interface CloudAssessment {
  id: string;
  answers: AssessmentAnswers;
  status: "draft" | "completed";
  completedAt: string | null;
  updatedAt: string;
}

export function isAssessmentAnswers(value: unknown): value is AssessmentAnswers {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  return Object.values(value as Record<string, unknown>).every((answer) =>
    typeof answer === "string" || typeof answer === "number" ||
    (Array.isArray(answer) && answer.every((item) => typeof item === "string")),
  );
}

export function hasAssessmentData(draft: AssessmentDraft | null): boolean {
  return Boolean(draft && (Object.keys(draft.answers).length > 0 || draft.completedAt));
}

export function assessmentDraftsMatch(local: AssessmentDraft | null, cloud: CloudAssessment | null): boolean {
  if (!local || !cloud) return local === null && cloud === null;
  return JSON.stringify(local.answers) === JSON.stringify(cloud.answers) &&
    (local.completedAt ?? null) === cloud.completedAt;
}
