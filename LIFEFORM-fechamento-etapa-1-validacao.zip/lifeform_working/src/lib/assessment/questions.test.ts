import { describe, expect, it } from "vitest";
import { ASSESSMENT_QUESTIONS, getMissingRequired, getVisibleQuestions, type AssessmentAnswers } from "./questions";

describe("assessment question flow", () => {
  it("has at least 20 essential questions", () => {
    expect(ASSESSMENT_QUESTIONS.filter((q) => q.required).length).toBeGreaterThanOrEqual(20);
  });
  it("shows conditional questions only when relevant", () => {
    const answers: AssessmentAnswers = { health_limitations: "Tenho uma lesão ou limitação física", training_experience: "Já pratiquei, mas estou parado(a)", sleep_quality: 3, stress_level: 8, routine_predictability: "Não, meus horários variam bastante", main_goal: "Melhorar meu condicionamento físico" };
    const visible = getVisibleQuestions(answers).map((q) => q.id);
    expect(visible).toContain("training_limit_detail");
    expect(visible).toContain("training_pause_reason");
    expect(visible).toContain("sleep_difficulty");
    expect(visible).toContain("stress_support");
    expect(visible).toContain("schedule_detail");
  });
  it("does not require optional follow-ups", () => {
    expect(getMissingRequired({})).toHaveLength(22);
  });
  it("rejects an age below 18 or a fractional age", () => {
    const ageQuestion = ASSESSMENT_QUESTIONS.find((question) => question.id === "age");
    expect(ageQuestion).toBeDefined();
    expect(getMissingRequired({ age: 17 })).toContain("age");
    expect(getMissingRequired({ age: 18.5 })).toContain("age");
    expect(getMissingRequired({ age: 18 })).toContain("main_goal");
  });
});
