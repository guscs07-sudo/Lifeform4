import type { AssessmentAnswers } from "./questions";

export type PillarId = "body" | "mind" | "lifestyle";
export type InitialPhase = "reconstruction" | "development";
export type SignalLevel = "needs_attention" | "building" | "steady" | "insufficient_data";

export interface PillarResult {
  id: PillarId;
  title: string;
  score: number | null;
  level: SignalLevel;
  summary: string;
  strengths: string[];
  opportunities: string[];
  evidence: string[];
}

export interface DiagnosisResult {
  generatedAt: string;
  overallCoverage: number;
  pillars: PillarResult[];
  priority: PillarId;
  priorityReason: string;
  goalSummary: string;
  phase: InitialPhase;
  phaseTitle: string;
  phaseReason: string;
  safety: {
    needsProfessionalGuidance: boolean;
    message: string | null;
  };
  nextSteps: string[];
  disclaimer: string;
}

const has = (a: AssessmentAnswers, key: string) => a[key] !== undefined && a[key] !== "";
const num = (a: AssessmentAnswers, key: string) => has(a, key) ? Number(a[key]) : null;
const includes = (a: AssessmentAnswers, key: string, value: string) => Array.isArray(a[key]) && (a[key] as string[]).includes(value);
const average = (values: Array<number | null>) => {
  const valid = values.filter((v): v is number => v !== null && Number.isFinite(v));
  return valid.length ? Math.round(valid.reduce((sum, value) => sum + value, 0) / valid.length) : null;
};
const clamp = (value: number) => Math.max(0, Math.min(100, Math.round(value)));
const levelFor = (score: number | null): SignalLevel => score === null ? "insufficient_data" : score < 40 ? "needs_attention" : score < 70 ? "building" : "steady";

function result(
  id: PillarId,
  score: number | null,
  summary: string,
  strengths: string[],
  opportunities: string[],
  evidence: string[],
): PillarResult {
  return { id, title: id === "body" ? "Corpo" : id === "mind" ? "Mente" : "Estilo de vida", score, level: levelFor(score), summary, strengths, opportunities, evidence };
}

/**
 * Regras transparentes de leitura das respostas. Os índices são indicadores
 * de organização e autopercepção, não notas clínicas nem avaliação médica.
 */
export function buildDiagnosis(answers: AssessmentAnswers, now = new Date()): DiagnosisResult {
  const bodySignals: number[] = [];
  const bodyEvidence: string[] = [];
  const activity = String(answers.activity_level ?? "");
  const activityScore: Record<string, number> = {
    "Quase não faço atividade física": 20,
    "Faço atividades leves algumas vezes": 50,
    "Treino ou me movimento regularmente": 80,
    "Tenho uma rotina física intensa": 90,
  };
  const activityValue = activityScore[activity] ?? 0;
  if (activityScore[activity] !== undefined) { bodySignals.push(activityScore[activity]); bodyEvidence.push(`Atividade atual: ${activity.toLowerCase()}.`); }
  const confidence = num(answers, "fitness_confidence");
  if (confidence !== null && confidence >= 0 && confidence <= 10) { bodySignals.push(confidence * 10); bodyEvidence.push("Autopercepção do condicionamento incluída."); }
  const experience = String(answers.training_experience ?? "");
  const experienceScore: Record<string, number> = { "Estou começando": 35, "Já pratiquei, mas estou parado(a)": 30, "Tenho alguma experiência": 65, "Treino há bastante tempo": 85 };
  if (experienceScore[experience] !== undefined) { bodySignals.push(experienceScore[experience]); bodyEvidence.push("Experiência prévia considerada."); }
  const nutritionScore: Record<string, number> = {
    "Tenho horários e refeições organizados": 85,
    "É razoavelmente equilibrada, mas irregular": 65,
    "Como conforme a correria do dia": 40,
    "Tenho dificuldade para manter uma alimentação adequada": 25,
  };
  const nutritionValue = nutritionScore[String(answers.nutrition_pattern ?? "")];
  if (nutritionValue !== undefined) {
    bodySignals.push(nutritionValue);
    bodyEvidence.push("Rotina alimentar autorreferida considerada, sem avaliação nutricional.");
  }
  const waterScore: Record<string, number> = { "Bebo água regularmente": 85, "Às vezes esqueço": 55, "Bebo pouca água": 30, "Não sei avaliar": 45 };
  const waterValue = waterScore[String(answers.water_habit)];
  if (waterValue !== undefined) bodySignals.push(waterValue);

  const mindSignals: number[] = [];
  const mindEvidence: string[] = [];
  const stress = num(answers, "stress_level");
  if (stress !== null && stress >= 0 && stress <= 10) { mindSignals.push(100 - stress * 10); mindEvidence.push("Nível de estresse percebido considerado de forma invertida."); }
  const commitment = num(answers, "commitment");
  if (commitment !== null && commitment >= 0 && commitment <= 10) { mindSignals.push(commitment * 10); mindEvidence.push("Disposição declarada para mudanças graduais considerada."); }
  const barriers = Array.isArray(answers.consistency_barrier) ? answers.consistency_barrier as string[] : [];
  const normalizedBarriers = barriers.filter((item) => item !== "Não tenho uma dificuldade específica");
  if (has(answers, "consistency_barrier")) {
    const barrierCount = normalizedBarriers.length;
    mindSignals.push(clamp(100 - barrierCount * 15));
    mindEvidence.push("Obstáculos de consistência informados considerados; não representam falta de capacidade.");
  }

  const lifestyleSignals: number[] = [];
  const lifestyleEvidence: string[] = [];
  const sleepQuality = num(answers, "sleep_quality");
  if (sleepQuality !== null && sleepQuality >= 0 && sleepQuality <= 10) { lifestyleSignals.push(sleepQuality * 10); lifestyleEvidence.push("Qualidade do sono percebida considerada."); }
  const sleepHours = String(answers.sleep_hours ?? "");
  const sleepScore: Record<string, number> = { "Menos de 5 horas": 20, "Entre 5 e 6 horas": 40, "Entre 6 e 7 horas": 65, "Entre 7 e 9 horas": 85, "Mais de 9 horas": 70, "Varia muito": 35 };
  const sleepValue = sleepScore[sleepHours];
  if (sleepValue !== undefined) { lifestyleSignals.push(sleepValue); lifestyleEvidence.push("Faixa de duração do sono informada considerada, sem avaliação clínica."); }
  const days = String(answers.available_days ?? "");
  const dayScore: Record<string, number> = { "1 dia": 35, "2 dias": 50, "3 dias": 70, "4 dias": 80, "5 dias": 85, "6 ou 7 dias": 75, "Minha rotina varia muito": 40 };
  const daysValue = dayScore[days];
  if (daysValue !== undefined) { lifestyleSignals.push(daysValue); lifestyleEvidence.push("Disponibilidade declarada considerada; mais dias não significa necessariamente melhor resultado."); }
  const predictability: Record<string, number> = { "Sim, tenho horários bem definidos": 85, "Em parte, alguns dias mudam": 65, "Não, meus horários variam bastante": 40 };
  const predictabilityValue = predictability[String(answers.routine_predictability)];
  if (predictabilityValue !== undefined) lifestyleSignals.push(predictabilityValue);

  const pillars = [
    result("body", average(bodySignals), "Um retrato inicial dos seus hábitos de movimento e autocuidado físico.",
      activityValue >= 75 ? ["Você relata uma rotina ativa."] : [],
      activityValue < 50 ? ["Começar com movimentos compatíveis com sua realidade pode ser uma oportunidade."] : [], bodyEvidence),
    result("mind", average(mindSignals), "Uma leitura da sua disposição e dos obstáculos que você identifica hoje.",
      commitment !== null && commitment >= 7 ? ["Você demonstra disposição para começar gradualmente."] : [],
      barriers.length ? ["O plano deve considerar os obstáculos que você selecionou, sem transformar isso em cobrança."] : [], mindEvidence),
    result("lifestyle", average(lifestyleSignals), "Uma visão da rotina, do descanso e do tempo que você consegue reservar.",
      sleepQuality !== null && sleepQuality >= 7 ? ["Você avalia positivamente a qualidade do sono."] : [],
      sleepQuality !== null && sleepQuality <= 5 ? ["Vale observar o que pode favorecer uma rotina de descanso mais consistente."] : [], lifestyleEvidence),
  ];

  const ranked = [...pillars].filter((p) => p.score !== null).sort((a, b) => (a.score ?? 101) - (b.score ?? 101));
  const explicitPriority = answers.priority_pillar;
  const lowest = ranked[0];
  const preferred = pillars.find((pillar) => pillar.id === explicitPriority);
  // A preferência declarada prevalece quando está próxima do menor indicador.
  // Uma diferença grande mantém em foco a área com mais oportunidades observáveis.
  const priority = (preferred && lowest && preferred.score !== null && lowest.score !== null && preferred.score <= lowest.score + 15
    ? preferred.id
    : lowest?.id ?? (explicitPriority === "mind" || explicitPriority === "lifestyle" ? explicitPriority : "body")) as PillarId;
  const safetyChoice = String(answers.health_limitations ?? "");
  const needsProfessionalGuidance = safetyChoice === "Tenho uma lesão ou limitação física" || safetyChoice === "Tenho orientação profissional para adaptar atividades" || safetyChoice === "Prefiro conversar sobre isso depois";
  const ready = commitment !== null && commitment >= 7 && activityScore[activity] !== undefined && activityValue >= 50 && normalizedBarriers.length <= 1 && !needsProfessionalGuidance;
  const phase: InitialPhase = ready ? "development" : "reconstruction";
  const phaseTitle = ready ? "Desenvolvimento" : "Reconstrução";
  const phaseReason = ready
    ? "Suas respostas indicam alguma base de atividade e disposição para desenvolver consistência. Esta é apenas uma fase inicial, revisável conforme sua experiência real."
    : "Vamos começar construindo uma base viável, entendendo sua rotina e priorizando constância antes de aumentar exigências.";
  const coverage = Math.round(([
    "activity_level", "fitness_confidence", "training_experience", "nutrition_pattern", "water_habit",
    "stress_level", "commitment", "consistency_barrier", "sleep_quality", "sleep_hours", "available_days", "routine_predictability",
  ].filter((key) => has(answers, key)).length / 12) * 100);
  const goal = String(answers.main_goal ?? "");
  const goalSummaryByAnswer: Record<string, string> = {
    "Melhorar meu condicionamento físico": "Seu foco declarado é desenvolver condicionamento de forma gradual e compatível com seu ponto de partida.",
    "Ganhar força e desenvolver músculos": "Seu foco declarado é desenvolver força e capacidade muscular com progressão responsável.",
    "Emagrecer e melhorar minha composição corporal": "Seu foco declarado é melhorar a composição corporal com hábitos sustentáveis, sem metas extremas.",
    "Ter mais disciplina e consistência": "Seu foco declarado é construir constância por meio de ações pequenas e repetíveis.",
    "Cuidar melhor da minha saúde e bem-estar": "Seu foco declarado é fortalecer hábitos gerais de bem-estar, respeitando suas necessidades individuais.",
    "Organizar minha rotina e qualidade de vida": "Seu foco declarado é criar uma rotina mais organizada e equilibrada, sem sobrecarga.",
  };
  const goalSummary = goalSummaryByAnswer[goal] ?? "Seu objetivo ainda precisa ser definido com mais clareza. Você poderá atualizá-lo depois.";
  const priorityReason = preferred && preferred.id === priority
    ? "Sua preferência pessoal foi considerada junto aos indicadores disponíveis."
    : lowest
      ? "Esta área apresentou o menor indicador entre os pilares com dados suficientes. Isso é um ponto de partida, não um julgamento."
      : "Ainda faltam respostas suficientes para definir uma prioridade baseada nos indicadores.";
  const nextSteps = [
    goalSummary,
    normalizedBarriers.length > 0
      ? `Planeje considerando este obstáculo: ${normalizedBarriers[0]?.toLowerCase() ?? "sua rotina atual"}. Comece com uma ação pequena e realista.`
      : "Escolha uma mudança pequena que caiba na sua semana real.",
    needsProfessionalGuidance ? "Antes de receber sugestões de exercício, considere as orientações do profissional que acompanha você." : "Registre como estão sua energia, rotina e consistência, sem buscar perfeição.",
  ];
  return {
    generatedAt: now.toISOString(), overallCoverage: coverage, pillars, priority, priorityReason, goalSummary, phase, phaseTitle, phaseReason,
    safety: {
      needsProfessionalGuidance,
      message: needsProfessionalGuidance
        ? "Você informou uma limitação, orientação profissional ou preferiu conversar sobre saúde depois. Por segurança, este diagnóstico não sugere exercícios específicos. Respeite a orientação de um profissional habilitado antes de iniciar ou alterar atividades."
        : null,
    },
    nextSteps,
    disclaimer: "Este relatório organiza respostas autorreferidas para apoiar seu planejamento. Os indicadores não são notas de saúde, testes psicológicos, diagnósticos médicos nem garantia de resultados. As recomendações são gerais e devem ser adaptadas à sua realidade.",
  };
}
