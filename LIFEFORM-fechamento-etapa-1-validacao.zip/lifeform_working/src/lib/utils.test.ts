import { describe, expect, it } from "vitest";
import { clamp, cn } from "@/lib/utils";

describe("cn", () => {
  it("combina classes e ignora valores falsos", () => {
    expect(cn("a", false && "b", undefined, "c")).toBe("a c");
  });
  it("resolve conflitos do Tailwind (a última vence)", () => {
    expect(cn("p-2", "p-4")).toBe("p-4");
  });
});

describe("clamp", () => {
  it("limita ao intervalo", () => {
    expect(clamp(15, 0, 10)).toBe(10);
    expect(clamp(-3, 0, 10)).toBe(0);
    expect(clamp(5, 0, 10)).toBe(5);
  });
  it("trata NaN retornando o mínimo", () => {
    expect(clamp(Number.NaN, 0, 10)).toBe(0);
  });
});
