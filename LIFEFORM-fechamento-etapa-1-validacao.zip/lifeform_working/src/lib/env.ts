import { z } from "zod";

/**
 * Leitura centralizada e validada das variáveis de ambiente.
 * Regras:
 *  - Variáveis NEXT_PUBLIC_* podem ir ao navegador (somente URL e chave pública/anon).
 *  - Chaves secretas (service_role / sb_secret_) são recusadas no navegador.
 *  - A chave de IA é lida apenas no servidor e é totalmente opcional.
 *
 * Importante: as variáveis NEXT_PUBLIC_* precisam ser lidas por acesso estático
 * (process.env.NEXT_PUBLIC_X) para o Next.js embuti-las no código do navegador.
 */

const publicSchema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.string().url().optional(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1).optional(),
  NEXT_PUBLIC_APP_URL: z.string().url().default("http://localhost:3000"),
});

export function getPublicEnv() {
  return publicSchema.parse({
    NEXT_PUBLIC_SUPABASE_URL: emptyToUndefined(process.env.NEXT_PUBLIC_SUPABASE_URL),
    NEXT_PUBLIC_SUPABASE_ANON_KEY: emptyToUndefined(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY),
    NEXT_PUBLIC_APP_URL: emptyToUndefined(process.env.NEXT_PUBLIC_APP_URL),
  });
}

/** true se a chave parece ser secreta (nunca deve estar no navegador). */
export function looksLikeSecretKey(key: string): boolean {
  if (key.startsWith("sb_secret_")) return true;
  const parts = key.split(".");
  if (parts.length !== 3) return false;
  try {
    const b64 = (parts[1] ?? "").replace(/-/g, "+").replace(/_/g, "/");
    const padded = b64 + "=".repeat((4 - (b64.length % 4)) % 4);
    const payload = JSON.parse(atob(padded)) as { role?: unknown };
    return payload.role === "service_role";
  } catch {
    return false;
  }
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
}

let warnedAboutSecretKey = false;

/** Configuração do Supabase para o navegador, ou null se ausente/inválida/insegura. */
export function getSupabaseConfig(): SupabaseConfig | null {
  try {
    const env = getPublicEnv();
    const url = env.NEXT_PUBLIC_SUPABASE_URL;
    const anonKey = env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    if (!url || !anonKey) return null;
    if (looksLikeSecretKey(anonKey)) {
      if (!warnedAboutSecretKey) {
        warnedAboutSecretKey = true;
        console.error(
          "[LIFEFORM] A chave configurada em NEXT_PUBLIC_SUPABASE_ANON_KEY parece ser uma chave SECRETA. " +
            "Ela foi ignorada. Use somente a chave anon/publishable.",
        );
      }
      return null;
    }
    return { url, anonKey };
  } catch {
    return null;
  }
}

export function isSupabaseConfigured(): boolean {
  return getSupabaseConfig() !== null;
}

/** Somente servidor. Nunca importe esta função em componentes "use client". */
export function isAiEnabled(): boolean {
  return process.env.LIFEFORM_AI_ENABLED === "true" && Boolean(process.env.LIFEFORM_AI_API_KEY);
}

function emptyToUndefined(value: string | undefined): string | undefined {
  return value && value.trim() !== "" ? value : undefined;
}
