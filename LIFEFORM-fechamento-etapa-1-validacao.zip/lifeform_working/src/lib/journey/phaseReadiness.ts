import type { PhaseId } from "../../config/phases";
import type { PhaseEvidence } from "./phaseProgression";

export type ReadinessActivity = { date: string };
export type ReadinessHabit = { frequency: "daily" | "weekly"; doneDates: string[] };
export type ReadinessReview = {
  weekOf: string;
  energy: "low" | "medium" | "high";
  recovery: "poor" | "okay" | "good";
  difficulty: "easy" | "right" | "hard";
};

function mondayKey(date: Date): string {
  const monday = new Date(date);
  monday.setHours(0, 0, 0, 0);
  monday.setDate(monday.getDate() - ((monday.getDay() + 6) % 7));
  return `${monday.getFullYear()}-${String(monday.getMonth() + 1).padStart(2, "0")}-${String(monday.getDate()).padStart(2, "0")}`;
}

function addDays(key: string, amount: number): string {
  const date = new Date(`${key}T12:00:00`);
  date.setDate(date.getDate() + amount);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

/** Converts real profile records into transparent phase-readiness evidence. */
export function buildPhaseReadinessEvidence(input: {
  currentPhase: PhaseId;
  activities: ReadinessActivity[];
  habits: ReadinessHabit[];
  reviews: ReadinessReview[];
  referenceDate?: Date;
  hasUnresolvedSafetyConcern?: boolean;
}): PhaseEvidence {
  const now = input.referenceDate ? new Date(input.referenceDate) : new Date();
  const weekOf = mondayKey(now);
  const weekdayIndex = (now.getDay() + 6) % 7;
  const elapsedDays = weekdayIndex + 1;
  const weekEnd = addDays(weekOf, 7);
  const inCurrentWeek = (date: string) => date >= weekOf && date < weekEnd;

  const activitiesThisWeek = input.activities.filter((item) => inCurrentWeek(item.date)).length;
  const adherenceRate = Math.min(1, activitiesThisWeek / 3);

  const expectedHabitChecks = input.habits.reduce(
    (sum, habit) => sum + (habit.frequency === "daily" ? elapsedDays : 1),
    0,
  );
  const completedHabitChecks = input.habits.reduce((sum, habit) => {
    const completedDates = [...new Set(habit.doneDates.filter(inCurrentWeek))];
    // Um hábito semanal vale no máximo uma conclusão por semana, mesmo que
    // dados antigos ou importados contenham mais de uma data na mesma semana.
    return sum + (habit.frequency === "weekly" ? Math.min(1, completedDates.length) : completedDates.length);
  }, 0);
  const habitConsistency = expectedHabitChecks === 0
    ? 0
    : Math.min(1, completedHabitChecks / expectedHabitChecks);

  const reviewWeeks = new Set(input.reviews.map((review) => review.weekOf));
  let consecutiveReviewedWeeks = 0;
  for (let offset = 0; offset < 12; offset += 1) {
    if (!reviewWeeks.has(addDays(weekOf, -7 * offset))) break;
    consecutiveReviewedWeeks += 1;
  }

  const currentReview = input.reviews.find((review) => review.weekOf === weekOf);
  return {
    currentPhase: input.currentPhase,
    adherenceRate,
    consecutiveReviewedWeeks,
    habitConsistency,
    energy: currentReview?.energy ?? null,
    recovery: currentReview?.recovery ?? null,
    difficulty: currentReview?.difficulty ?? null,
    hasUnresolvedSafetyConcern: input.hasUnresolvedSafetyConcern ?? false,
  };
}
