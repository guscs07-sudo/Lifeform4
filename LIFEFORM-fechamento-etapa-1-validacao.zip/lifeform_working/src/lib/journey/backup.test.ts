import { describe, expect, it } from "vitest";
import { parseJourneyBackup } from "./backup";

const emptyData = { activities: [], habits: [], goals: [], trainingSessions: [], weeklyReviews: [] };
const backup = (overrides: Record<string, unknown> = {}) => JSON.stringify({ app: "LIFEFORM", formatVersion: 1, userId: "profile-a", data: emptyData, ...overrides });

describe("backup da jornada", () => {
  it("aceita backup válido do mesmo perfil", () => {
    expect(parseJourneyBackup(backup(), "profile-a")).toEqual({ ok: true, data: emptyData });
  });
  it("recusa backup de outro perfil", () => {
    expect(parseJourneyBackup(backup(), "profile-b")).toEqual({ ok: false, reason: "wrong-profile" });
  });
  it("recusa JSON inválido e estrutura incompleta", () => {
    expect(parseJourneyBackup("{", "profile-a")).toEqual({ ok: false, reason: "invalid-json" });
    expect(parseJourneyBackup(JSON.stringify({ app: "LIFEFORM" }), "profile-a")).toEqual({ ok: false, reason: "invalid-file" });
  });
  it("recusa versões futuras desconhecidas", () => {
    expect(parseJourneyBackup(backup({ formatVersion: 2 }), "profile-a")).toEqual({ ok: false, reason: "unsupported-version" });
  });
  it("preserva o vínculo entre atividade e sessão de treino", () => {
    const data = { ...emptyData, activities: [{ id: "activity-1", title: "Treino A", minutes: 30, date: "2026-11-12", trainingSessionId: "session-1" }] };
    const result = parseJourneyBackup(backup({ data }), "profile-a");
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.data.activities[0]?.trainingSessionId).toBe("session-1");
  });
  it("recusa datas impossíveis", () => {
    const data = { ...emptyData, activities: [{ id: "activity-1", title: "Corrida", minutes: 20, date: "2026-02-30" }] };
    expect(parseJourneyBackup(backup({ data }), "profile-a")).toEqual({ ok: false, reason: "invalid-file" });
  });
  it("recusa identificadores duplicados", () => {
    const data = { ...emptyData, activities: [
      { id: "same", title: "Corrida", minutes: 20, date: "2026-11-12" },
      { id: "same", title: "Caminhada", minutes: 15, date: "2026-11-12" },
    ] };
    expect(parseJourneyBackup(backup({ data }), "profile-a")).toEqual({ ok: false, reason: "invalid-file" });
  });
  it("recusa registros com campos fora dos limites", () => {
    const invalid = { ...emptyData, activities: [{ id: "a", title: "Corrida", minutes: 9999, date: "2026-11-12" }] };
    expect(parseJourneyBackup(backup({ data: invalid }), "profile-a")).toEqual({ ok: false, reason: "invalid-file" });
  });
});
