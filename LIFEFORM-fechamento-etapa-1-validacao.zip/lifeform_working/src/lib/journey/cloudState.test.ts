import { describe, expect, it } from "vitest";
import { hasJourneyRecords, isJourneyCloudState, journeyStatesMatch, type JourneyCloudState } from "@/lib/journey/cloudState";

const empty: JourneyCloudState = { activities: [], habits: [], goals: [], trainingSessions: [], weeklyReviews: [] };

describe("journey cloud state", () => {
  it("accepts only the expected collection structure", () => {
    expect(isJourneyCloudState(empty)).toBe(true);
    expect(isJourneyCloudState({ ...empty, goals: null })).toBe(false);
    expect(isJourneyCloudState(null)).toBe(false);
    expect(isJourneyCloudState([])).toBe(false);
  });

  it("detects whether local records exist", () => {
    expect(hasJourneyRecords(empty)).toBe(false);
    expect(hasJourneyRecords({ ...empty, activities: [{ id: "a" }] })).toBe(true);
  });

  it("compares states without mutating either version", () => {
    const other = { ...empty, habits: [{ id: "h" }] };
    expect(journeyStatesMatch(empty, { ...empty })).toBe(true);
    expect(journeyStatesMatch(empty, other)).toBe(false);
    expect(empty.habits).toHaveLength(0);
  });

  it("does not report a conflict only because object keys were serialized in another order", () => {
    const local = { ...empty, activities: [{ id: "a", title: "Corrida", minutes: 20 }] };
    const cloud = { ...empty, activities: [{ minutes: 20, title: "Corrida", id: "a" }] };
    expect(journeyStatesMatch(local, cloud)).toBe(true);
  });
});
