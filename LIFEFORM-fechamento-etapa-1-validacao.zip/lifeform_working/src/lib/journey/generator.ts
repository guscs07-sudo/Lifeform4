import type { AssessmentAnswers } from "@/lib/assessment/questions";

export type JourneyPillarId = "body" | "mind" | "lifestyle";
export type JourneyActionKind = "movement" | "habit" | "reflection" | "recovery";
export interface JourneyAction {
  id: string;
  day: number;
  dayLabel: string;
  title: string;
  description: string;
  pillar: JourneyPillarId;
  kind: JourneyActionKind;
  durationMinutes: number;
}
export interface PersonalizedJourney {
  title: string;
  subtitle: string;
  phase: "reconstruction" | "development";
  weeklyDays: number;
  sessionMinutes: number;
  focus: JourneyPillarId;
  actions: JourneyAction[];
  habits: Array<{ title: string; pillar: JourneyPillarId; frequency: string }>;
  safetyNote: string | null;
  rationale: string[];
}

const DAYS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"] as const;
const selected = (answers: AssessmentAnswers, key: string): string[] => Array.isArray(answers[key]) ? answers[key] as string[] : [];
const text = (answers: AssessmentAnswers, key: string): string => String(answers[key] ?? "");

function availableDays(value: string): number {
  if (value === "1 dia") return 1;
  if (value === "2 dias") return 2;
  if (value === "3 dias") return 3;
  if (value === "4 dias") return 4;
  if (value === "5 dias") return 5;
  if (value === "6 ou 7 dias") return 6;
  return 2; // início conservador quando a rotina varia
}
function sessionLength(value: string): number {
  if (value === "Até 15 minutos") return 15;
  if (value === "15 a 30 minutos") return 20;
  if (value === "30 a 45 minutos") return 30;
  if (value === "45 a 60 minutos") return 40;
  if (value === "Mais de 60 minutos") return 45;
  return 20;
}
function focusFromAnswers(answers: AssessmentAnswers, diagnosedPriority?: JourneyPillarId): JourneyPillarId {
  if (diagnosedPriority) return diagnosedPriority;
  const requested = text(answers, "priority_pillar");
  return requested === "mind" || requested === "lifestyle" ? requested : "body";
}

/**
 * Monta uma proposta inicial de organização, não uma prescrição de treino.
 * As ações físicas são descritas como opções leves e devem respeitar limitações,
 * sintomas e orientações profissionais informadas pela pessoa.
 */
export function generatePersonalizedJourney(answers: AssessmentAnswers, diagnosedPriority?: JourneyPillarId): PersonalizedJourney {
  const weeklyDays = Math.min(5, availableDays(text(answers, "available_days")));
  const sessionMinutes = sessionLength(text(answers, "session_minutes"));
  const focus = focusFromAnswers(answers, diagnosedPriority);
  const activity = text(answers, "activity_level");
  const experience = text(answers, "training_experience");
  const commitment = Number(answers.commitment ?? 0);
  const limitations = text(answers, "health_limitations");
  const sleep = text(answers, "sleep_hours");
  const barriers = selected(answers, "consistency_barrier");
  const variableRoutine = text(answers, "routine_predictability") === "Não, meus horários variam bastante" || text(answers, "available_days") === "Minha rotina varia muito";
  const needsCare = limitations !== "" && limitations !== "Não tenho nenhuma que eu saiba";
  const lowBase = activity === "Quase não faço atividade física" || experience === "Estou começando" || experience === "Já pratiquei, mas estou parado(a)" || commitment < 5;
  const phase = lowBase || needsCare ? "reconstruction" : "development";
  const preferences = selected(answers, "training_preferences");
  const preferredActivity = preferences.find((item) => item !== "Ainda não sei") ?? "movimento confortável";
  const actions: JourneyAction[] = [];
  const moveDays = weeklyDays === 1 ? [2] : Array.from({ length: weeklyDays }, (_, index) => Math.round(index * 6 / (weeklyDays - 1)));
  moveDays.forEach((day, index) => {
    const isCareful = needsCare || phase === "reconstruction";
    actions.push({
      id: `movement-${day}`,
      day,
      dayLabel: DAYS[day] ?? "Dia",
      title: index === 0 ? "Movimento de partida" : "Momento de movimento",
      description: needsCare
        ? "Defina com seu profissional quais movimentos são adequados antes de executar atividades físicas."
        : `${preferredActivity}: escolha uma opção confortável, sem buscar recordes ou forçar o corpo${isCareful ? ". Priorize facilidade e consistência." : ". Ajuste à sua disposição do dia."}`,
      pillar: "body",
      kind: needsCare ? "recovery" : "movement",
      durationMinutes: needsCare ? 0 : Math.min(sessionMinutes, phase === "reconstruction" ? 20 : sessionMinutes),
    });
  });
  const habitChoices = selected(answers, "habit_focus");
  const habits = habitChoices.slice(0, 3).map((habit) => ({
    title: habit,
    pillar: /dormir|descanso|alimentação|água/i.test(habit) ? "lifestyle" as const : /planejar|ler|estudar|tela/i.test(habit) ? "mind" as const : "body" as const,
    frequency: "Pequeno passo diário, adaptado à sua realidade",
  }));
  if (!habits.length) habits.push({ title: "Reservar alguns minutos para planejar o dia", pillar: "mind", frequency: "Em dias úteis, quando for possível" });
  if (sleep === "Menos de 5 horas" || sleep === "Entre 5 e 6 horas") {
    actions.push({ id: "recovery-midweek", day: 3, dayLabel: DAYS[3] ?? "Quinta", title: "Pausa de recuperação", description: "Observe seu descanso e reduza compromissos não essenciais quando possível.", pillar: "lifestyle", kind: "recovery", durationMinutes: 5 });
  }
  if (barriers.includes("Falta de tempo") || variableRoutine) {
    actions.push({ id: "weekly-planning", day: 0, dayLabel: DAYS[0] ?? "Segunda", title: "Planejamento flexível", description: "Escolha antecipadamente os momentos mais realistas da semana; se um dia mudar, reorganize sem compensar com excesso.", pillar: "lifestyle", kind: "reflection", durationMinutes: 5 });
  }
  actions.push({ id: "weekly-review", day: 6, dayLabel: DAYS[6] ?? "Domingo", title: "Revisão da semana", description: "Registre o que funcionou, o que foi difícil e o que precisa mudar na próxima semana.", pillar: "mind", kind: "reflection", durationMinutes: 5 });
  const rationale = [
    `A proposta considera ${weeklyDays} dia(s) disponíveis e sessões de referência de até ${sessionMinutes} minutos.`,
    `O ponto de partida foi definido como ${phase === "reconstruction" ? "Reconstrução" : "Desenvolvimento"}, considerando atividade atual, experiência e disposição declarada.`,
    `O pilar de atenção escolhido foi ${focus === "body" ? "Corpo" : focus === "mind" ? "Mente" : "Estilo de vida"}.`,
  ];
  if (barriers.length) rationale.push(`A organização também considera o(s) obstáculo(s) informado(s): ${barriers.join(", ")}.`);
  return {
    title: phase === "reconstruction" ? "Sua base de reconstrução" : "Seu plano de desenvolvimento",
    subtitle: variableRoutine ? "Uma semana flexível, com espaço para mudanças." : "Uma proposta inicial que pode ser ajustada a cada revisão semanal.",
    phase,
    weeklyDays,
    sessionMinutes,
    focus,
    actions: actions.sort((a, b) => a.day - b.day),
    habits,
    safetyNote: needsCare ? "Você informou uma lesão, limitação ou necessidade de adaptação. O LIFEFORM não vai sugerir exercícios específicos até que a adequação seja definida com um profissional habilitado." : null,
    rationale,
  };
}
