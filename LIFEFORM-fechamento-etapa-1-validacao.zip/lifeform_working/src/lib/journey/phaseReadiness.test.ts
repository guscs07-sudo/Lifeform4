import { describe, expect, it } from "vitest";
import { buildPhaseReadinessEvidence } from "./phaseReadiness";

describe("buildPhaseReadinessEvidence", () => {
  const referenceDate = new Date("2026-11-11T12:00:00");

  it("conta um hábito semanal no máximo uma vez por semana", () => {
    const result = buildPhaseReadinessEvidence({
      currentPhase: "reconstruction",
      activities: [],
      habits: [
        { frequency: "weekly", doneDates: ["2026-11-09", "2026-11-10", "2026-11-11"] },
      ],
      reviews: [],
      referenceDate,
    });
    expect(result.habitConsistency).toBe(1);
  });

  it("remove datas duplicadas de hábitos diários ao calcular consistência", () => {
    const result = buildPhaseReadinessEvidence({
      currentPhase: "reconstruction",
      activities: [],
      habits: [
        { frequency: "daily", doneDates: ["2026-11-09", "2026-11-09", "2026-11-10"] },
      ],
      reviews: [],
      referenceDate,
    });
    expect(result.habitConsistency).toBeCloseTo(2 / 3);
  });

  it("não conta registros de semanas anteriores na consistência atual", () => {
    const result = buildPhaseReadinessEvidence({
      currentPhase: "reconstruction",
      activities: [],
      habits: [{ frequency: "weekly", doneDates: ["2026-11-02"] }],
      reviews: [],
      referenceDate,
    });
    expect(result.habitConsistency).toBe(0);
  });
});
