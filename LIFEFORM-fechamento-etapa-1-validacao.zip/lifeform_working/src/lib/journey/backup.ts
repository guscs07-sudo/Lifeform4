export interface BackupActivity { id: string; title: string; minutes: number; date: string; note?: string; trainingSessionId?: string }
export interface BackupHabit { id: string; title: string; frequency: "daily" | "weekly"; doneDates: string[] }
export interface BackupGoal { id: string; title: string; detail: string; createdAt: string; completed: boolean }
export interface BackupTrainingEntry { exerciseId: string; exerciseName: string; sets: number; reps: number; loadKg?: number }
export interface BackupTrainingSession { id: string; title: string; date: string; durationMinutes: number; entries: BackupTrainingEntry[]; note?: string }
export interface BackupWeeklyReview { weekOf: string; energy: "low" | "medium" | "high"; recovery: "poor" | "okay" | "good"; difficulty: "easy" | "right" | "hard"; routine: "stable" | "changed" | "busy"; note: string; submittedAt: string }
export interface JourneyBackupData { activities: BackupActivity[]; habits: BackupHabit[]; goals: BackupGoal[]; trainingSessions: BackupTrainingSession[]; weeklyReviews: BackupWeeklyReview[] }

const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null && !Array.isArray(value);
const isText = (value: unknown): value is string => typeof value === "string" && value.length <= 1000;
const isDate = (value: unknown): value is string => {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(year, month - 1, day);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
};
const hasUniqueIds = (items: Array<{ id: string }>) => new Set(items.map((item) => item.id)).size === items.length;
const isCount = (value: unknown, min = 0, max = 10000): value is number => typeof value === "number" && Number.isInteger(value) && value >= min && value <= max;
const isTextArray = (value: unknown): value is string[] => Array.isArray(value) && value.length <= 5000 && value.every(isDate);

export type JourneyBackupResult = { ok: true; data: JourneyBackupData } | { ok: false; reason: "invalid-json" | "invalid-file" | "wrong-profile" | "unsupported-version" };

export function parseJourneyBackup(raw: string, expectedUserId: string): JourneyBackupResult {
  let parsed: unknown;
  try { parsed = JSON.parse(raw); } catch { return { ok: false, reason: "invalid-json" }; }
  if (!isRecord(parsed) || parsed.app !== "LIFEFORM" || !isRecord(parsed.data) || typeof parsed.userId !== "string") return { ok: false, reason: "invalid-file" };
  if (parsed.userId !== expectedUserId) return { ok: false, reason: "wrong-profile" };
  if (parsed.formatVersion !== 1) return { ok: false, reason: "unsupported-version" };
  const data = parsed.data;
  if (!["activities", "habits", "goals", "trainingSessions", "weeklyReviews"].every((key) => Array.isArray(data[key]))) return { ok: false, reason: "invalid-file" };

  const activities: BackupActivity[] = [];
  for (const item of data.activities as unknown[]) {
    if (!isRecord(item) || !isText(item.id) || !item.id.trim() || !isText(item.title) || !item.title.trim() || !isCount(item.minutes, 1, 600) || !isDate(item.date) || (item.note !== undefined && !isText(item.note)) || (item.trainingSessionId !== undefined && (typeof item.trainingSessionId !== "string" || !item.trainingSessionId.trim()))) return { ok: false, reason: "invalid-file" };
    activities.push({ id: item.id, title: item.title, minutes: item.minutes, date: item.date, ...(typeof item.note === "string" ? { note: item.note } : {}), ...(typeof item.trainingSessionId === "string" ? { trainingSessionId: item.trainingSessionId } : {}) });
  }
  const habits: BackupHabit[] = [];
  for (const item of data.habits as unknown[]) {
    if (!isRecord(item) || !isText(item.id) || !isText(item.title) || (item.frequency !== "daily" && item.frequency !== "weekly") || !isTextArray(item.doneDates)) return { ok: false, reason: "invalid-file" };
    habits.push({ id: item.id, title: item.title, frequency: item.frequency, doneDates: item.doneDates });
  }
  const goals: BackupGoal[] = [];
  for (const item of data.goals as unknown[]) {
    if (!isRecord(item) || !isText(item.id) || !isText(item.title) || !isText(item.detail) || !isDate(item.createdAt) || typeof item.completed !== "boolean") return { ok: false, reason: "invalid-file" };
    goals.push({ id: item.id, title: item.title, detail: item.detail, createdAt: item.createdAt, completed: item.completed });
  }
  const trainingSessions: BackupTrainingSession[] = [];
  for (const item of data.trainingSessions as unknown[]) {
    if (!isRecord(item) || !isText(item.id) || !isText(item.title) || !isDate(item.date) || !isCount(item.durationMinutes, 1, 600) || !Array.isArray(item.entries) || item.entries.length > 100 || (item.note !== undefined && !isText(item.note))) return { ok: false, reason: "invalid-file" };
    const entries: BackupTrainingEntry[] = [];
    for (const entry of item.entries) {
      if (!isRecord(entry) || !isText(entry.exerciseId) || !isText(entry.exerciseName) || !isCount(entry.sets, 1, 20) || !isCount(entry.reps, 1, 300) || (entry.loadKg !== undefined && (typeof entry.loadKg !== "number" || !Number.isFinite(entry.loadKg) || entry.loadKg < 0 || entry.loadKg > 1000))) return { ok: false, reason: "invalid-file" };
      entries.push({ exerciseId: entry.exerciseId, exerciseName: entry.exerciseName, sets: entry.sets, reps: entry.reps, ...(typeof entry.loadKg === "number" ? { loadKg: entry.loadKg } : {}) });
    }
    trainingSessions.push({ id: item.id, title: item.title, date: item.date, durationMinutes: item.durationMinutes, entries, ...(typeof item.note === "string" ? { note: item.note } : {}) });
  }
  const weeklyReviews: BackupWeeklyReview[] = [];
  for (const item of data.weeklyReviews as unknown[]) {
    if (!isRecord(item) || !isDate(item.weekOf) || !["low", "medium", "high"].includes(String(item.energy)) || !["poor", "okay", "good"].includes(String(item.recovery)) || !["easy", "right", "hard"].includes(String(item.difficulty)) || !["stable", "changed", "busy"].includes(String(item.routine)) || !isText(item.note) || typeof item.submittedAt !== "string" || Number.isNaN(Date.parse(item.submittedAt))) return { ok: false, reason: "invalid-file" };
    weeklyReviews.push({ weekOf: item.weekOf, energy: item.energy as BackupWeeklyReview["energy"], recovery: item.recovery as BackupWeeklyReview["recovery"], difficulty: item.difficulty as BackupWeeklyReview["difficulty"], routine: item.routine as BackupWeeklyReview["routine"], note: item.note, submittedAt: item.submittedAt });
  }
  if (!hasUniqueIds(activities) || !hasUniqueIds(habits) || !hasUniqueIds(goals) || !hasUniqueIds(trainingSessions)) return { ok: false, reason: "invalid-file" };
  if (new Set(weeklyReviews.map((review) => review.weekOf)).size !== weeklyReviews.length) return { ok: false, reason: "invalid-file" };
  return { ok: true, data: { activities, habits, goals, trainingSessions, weeklyReviews } };
}
