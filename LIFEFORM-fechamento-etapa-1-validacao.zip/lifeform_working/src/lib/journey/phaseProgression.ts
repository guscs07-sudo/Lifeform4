import type { PhaseId } from "../../config/phases";

export type PhaseSignal = "advance" | "maintain" | "simplify" | "recover";

export interface PhaseEvidence {
  currentPhase: PhaseId;
  /** Completed planned actions divided by planned actions, from 0 to 1. */
  adherenceRate: number;
  /** Number of consecutive weekly reviews with usable evidence. */
  consecutiveReviewedWeeks: number;
  /** Habit checks completed divided by planned checks, from 0 to 1. */
  habitConsistency: number;
  energy: "low" | "medium" | "high" | null;
  recovery: "poor" | "okay" | "good" | null;
  difficulty: "easy" | "right" | "hard" | null;
  hasUnresolvedSafetyConcern?: boolean;
}

export interface PhaseAssessment {
  currentPhase: PhaseId;
  recommendedPhase: PhaseId;
  signal: PhaseSignal;
  canAdvance: boolean;
  progressPercent: number;
  reasons: string[];
  nextCriteria: string[];
}

const ORDER: readonly PhaseId[] = ["reconstruction", "development", "evolution", "consolidation"];
const NEXT: Record<PhaseId, PhaseId> = {
  reconstruction: "development",
  development: "evolution",
  evolution: "consolidation",
  consolidation: "consolidation",
};

const clampRate = (value: number) => Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : 0;

/**
 * Avalia prontidão para a próxima fase. É uma recomendação explicável:
 * nunca muda a fase do perfil automaticamente e nunca usa tempo decorrido.
 */
export function assessPhaseProgress(evidence: PhaseEvidence): PhaseAssessment {
  const currentIndex = ORDER.indexOf(evidence.currentPhase);
  const target = NEXT[evidence.currentPhase];
  const adherence = clampRate(evidence.adherenceRate);
  const habits = clampRate(evidence.habitConsistency);
  const reasons: string[] = [];
  const criteria: string[] = [];

  if (evidence.currentPhase === "consolidation") {
    return {
      currentPhase: evidence.currentPhase,
      recommendedPhase: evidence.currentPhase,
      signal: "maintain",
      canAdvance: false,
      progressPercent: 100,
      reasons: ["Você está na fase de consolidação; o foco é preservar autonomia e consistência."],
      nextCriteria: ["Manter uma rotina sustentável e revisar objetivos quando suas prioridades mudarem."],
    };
  }

  const recoveryConcern = evidence.energy === "low" || evidence.recovery === "poor" || evidence.difficulty === "hard";
  if (evidence.hasUnresolvedSafetyConcern) {
    reasons.push("Existe uma questão de segurança ainda não resolvida; a progressão fica pausada.");
  }
  if (recoveryConcern) {
    if (evidence.energy === "low") reasons.push("A energia relatada está baixa.");
    if (evidence.recovery === "poor") reasons.push("A recuperação relatada precisa de atenção.");
    if (evidence.difficulty === "hard") reasons.push("A semana foi percebida como difícil demais.");
  }

  const requiredAdherence = evidence.currentPhase === "reconstruction" ? 0.6 : 0.7;
  const requiredHabits = evidence.currentPhase === "reconstruction" ? 0.5 : 0.6;
  const requiredWeeks = evidence.currentPhase === "reconstruction" ? 2 : 3;
  const checks = [
    { ok: adherence >= requiredAdherence, label: `Concluir pelo menos ${Math.round(requiredAdherence * 100)}% das atividades planejadas`, value: adherence / requiredAdherence },
    { ok: habits >= requiredHabits, label: `Manter pelo menos ${Math.round(requiredHabits * 100)}% de consistência nos hábitos`, value: habits / requiredHabits },
    { ok: evidence.consecutiveReviewedWeeks >= requiredWeeks, label: `Registrar ${requiredWeeks} revisões semanais consecutivas`, value: evidence.consecutiveReviewedWeeks / requiredWeeks },
    { ok: !recoveryConcern, label: "Apresentar sinais de energia e recuperação compatíveis com a progressão", value: recoveryConcern ? 0 : 1 },
    { ok: !evidence.hasUnresolvedSafetyConcern, label: "Resolver limitações ou alertas de segurança antes de avançar", value: evidence.hasUnresolvedSafetyConcern ? 0 : 1 },
  ];
  checks.filter((check) => !check.ok).forEach((check) => criteria.push(check.label));
  const score = checks.reduce((sum, check) => sum + Math.min(1, check.value), 0) / checks.length;
  const canAdvance = checks.every((check) => check.ok);

  if (evidence.hasUnresolvedSafetyConcern) {
    return { currentPhase: evidence.currentPhase, recommendedPhase: evidence.currentPhase, signal: "recover", canAdvance: false, progressPercent: Math.round(score * 100), reasons, nextCriteria: criteria };
  }
  if (recoveryConcern) {
    return { currentPhase: evidence.currentPhase, recommendedPhase: evidence.currentPhase, signal: "simplify", canAdvance: false, progressPercent: Math.round(score * 100), reasons, nextCriteria: criteria };
  }
  if (canAdvance) {
    return {
      currentPhase: evidence.currentPhase,
      recommendedPhase: target,
      signal: "advance",
      canAdvance: true,
      progressPercent: 100,
      reasons: [`Os critérios observáveis da fase ${currentIndex + 1} foram alcançados.`],
      nextCriteria: [`Próxima fase: ${target === "development" ? "Desenvolvimento" : target === "evolution" ? "Evolução" : "Consolidação"}. Confirme a mudança antes de atualizar seu plano.`],
    };
  }
  reasons.push("Ainda há critérios em construção; manter a fase atual é uma decisão válida.");
  return { currentPhase: evidence.currentPhase, recommendedPhase: evidence.currentPhase, signal: adherence < 0.35 ? "simplify" : "maintain", canAdvance: false, progressPercent: Math.round(score * 100), reasons, nextCriteria: criteria };
}
