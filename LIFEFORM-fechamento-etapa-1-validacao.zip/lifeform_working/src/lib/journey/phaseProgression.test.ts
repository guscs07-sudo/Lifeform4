import { describe, expect, it } from "vitest";
import { assessPhaseProgress } from "./phaseProgression";

const base = {
  currentPhase: "reconstruction" as const,
  adherenceRate: 0.8,
  consecutiveReviewedWeeks: 2,
  habitConsistency: 0.7,
  energy: "medium" as const,
  recovery: "good" as const,
  difficulty: "right" as const,
};

describe("assessPhaseProgress", () => {
  it("recomenda avanço quando todos os critérios são atendidos", () => {
    const result = assessPhaseProgress(base);
    expect(result.canAdvance).toBe(true);
    expect(result.recommendedPhase).toBe("development");
    expect(result.signal).toBe("advance");
  });

  it("não avança apenas porque a pessoa concluiu muitas atividades", () => {
    const result = assessPhaseProgress({ ...base, consecutiveReviewedWeeks: 0 });
    expect(result.canAdvance).toBe(false);
    expect(result.nextCriteria).toContain("Registrar 2 revisões semanais consecutivas");
  });

  it("pausa a progressão diante de alerta de segurança", () => {
    const result = assessPhaseProgress({ ...base, hasUnresolvedSafetyConcern: true });
    expect(result.signal).toBe("recover");
    expect(result.recommendedPhase).toBe("reconstruction");
  });

  it("sugere simplificar quando energia ou recuperação estão ruins", () => {
    const result = assessPhaseProgress({ ...base, energy: "low" });
    expect(result.signal).toBe("simplify");
    expect(result.canAdvance).toBe(false);
  });

  it("mantém consolidação como fase final", () => {
    const result = assessPhaseProgress({ ...base, currentPhase: "consolidation" });
    expect(result.recommendedPhase).toBe("consolidation");
    expect(result.progressPercent).toBe(100);
  });
});
