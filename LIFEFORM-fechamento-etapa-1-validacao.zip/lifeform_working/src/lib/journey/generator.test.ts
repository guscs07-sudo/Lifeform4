import { describe, expect, it } from "vitest";
import { generatePersonalizedJourney } from "./generator";

describe("generatePersonalizedJourney", () => {
  it("monta uma proposta conservadora quando a pessoa está começando", () => {
    const plan = generatePersonalizedJourney({ available_days: "3 dias", session_minutes: "30 a 45 minutos", activity_level: "Quase não faço atividade física", training_experience: "Estou começando", commitment: 4, priority_pillar: "body" });
    expect(plan.phase).toBe("reconstruction");
    expect(plan.weeklyDays).toBe(3);
    expect(plan.actions.filter((action) => action.kind === "movement")).toHaveLength(3);
    expect(plan.actions.filter((action) => action.kind === "movement").every((action) => action.durationMinutes <= 20)).toBe(true);
  });

  it("não sugere atividade física específica quando há limitação informada", () => {
    const plan = generatePersonalizedJourney({ available_days: "2 dias", session_minutes: "15 a 30 minutos", health_limitations: "Tenho uma lesão ou limitação física" });
    expect(plan.safetyNote).toContain("profissional habilitado");
    expect(plan.actions.filter((action) => action.kind === "recovery").every((action) => action.durationMinutes === 0)).toBe(true);
  });

  it("considera hábitos escolhidos e obstáculos de rotina", () => {
    const plan = generatePersonalizedJourney({ available_days: "Minha rotina varia muito", session_minutes: "Até 15 minutos", habit_focus: ["Beber mais água", "Planejar meu dia"], consistency_barrier: ["Falta de tempo"] });
    expect(plan.habits.map((habit) => habit.title)).toEqual(["Beber mais água", "Planejar meu dia"]);
    expect(plan.actions.some((action) => action.id === "weekly-planning")).toBe(true);
  });

  it("usa o foco do pilar selecionado", () => {
    const plan = generatePersonalizedJourney({ priority_pillar: "lifestyle" });
    expect(plan.focus).toBe("lifestyle");
  });

  it("prioriza o pilar calculado pelo diagnóstico integrado", () => {
    const plan = generatePersonalizedJourney({ priority_pillar: "body" }, "mind");
    expect(plan.focus).toBe("mind");
    expect(plan.rationale.some((item) => item.includes("Mente"))).toBe(true);
  });
});
