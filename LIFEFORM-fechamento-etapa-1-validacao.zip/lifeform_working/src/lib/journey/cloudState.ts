export type JourneyCloudState = {
  activities: unknown[];
  habits: unknown[];
  goals: unknown[];
  trainingSessions: unknown[];
  weeklyReviews: unknown[];
};

export function isJourneyCloudState(value: unknown): value is JourneyCloudState {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const candidate = value as Record<string, unknown>;
  return ["activities", "habits", "goals", "trainingSessions", "weeklyReviews"].every((key) => Array.isArray(candidate[key]));
}

export function hasJourneyRecords(state: JourneyCloudState): boolean {
  return Object.values(state).some((items) => items.length > 0);
}

function stableSerialize(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stableSerialize).join(",")}]`;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableSerialize(record[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

export function journeyStatesMatch(left: JourneyCloudState, right: JourneyCloudState): boolean {
  return stableSerialize(left) === stableSerialize(right);
}
