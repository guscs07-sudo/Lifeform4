import { isSupabaseConfigured } from "@/lib/env";
import { getSupabaseBrowserClient } from "@/lib/supabase/browser";
import { mapAuthError } from "./errors";
import type { AuthErrorCode, AuthResult, AuthService, AuthUser } from "./types";

const fail = (error: AuthErrorCode): { ok: false; error: AuthErrorCode } => ({ ok: false, error });

/** Usado quando o Supabase não está configurado: nada é simulado, tudo falha de forma clara. */
const notConfiguredService: AuthService = {
  isConfigured: false,
  signUp: async () => fail("not_configured"),
  signIn: async () => fail("not_configured"),
  signOut: async () => fail("not_configured"),
  getUser: async () => fail("not_configured"),
};

const supabaseService: AuthService = {
  isConfigured: true,

  async signUp({ name, email, password }) {
    const client = getSupabaseBrowserClient();
    if (!client) return fail("not_configured");
    try {
      const { data, error } = await client.auth.signUp({
        email,
        password,
        options: {
          data: { display_name: name, age_confirmed: true },
          emailRedirectTo: `${window.location.origin}/avaliacao`,
        },
      });
      if (error) return fail(mapAuthError(error));
      return { ok: true, data: { status: data.session ? "signed_in" : "confirm_email" } };
    } catch (error) {
      return fail(mapAuthError(error));
    }
  },

  async signIn({ email, password }) {
    const client = getSupabaseBrowserClient();
    if (!client) return fail("not_configured");
    try {
      const { error } = await client.auth.signInWithPassword({ email, password });
      if (error) return fail(mapAuthError(error));
      return { ok: true, data: null };
    } catch (error) {
      return fail(mapAuthError(error));
    }
  },

  async signOut() {
    const client = getSupabaseBrowserClient();
    if (!client) return fail("not_configured");
    try {
      const { error } = await client.auth.signOut();
      if (error) return fail(mapAuthError(error));
      return { ok: true, data: null };
    } catch (error) {
      return fail(mapAuthError(error));
    }
  },

  async getUser(): Promise<AuthResult<AuthUser | null>> {
    const client = getSupabaseBrowserClient();
    if (!client) return fail("not_configured");
    try {
      const { data, error } = await client.auth.getUser();
      if (error) {
        const sessionMissing =
          error.name === "AuthSessionMissingError" || error.message.toLowerCase().includes("session missing");
        if (sessionMissing) return { ok: true, data: null };
        return fail(mapAuthError(error));
      }
      const user = data.user;
      if (!user) return { ok: true, data: null };
      const displayName: unknown = user.user_metadata?.display_name;
      return {
        ok: true,
        data: {
          id: user.id,
          email: user.email ?? "",
          name: typeof displayName === "string" && displayName !== "" ? displayName : null,
        },
      };
    } catch (error) {
      return fail(mapAuthError(error));
    }
  },
};

export function createAuthService(): AuthService {
  return isSupabaseConfigured() ? supabaseService : notConfiguredService;
}
