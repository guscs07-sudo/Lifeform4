/**
 * Contrato de autenticação do LIFEFORM.
 * A interface não depende do Supabase: a implementação atual fica em service.ts
 * e pode ser trocada sem alterar telas ou formulários.
 */

export const AUTH_ERROR_CODES = [
  "not_configured",
  "invalid_credentials",
  "email_in_use",
  "email_not_confirmed",
  "weak_password",
  "rate_limited",
  "network",
  "unknown",
] as const;
export type AuthErrorCode = (typeof AUTH_ERROR_CODES)[number];

export type AuthResult<T> = { ok: true; data: T } | { ok: false; error: AuthErrorCode };

export interface SignUpInput {
  name: string;
  email: string;
  password: string;
}

export interface SignInInput {
  email: string;
  password: string;
}

/** "confirm_email": conta criada, mas o e-mail precisa ser confirmado antes de entrar. */
export type SignUpStatus = "signed_in" | "confirm_email";

export interface AuthUser {
  id: string;
  email: string;
  name: string | null;
}

export interface AuthService {
  /** false quando o Supabase não está configurado neste ambiente. */
  readonly isConfigured: boolean;
  signUp(input: SignUpInput): Promise<AuthResult<{ status: SignUpStatus }>>;
  signIn(input: SignInInput): Promise<AuthResult<null>>;
  signOut(): Promise<AuthResult<null>>;
  /** Usuário da sessão atual (validado no servidor de autenticação) ou null. */
  getUser(): Promise<AuthResult<AuthUser | null>>;
}
