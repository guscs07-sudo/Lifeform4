import { describe, expect, it } from "vitest";
import { getLoginRedirect, getSafePostAuthRedirect, isProtectedPath } from "./protectedRoutes";

describe("protected route helpers", () => {
  it("protects private pages and nested paths", () => {
    expect(isProtectedPath("/painel")).toBe(true);
    expect(isProtectedPath("/painel/configuracoes")).toBe(true);
    expect(isProtectedPath("/avaliacao")).toBe(true);
    expect(isProtectedPath("/avaliacao/resultado")).toBe(true);
  });

  it("does not protect public pages or similarly named paths", () => {
    expect(isProtectedPath("/")).toBe(false);
    expect(isProtectedPath("/entrar")).toBe(false);
    expect(isProtectedPath("/cadastro")).toBe(false);
    expect(isProtectedPath("/painel-publico")).toBe(false);
  });

  it("accepts only internal protected destinations after login", () => {
    expect(getSafePostAuthRedirect("/painel/treinos?aba=semana")).toBe("/painel/treinos?aba=semana");
    expect(getSafePostAuthRedirect("/avaliacao/resultado#resumo")).toBe("/avaliacao/resultado#resumo");
    expect(getSafePostAuthRedirect("https://evil.example")).toBe("/avaliacao");
    expect(getSafePostAuthRedirect("//evil.example")).toBe("/avaliacao");
    expect(getSafePostAuthRedirect("/entrar")).toBe("/avaliacao");
    expect(getSafePostAuthRedirect("/\\\\evil.example")).toBe("/avaliacao");
    expect(getSafePostAuthRedirect(null)).toBe("/avaliacao");
  });

  it("creates a safe return URL for login", () => {
    expect(getLoginRedirect("/painel")).toBe("/entrar?next=%2Fpainel");
    expect(getLoginRedirect("//evil.example")).toBe("/entrar?next=%2Fpainel");
  });
});
