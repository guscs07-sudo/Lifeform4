import { describe, expect, it } from "vitest";
import {
  validateEmail,
  validateLogin,
  validateName,
  validateNewPassword,
  validateSignup,
  type SignupFormValues,
} from "./validation";

const valid: SignupFormValues = {
  name: "  Ana   Souza ",
  email: "  Ana@Exemplo.COM ",
  password: "senha1234",
  confirmPassword: "senha1234",
  ageConfirmed: true,
};

describe("validateEmail", () => {
  it("aceita e-mails válidos", () => {
    expect(validateEmail("ana@exemplo.com")).toBeUndefined();
    expect(validateEmail("  ana+lf@sub.exemplo.com.br ")).toBeUndefined();
  });
  it("rejeita vazio e formatos inválidos", () => {
    expect(validateEmail("   ")).toBe("auth.errors.emailRequired");
    expect(validateEmail("ana")).toBe("auth.errors.emailInvalid");
    expect(validateEmail("ana@exemplo")).toBe("auth.errors.emailInvalid");
    expect(validateEmail("a na@exemplo.com")).toBe("auth.errors.emailInvalid");
  });
});

describe("validateName", () => {
  it("aplica limites", () => {
    expect(validateName("")).toBe("auth.errors.nameRequired");
    expect(validateName("A")).toBe("auth.errors.nameTooShort");
    expect(validateName("x".repeat(61))).toBe("auth.errors.nameTooLong");
    expect(validateName("Ana")).toBeUndefined();
  });
});

describe("validateNewPassword", () => {
  it("exige tamanho mínimo, letra e número", () => {
    expect(validateNewPassword("")).toBe("auth.errors.passwordRequired");
    expect(validateNewPassword("abc123")).toBe("auth.errors.passwordTooShort");
    expect(validateNewPassword("somenteletras")).toBe("auth.errors.passwordWeak");
    expect(validateNewPassword("12345678")).toBe("auth.errors.passwordWeak");
    expect(validateNewPassword("senha1234")).toBeUndefined();
  });
  it("limita o tamanho máximo em bytes", () => {
    expect(validateNewPassword("a1".repeat(40))).toBe("auth.errors.passwordTooLong");
  });
});

describe("validateSignup", () => {
  it("normaliza nome e e-mail quando válido", () => {
    const result = validateSignup(valid);
    expect(result).toEqual({
      ok: true,
      value: { name: "Ana Souza", email: "ana@exemplo.com", password: "senha1234" },
    });
  });
  it("retorna um erro por campo inválido", () => {
    const result = validateSignup({
      name: "",
      email: "x",
      password: "curta",
      confirmPassword: "outra",
      ageConfirmed: false,
    });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(Object.keys(result.errors).sort()).toEqual(
      ["ageConfirmed", "confirmPassword", "email", "name", "password"].sort(),
    );
  });
  it("detecta confirmação de senha diferente", () => {
    const result = validateSignup({ ...valid, confirmPassword: "senha12345" });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.errors.confirmPassword).toBe("auth.errors.confirmMismatch");
  });
  it("exige a declaração de maioridade", () => {
    const result = validateSignup({ ...valid, ageConfirmed: false });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.errors.ageConfirmed).toBe("auth.errors.ageRequired");
  });
});

describe("validateLogin", () => {
  it("não aplica regras de força da senha no login", () => {
    const result = validateLogin({ email: "Ana@Exemplo.com", password: "x" });
    expect(result).toEqual({ ok: true, value: { email: "ana@exemplo.com", password: "x" } });
  });
  it("exige e-mail e senha", () => {
    const result = validateLogin({ email: "", password: "" });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.errors.email).toBe("auth.errors.emailRequired");
    expect(result.errors.password).toBe("auth.errors.passwordRequired");
  });
});
