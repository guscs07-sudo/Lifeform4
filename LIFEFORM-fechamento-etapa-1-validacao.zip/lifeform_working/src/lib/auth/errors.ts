import type { AuthErrorCode } from "./types";

interface ErrorLike {
  message?: string;
  status?: number;
  code?: string;
  name?: string;
}

/**
 * Converte erros do provedor de autenticação em códigos internos estáveis.
 * Mensagens exibidas ao usuário vêm do catálogo i18n (auth.errors.<codigo>);
 * o texto cru do provedor nunca é mostrado na tela.
 */
export function mapAuthError(error: unknown): AuthErrorCode {
  const e: ErrorLike = typeof error === "object" && error !== null ? (error as ErrorLike) : {};
  const message = (e.message ?? (typeof error === "string" ? error : "")).toLowerCase();
  const code = (e.code ?? "").toLowerCase();
  const name = e.name ?? "";

  if (code === "invalid_credentials" || message.includes("invalid login credentials")) {
    return "invalid_credentials";
  }
  if (code === "user_already_exists" || code === "email_exists" || message.includes("already registered") || message.includes("already been registered")) {
    return "email_in_use";
  }
  if (code === "email_not_confirmed" || message.includes("email not confirmed")) {
    return "email_not_confirmed";
  }
  if (code === "weak_password" || message.includes("weak password") || message.includes("password should be")) {
    return "weak_password";
  }
  if (e.status === 429 || code.includes("rate_limit") || message.includes("rate limit")) {
    return "rate_limited";
  }
  if (
    name === "AuthRetryableFetchError" ||
    message.includes("failed to fetch") ||
    message.includes("network") ||
    message.includes("load failed") // mensagem do Safari quando a conexão falha
  ) {
    return "network";
  }
  return "unknown";
}
