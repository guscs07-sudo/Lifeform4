/** Rotas que exigem uma sessão autenticada do LIFEFORM. */
const PROTECTED_PREFIXES = ["/painel", "/avaliacao"] as const;

export function isProtectedPath(pathname: string): boolean {
  return PROTECTED_PREFIXES.some(
    (prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`),
  );
}

export function getLoginRedirect(pathname: string): string {
  const safePath = pathname.startsWith("/") && !pathname.startsWith("//") ? pathname : "/painel";
  return `/entrar?next=${encodeURIComponent(safePath)}`;
}


/**
 * Destino pós-autenticação: aceita somente caminhos internos que já exigem
 * sessão. Rejeita URLs absolutas, protocol-relative e rotas públicas.
 */
export function getSafePostAuthRedirect(nextPath: string | null | undefined): string {
  if (!nextPath || !nextPath.startsWith("/") || nextPath.startsWith("//") || nextPath.includes("\\\\")) {
    return "/avaliacao";
  }

  try {
    const url = new URL(nextPath, "https://lifeform.invalid");
    if (url.origin !== "https://lifeform.invalid" || !isProtectedPath(url.pathname)) {
      return "/avaliacao";
    }
    return `${url.pathname}${url.search}${url.hash}`;
  } catch {
    return "/avaliacao";
  }
}
