import { describe, expect, it } from "vitest";
import { t } from "@/i18n";
import { mapAuthError } from "./errors";
import { AUTH_ERROR_CODES } from "./types";

describe("mapAuthError", () => {
  it("mapeia credenciais inválidas", () => {
    expect(mapAuthError({ message: "Invalid login credentials", status: 400 })).toBe("invalid_credentials");
    expect(mapAuthError({ code: "invalid_credentials" })).toBe("invalid_credentials");
  });
  it("mapeia e-mail já cadastrado", () => {
    expect(mapAuthError({ message: "User already registered" })).toBe("email_in_use");
    expect(mapAuthError({ code: "user_already_exists" })).toBe("email_in_use");
  });
  it("mapeia e-mail não confirmado", () => {
    expect(mapAuthError({ message: "Email not confirmed" })).toBe("email_not_confirmed");
  });
  it("mapeia senha fraca", () => {
    expect(mapAuthError({ code: "weak_password" })).toBe("weak_password");
    expect(mapAuthError({ message: "Password should be at least 6 characters" })).toBe("weak_password");
  });
  it("mapeia limite de requisições", () => {
    expect(mapAuthError({ status: 429 })).toBe("rate_limited");
    expect(mapAuthError({ code: "over_email_send_rate_limit" })).toBe("rate_limited");
  });
  it("mapeia falhas de rede (inclui Safari)", () => {
    expect(mapAuthError(new TypeError("Failed to fetch"))).toBe("network");
    expect(mapAuthError({ message: "Load failed" })).toBe("network");
    expect(mapAuthError({ name: "AuthRetryableFetchError", message: "x" })).toBe("network");
  });
  it("usa 'unknown' para o restante, sem lançar", () => {
    expect(mapAuthError({ message: "algo inesperado" })).toBe("unknown");
    expect(mapAuthError(undefined)).toBe("unknown");
    expect(mapAuthError("texto solto")).toBe("unknown");
  });
});

describe("mensagens de erro de autenticação", () => {
  it("todo código tem texto no catálogo de idioma", () => {
    for (const code of AUTH_ERROR_CODES) {
      const key = `auth.errors.${code}`;
      expect(t(key)).not.toBe(key);
    }
  });
});
