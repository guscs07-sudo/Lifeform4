/**
 * Validação de formulários de autenticação.
 * Funções puras, sem dependência de React ou de i18n: os erros são CHAVES de
 * tradução (ex.: "auth.errors.emailInvalid"), traduzidas na camada de interface.
 */

export const NAME_MIN = 2;
export const NAME_MAX = 60;
export const PASSWORD_MIN = 8;
/** O Supabase (bcrypt) considera no máximo 72 bytes da senha. */
export const PASSWORD_MAX = 72;
export const EMAIL_MAX = 254;

export type FieldErrors<K extends string> = Partial<Record<K, string>>;
export type Validation<T, K extends string> =
  | { ok: true; value: T }
  | { ok: false; errors: FieldErrors<K> };

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function normalizeEmail(value: string): string {
  return value.trim().toLowerCase();
}

export function normalizeName(value: string): string {
  return value.trim().replace(/\s+/g, " ");
}

export function validateEmail(value: string): string | undefined {
  const email = normalizeEmail(value);
  if (email === "") return "auth.errors.emailRequired";
  if (email.length > EMAIL_MAX || !EMAIL_PATTERN.test(email)) return "auth.errors.emailInvalid";
  return undefined;
}

export function validateName(value: string): string | undefined {
  const name = normalizeName(value);
  if (name === "") return "auth.errors.nameRequired";
  const length = Array.from(name).length;
  if (length < NAME_MIN) return "auth.errors.nameTooShort";
  if (length > NAME_MAX) return "auth.errors.nameTooLong";
  return undefined;
}

/** Regras de senha para CRIAR conta. No login só se exige que não esteja vazia. */
export function validateNewPassword(value: string): string | undefined {
  if (value === "") return "auth.errors.passwordRequired";
  if (value.length < PASSWORD_MIN) return "auth.errors.passwordTooShort";
  if (new TextEncoder().encode(value).length > PASSWORD_MAX) return "auth.errors.passwordTooLong";
  if (!/\p{L}/u.test(value) || !/\d/.test(value)) return "auth.errors.passwordWeak";
  return undefined;
}

export type SignupField = "name" | "email" | "password" | "confirmPassword" | "ageConfirmed";

export interface SignupFormValues {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  ageConfirmed: boolean;
}

export interface SignupPayload {
  name: string;
  email: string;
  password: string;
}

export function validateSignup(input: SignupFormValues): Validation<SignupPayload, SignupField> {
  const errors: FieldErrors<SignupField> = {};

  const nameError = validateName(input.name);
  if (nameError) errors.name = nameError;

  const emailError = validateEmail(input.email);
  if (emailError) errors.email = emailError;

  const passwordError = validateNewPassword(input.password);
  if (passwordError) errors.password = passwordError;

  if (input.confirmPassword === "") errors.confirmPassword = "auth.errors.confirmRequired";
  else if (input.confirmPassword !== input.password) errors.confirmPassword = "auth.errors.confirmMismatch";

  if (!input.ageConfirmed) errors.ageConfirmed = "auth.errors.ageRequired";

  if (Object.keys(errors).length > 0) return { ok: false, errors };
  return {
    ok: true,
    value: {
      name: normalizeName(input.name),
      email: normalizeEmail(input.email),
      password: input.password,
    },
  };
}

export type LoginField = "email" | "password";

export interface LoginFormValues {
  email: string;
  password: string;
}

export function validateLogin(input: LoginFormValues): Validation<LoginFormValues, LoginField> {
  const errors: FieldErrors<LoginField> = {};

  const emailError = validateEmail(input.email);
  if (emailError) errors.email = emailError;

  if (input.password === "") errors.password = "auth.errors.passwordRequired";

  if (Object.keys(errors).length > 0) return { ok: false, errors };
  return { ok: true, value: { email: normalizeEmail(input.email), password: input.password } };
}
