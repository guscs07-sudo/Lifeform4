import { createBrowserClient } from "@supabase/ssr";
import type { SupabaseClient } from "@supabase/supabase-js";
import { getSupabaseConfig } from "@/lib/env";

/**
 * Cliente Supabase para o navegador (somente URL + chave pública/anon).
 * Projeto Supabase PRÓPRIO do LIFEFORM: nenhuma credencial ou referência do
 * OPERAÇÃO TAF existe neste código; tudo vem das variáveis de ambiente.
 * Criado sob demanda (nunca durante a renderização no servidor).
 */
let cached: SupabaseClient | null = null;

export function getSupabaseBrowserClient(): SupabaseClient | null {
  if (cached) return cached;
  const config = getSupabaseConfig();
  if (!config) return null;
  cached = createBrowserClient(config.url, config.anonKey);
  return cached;
}
