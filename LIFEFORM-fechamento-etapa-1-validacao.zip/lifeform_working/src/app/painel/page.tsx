import type { Metadata } from "next";
import { DashboardGate } from "@/features/dashboard/DashboardGate";

export const metadata: Metadata = { title: "Seu painel" };

export default function DashboardPage() {
  return <DashboardGate />;
}
