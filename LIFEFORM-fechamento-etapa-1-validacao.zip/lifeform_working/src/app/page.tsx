import Link from "next/link";
import { buttonClasses } from "@/components/ui/Button";
import { Hero } from "@/features/landing/Hero";
import { HowItWorks } from "@/features/landing/HowItWorks";
import { Pillars } from "@/features/landing/Pillars";
import { t } from "@/i18n";

export default function HomePage() {
  return (
    <main className="flex-1">
      <Hero />
      <Pillars />
      <HowItWorks />
      <section className="mx-auto flex w-full max-w-md flex-col gap-4 px-5 pb-14">
        <Link href="/cadastro" className={buttonClasses({ size: "lg", fullWidth: true })}>
          {t("landing.ctaStart")}
        </Link>
        <p className="text-center text-xs text-lf-gray-400">{t("landing.safety")}</p>
      </section>
    </main>
  );
}
