import type { Metadata } from "next";
import { AssessmentGate } from "@/features/assessment/AssessmentGate";
import { AuthShell } from "@/features/auth/AuthShell";

export const metadata: Metadata = { title: "Sua avaliação" };

export default function AssessmentPage() {
  return (
    <AuthShell title="Sua jornada começa aqui" subtitle="Uma avaliação feita para entender seu momento e respeitar sua realidade.">
      <AssessmentGate />
    </AuthShell>
  );
}
