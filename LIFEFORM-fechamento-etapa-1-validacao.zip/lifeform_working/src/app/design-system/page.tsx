import type { Metadata } from "next";
import { Logo } from "@/components/brand/Logo";
import { AssetImage } from "@/components/media/AssetImage";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { EmptyState, ErrorState, LoadingState, SuccessState } from "@/components/ui/StateViews";
import { MODULES } from "@/config/modules";
import { PHASES } from "@/config/phases";
import { moduleSlotId } from "@/content/assets/registry";
import { t } from "@/i18n";

export const metadata: Metadata = { title: "Design system" };

const SWATCHES = [
  ["ink", "bg-lf-ink"],
  ["graphite 800", "bg-lf-graphite-800"],
  ["graphite 600", "bg-lf-graphite-600"],
  ["gray 400", "bg-lf-gray-400"],
  ["white", "bg-lf-white"],
  ["accent", "bg-lf-accent"],
] as const;

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-4">
      <h2 className="font-display text-sm uppercase tracking-[0.2em] text-lf-gray-400">{title}</h2>
      {children}
    </section>
  );
}

/** Página de referência interna. Mostra os componentes da Etapa 1 em todos os estados. */
export default function DesignSystemPage() {
  const firstModule = MODULES[0];
  return (
    <main className="mx-auto flex max-w-md flex-col gap-10 px-5 py-10">
      <Logo />

      <Section title="Cores (provisórias até a logo oficial)">
        <div className="grid grid-cols-3 gap-3">
          {SWATCHES.map(([name, cls]) => (
            <div key={name} className="flex flex-col gap-1 text-xs text-lf-gray-300">
              <div className={`h-12 rounded-xl border border-lf-graphite-600 ${cls}`} />
              {name}
            </div>
          ))}
        </div>
      </Section>

      <Section title="Botões">
        <div className="flex flex-col gap-3">
          <Button size="lg" fullWidth>Primário</Button>
          <Button variant="secondary" fullWidth>Secundário</Button>
          <Button variant="ghost" fullWidth>Fantasma</Button>
          <Button loading fullWidth>Carregando</Button>
          <Button disabled fullWidth>Desabilitado</Button>
        </div>
      </Section>

      <Section title="Cartões">
        <Card>Padrão</Card>
        <Card tone="interactive">Interativo</Card>
        <Card tone="selected">Selecionado</Card>
      </Section>

      <Section title="Progresso">
        <ProgressBar value={35} label="Exemplo de barra a 35%" />
        <p className="text-xs text-lf-gray-400">Valor ilustrativo apenas nesta página de referência.</p>
      </Section>

      <Section title="Estados">
        <Card><LoadingState /></Card>
        <Card><EmptyState description="Quando não há dados, a tela explica o que fazer." /></Card>
        <Card><ErrorState /></Card>
        <Card><SuccessState /></Card>
      </Section>

      <Section title="Imagens: slots aguardando arquivos definitivos">
        {firstModule && <AssetImage slotId={moduleSlotId("anime", firstModule.id)} priority />}
        {firstModule && <AssetImage slotId={moduleSlotId("photo", firstModule.id)} className="max-w-[260px]" />}
      </Section>

      <Section title="Módulos e fases">
        <ul className="flex flex-col gap-2 text-sm">
          {MODULES.map((m) => (
            <li key={m.id} className="text-lf-gray-300">
              {String(m.number).padStart(2, "0")} · {t(m.titleKey)}
            </li>
          ))}
        </ul>
        <ul className="flex flex-col gap-2 text-sm">
          {PHASES.map((p) => (
            <li key={p.id} className="text-lf-gray-300">
              Fase {p.number} · {t(p.titleKey)}
            </li>
          ))}
        </ul>
      </Section>
    </main>
  );
}
