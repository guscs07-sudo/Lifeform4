import type { Metadata } from "next";
import Link from "next/link";
import { AuthShell } from "@/features/auth/AuthShell";
import { SignupForm } from "@/features/auth/SignupForm";
import { t } from "@/i18n";

export const metadata: Metadata = { title: "Criar conta" };

export default function SignupPage() {
  return (
    <AuthShell
      title={t("auth.signup.title")}
      subtitle={t("auth.signup.subtitle")}
      footer={
        <p>
          {t("auth.signup.haveAccount")}{" "}
          <Link href="/entrar" className="inline-flex min-h-11 items-center text-lf-accent underline underline-offset-4">
            {t("auth.signup.loginLink")}
          </Link>
        </p>
      }
    >
      <SignupForm />
    </AuthShell>
  );
}
