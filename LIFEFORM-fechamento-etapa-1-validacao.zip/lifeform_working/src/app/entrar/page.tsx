import type { Metadata } from "next";
import Link from "next/link";
import { AuthShell } from "@/features/auth/AuthShell";
import { LoginForm } from "@/features/auth/LoginForm";
import { t } from "@/i18n";

export const metadata: Metadata = { title: "Entrar" };

export default function LoginPage() {
  return (
    <AuthShell
      title={t("auth.login.title")}
      subtitle={t("auth.login.subtitle")}
      footer={
        <p>
          {t("auth.login.noAccount")}{" "}
          <Link href="/cadastro" className="inline-flex min-h-11 items-center text-lf-accent underline underline-offset-4">
            {t("auth.login.signupLink")}
          </Link>
        </p>
      }
    >
      <LoginForm />
    </AuthShell>
  );
}
