import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { getSupabaseConfig } from "@/lib/env";
import { getLoginRedirect, isProtectedPath } from "@/lib/auth/protectedRoutes";

/** Renova cookies do Supabase e bloqueia rotas privadas antes de renderizar a página. */
export async function middleware(request: NextRequest) {
  const config = getSupabaseConfig();
  if (!config) return NextResponse.next({ request });

  let response = NextResponse.next({ request });
  const supabase = createServerClient(config.url, config.anonKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        cookiesToSet.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
      },
    },
  });

  // getUser valida a sessão no servidor de autenticação; não confiar apenas no cookie.
  const { data, error } = await supabase.auth.getUser();
  if (isProtectedPath(request.nextUrl.pathname) && (error || !data.user)) {
    const redirectUrl = new URL(getLoginRedirect(request.nextUrl.pathname), request.url);
    const redirect = NextResponse.redirect(redirectUrl);
    response.cookies.getAll().forEach((cookie) => redirect.cookies.set(cookie));
    return redirect;
  }

  return response;
}

export const config = {
  matcher: ["/painel/:path*", "/avaliacao/:path*"],
};
